CLASS 11 PHYSICS LAB - WAVES
Interactive Design Practicum Project for CBSE Class 11 (Waves chapter)
=====================================================================

WHAT THIS IS
------------
A complete, self-contained interactive project covering the Waves chapter.
It has 9 simulated experiments, supporting theory notes, graphs, a quiz and
a printable lab report. Everything runs offline in any modern browser --
nothing needs to be installed and no internet connection is required.

WHAT IS IN THIS FOLDER
----------------------
index.html          Home page: experiment cards, key concepts, FAQ and the
                    student's saved progress dashboard.
class11-lab.html    The main Lab: 9 experiments (Wave on a String, Standing
                    Waves, Sonometer, Air Column, Doppler Effect, Beats,
                    Interference, Reflection, Superposition). Each has live
                    controls, recordable observation tables, operating
                    steps, aim/apparatus/viva notes, and a printable report.
theory.html         15 short sections of notes covering the whole chapter,
                    with key equations, worked problems and common pitfalls.
quiz.html           45 questions (Easy / Medium / Hard) plus a practice mode,
                    with scores, badges and saved progress.
graphs.html         21 interactive graphs showing how the quantities depend
                    on each other for all ten experiments.
project.html        A write-up of the project: aim, the interactive approach,
                    syllabus mapping for the Waves chapter, how to use the set,
                    expected outcomes, and the technology used -- ready to print.
css/style.css       Shared stylesheet used by the pages above.
css/theme.css       Dark navy / deep purple / sky-blue theme. Loaded LAST by every
                    page (index, lab, theory, quiz, graphs, project), so it
                    controls the whole look of the site.
css/mobile.css      Phone-friendly layout. Loaded after theme.css on every page.
                    Stacks panels, enlarges tap targets and sliders, makes tables
                    swipeable, fixes the Lab scroll on phones.
README.txt          This file.

HOW TO OPEN IT
--------------
Double-click index.html (or any of the HTML files). All pages link to each
other. No server, no install, no internet.

HOW THE STUDENT USES IT
-----------------------
1. Open the Lab, pick an experiment, follow the numbered "How to operate"
   steps, and press Record to save each set of readings on the device.
   Copy or download the table as CSV is also available.
2. Compare with the Graphs page, study the Theory notes, and take the Quiz
   (scores/saved progress are shown on the home page).
3. Open the Lab's "Lab Report" (top bar) and press Print to produce a
   complete printed report: aim, apparatus, formula, observations,
   calculations, result, precautions and signature lines.

Extra notes
-----------
- Student details (name, class, roll, etc.) are typed once in the Lab's
  report form (📋 Lab Report) and appear on the printed report.
- The site uses one dark navy theme (css/theme.css); the old light/dark
  toggle button is hidden.
- Recorded readings and quiz scores are kept in the browser on the device
  where they were taken (so they do not travel with the files by themselves).
- Sound experiments use the browser's Web Audio API; all sound is optional.

REQUIREMENTS
------------
Any current browser (Chrome, Edge, Firefox, Safari) on computer or phone.
JavaScript must be enabled. No other software is required.
On phones: open index.html in your phone browser — the Lab stacks vertically
(experiments row -> wave canvas -> sliders), buttons and sliders are larger
for touch, and tables swipe sideways.