/*
# Create experiment_readings table (lab notebook)

1. New Tables
- `experiment_readings`
  - `id` (uuid, primary key)
  - `experiment_slug` (text, not null) - which experiment the reading came from
  - `label` (text, not null) - short name the student gave the reading
  - `settings` (jsonb, not null) - slider values used for the reading
  - `results` (jsonb, not null) - computed readouts at the time of saving
  - `created_at` (timestamptz) - when the reading was saved

2. Security
- Enable RLS on `experiment_readings`.
- Grant SELECT, INSERT, DELETE to `anon` and `authenticated`. The app has no sign-in, so the anon key must be able to read and write its own notebook.
- Policies allow public access because the notebook is intentionally shared and holds no personal data.
*/

CREATE TABLE IF NOT EXISTS experiment_readings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  experiment_slug text NOT NULL,
  label text NOT NULL,
  settings jsonb NOT NULL DEFAULT '{}'::jsonb,
  results jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS experiment_readings_created_at_idx
  ON experiment_readings (created_at DESC);

ALTER TABLE experiment_readings ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, DELETE ON experiment_readings TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_experiment_readings" ON experiment_readings;
CREATE POLICY "anon_select_experiment_readings" ON experiment_readings
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_experiment_readings" ON experiment_readings;
CREATE POLICY "anon_insert_experiment_readings" ON experiment_readings
  FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_experiment_readings" ON experiment_readings;
CREATE POLICY "anon_delete_experiment_readings" ON experiment_readings
  FOR DELETE TO anon, authenticated USING (true);
