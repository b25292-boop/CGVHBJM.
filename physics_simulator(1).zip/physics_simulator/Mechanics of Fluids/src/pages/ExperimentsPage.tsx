import ExperimentGrid from '@/components/ExperimentGrid';

export default function ExperimentsPage() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-12 lg:py-16">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-cyan-300">Simulator</p>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-ink-50 sm:text-4xl">All experiments</h1>
      <p className="mt-3 max-w-2xl text-base leading-relaxed text-ink-300">
        Open any experiment to run it. Each one has sliders, live readings, and step-by-step instructions for class.
      </p>
      <div className="mt-10">
        <ExperimentGrid />
      </div>
    </section>
  );
}
