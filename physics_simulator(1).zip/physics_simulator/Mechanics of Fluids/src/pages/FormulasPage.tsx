import FormulaCard from '@/components/FormulaCard';
import { EXPERIMENTS } from '@/experiments';
import { COMMON_SYMBOLS, FORMULA_REFERENCE } from '@/experiments/formulaReference';

export default function FormulasPage() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-12 lg:py-16">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-cyan-300">Reference</p>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-ink-50 sm:text-4xl">Formula reference</h1>
      <p className="mt-3 max-w-2xl text-base leading-relaxed text-ink-300">
        Every experiment is built on one or two equations. Read each one as a short story: what goes in, what comes
        out, and why. Use the worked example to check your own answers.
      </p>

      <div className="mt-10 rounded-2xl border border-ink-700 bg-ink-850 p-6 sm:p-8">
        <h2 className="text-sm font-semibold uppercase tracking-[0.15em] text-ink-300">Symbols used everywhere</h2>
        <dl className="mt-4 grid gap-x-8 gap-y-3 sm:grid-cols-2">
          {COMMON_SYMBOLS.map((item) => (
            <div key={item.symbol} className="grid grid-cols-[auto_1fr] gap-x-4">
              <dt className="font-mono text-sm text-cyan-300">{item.symbol}</dt>
              <dd className="text-sm leading-relaxed text-ink-200">
                {item.meaning}
                <span className="ml-2 font-mono text-xs text-ink-400">{item.unit}</span>
              </dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="mt-10 space-y-8">
        {EXPERIMENTS.map((experiment, index) => (
          <FormulaCard
            key={experiment.slug}
            experiment={experiment}
            entry={FORMULA_REFERENCE[experiment.slug]}
            index={index}
          />
        ))}
      </div>
    </section>
  );
}
