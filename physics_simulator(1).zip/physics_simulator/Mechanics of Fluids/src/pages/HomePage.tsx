import Hero from '@/components/Hero';
import ExperimentGrid from '@/components/ExperimentGrid';
import { EXPERIMENTS } from '@/experiments';

const STEPS = [
  { title: 'Pick an experiment', body: 'Each one covers a single idea from fluid mechanics.' },
  { title: 'Move the sliders', body: 'Change one setting and watch the fluid and the readouts respond.' },
  { title: 'Save what you find', body: 'Store a reading in your lab notebook to compare later.' },
];

export default function HomePage() {
  return (
    <>
      <Hero />
      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-cyan-300">Experiments</p>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-ink-50 sm:text-3xl">
              {EXPERIMENTS.length} simulations, one idea each
            </h2>
          </div>
          <a href="#/experiments" className="text-sm text-ink-300 transition-colors hover:text-ink-50">
            View all
          </a>
        </div>
        <ExperimentGrid />
      </section>
      <section className="border-t border-ink-700 bg-ink-850/60">
        <div className="mx-auto grid max-w-7xl gap-8 px-6 py-14 md:grid-cols-3">
          {STEPS.map((step, index) => (
            <div key={step.title}>
              <p className="font-mono text-xs text-amber-300">0{index + 1}</p>
              <h3 className="mt-2 text-base font-semibold text-ink-50">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-300">{step.body}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
