import { useState } from 'react';
import { ArrowLeft, Pause, Play, RotateCcw, SearchX } from 'lucide-react';
import FluidCanvas from '@/components/FluidCanvas';
import ControlPanel from '@/components/ControlPanel';
import ReadoutList from '@/components/ReadoutList';
import SaveReadingForm from '@/components/SaveReadingForm';
import TheoryPanel from '@/components/TheoryPanel';
import { ACCENT_STYLES } from '@/components/accentStyles';
import { EXPERIMENTS, getExperiment } from '@/experiments';
import { defaultSettings } from '@/experiments/helpers';
import type { ExperimentDef, Settings } from '@/experiments/types';

interface ExperimentPageProps {
  slug: string;
}

export default function ExperimentPage({ slug }: ExperimentPageProps) {
  const experiment = getExperiment(slug);

  if (!experiment) {
    return (
      <div className="mx-auto flex max-w-xl flex-col items-center px-6 py-24 text-center">
        <SearchX className="h-10 w-10 text-ink-400" aria-hidden />
        <h1 className="mt-5 text-2xl font-semibold text-ink-50">We could not find that experiment</h1>
        <p className="mt-3 text-sm leading-relaxed text-ink-300">
          The link may be out of date. Pick another experiment from the list.
        </p>
        <a
          href="#/experiments"
          className="mt-6 inline-flex items-center gap-2 rounded-lg bg-cyan-400 px-4 py-2 text-sm font-semibold text-ink-950 hover:bg-cyan-300"
        >
          Back to experiments
        </a>
      </div>
    );
  }

  return <ExperimentView key={experiment.slug} experiment={experiment} />;
}

function ExperimentView({ experiment }: { experiment: ExperimentDef }) {
  const [settings, setSettings] = useState<Settings>(() => defaultSettings(experiment));
  const [running, setRunning] = useState(true);
  const [focusKey, setFocusKey] = useState<string | null>(null);
  const style = ACCENT_STYLES[experiment.accent];
  const readouts = experiment.readouts(settings);
  const position = EXPERIMENTS.findIndex((item) => item.slug === experiment.slug) + 1;

  const handleChange = (key: string, value: number | string) => {
    setSettings((previous) => ({ ...previous, [key]: value }));
  };

  const draw = (ctx: CanvasRenderingContext2D, width: number, height: number, time: number) =>
    experiment.draw(ctx, width, height, settings, time);

  return (
    <div className="mx-auto max-w-7xl px-6 py-8 lg:py-12">
      <a
        href="#/experiments"
        className="inline-flex items-center gap-2 text-sm text-ink-300 transition-colors hover:text-ink-50"
      >
        <ArrowLeft className="h-4 w-4" aria-hidden />
        All experiments
      </a>

      <header className="mt-6 max-w-3xl">
        <p className={`font-mono text-xs uppercase tracking-[0.2em] ${style.text}`}>
          Experiment {String(position).padStart(2, '0')}
        </p>
        <h1 className="mt-3 text-3xl font-semibold leading-tight tracking-tight text-ink-50 sm:text-4xl">
          {experiment.title}
        </h1>
      </header>

      <div className="mt-6">
        <TheoryPanel experiment={experiment} focusKey={focusKey} onFocusControl={setFocusKey} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
        <section className="rounded-2xl border border-ink-600 bg-ink-850 p-4 sm:p-6">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h2 className="text-sm font-semibold text-ink-100">Simulation</h2>
            <button
              type="button"
              onClick={() => setRunning((value) => !value)}
              aria-pressed={!running}
              className="inline-flex items-center gap-2 rounded-lg border border-ink-500 bg-ink-800 px-3 py-1.5 text-sm text-ink-100 transition-colors hover:border-ink-400 hover:text-ink-50"
            >
              {running ? <Pause className="h-3.5 w-3.5" aria-hidden /> : <Play className="h-3.5 w-3.5" aria-hidden />}
              {running ? 'Pause' : 'Play'}
            </button>
          </div>
          <FluidCanvas
            height={380}
            running={running}
            draw={draw}
            ariaLabel={`Live simulation: ${experiment.title}`}
          />
          <div className="mt-5">
            <ReadoutList readouts={readouts} />
          </div>
        </section>

        <aside className="flex flex-col gap-8 rounded-2xl border border-ink-600 bg-ink-850 p-6">
          <div>
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-ink-100">Controls</h2>
              <button
                type="button"
                onClick={() => setSettings(defaultSettings(experiment))}
                className="inline-flex items-center gap-1.5 text-xs text-ink-300 transition-colors hover:text-ink-50"
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden />
                Reset
              </button>
            </div>
            <ControlPanel
              controls={experiment.controls}
              settings={settings}
              accent={experiment.accent}
              highlightedKey={focusKey}
              onHighlight={setFocusKey}
              onChange={handleChange}
            />
          </div>
          <div className="border-t border-ink-600 pt-6">
            <SaveReadingForm experiment={experiment} settings={settings} readouts={readouts} />
          </div>
        </aside>
      </div>

      <section className="mt-6 rounded-2xl border border-ink-600 bg-ink-850 p-6 sm:p-8">
        <h2 className="text-lg font-semibold text-ink-50">Step by step</h2>
        <p className="mt-1 text-sm text-ink-300">Follow these steps in order, then try your own ideas.</p>
        <ol className="mt-6 grid gap-4 md:grid-cols-2">
          {experiment.steps.map((step, index) => (
            <li key={step} className="flex gap-4 rounded-xl border border-ink-700 bg-ink-900/60 p-4">
              <span
                className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full border font-mono text-xs ${style.chip}`}
              >
                {index + 1}
              </span>
              <p className="text-sm leading-relaxed text-ink-200">{step}</p>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
