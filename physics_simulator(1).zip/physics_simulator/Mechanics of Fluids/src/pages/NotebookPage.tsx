import { useEffect, useState } from 'react';
import { BookOpen, Loader2, Trash2 } from 'lucide-react';
import { ACCENT_STYLES, TONE_TEXT } from '@/components/accentStyles';
import { getExperiment } from '@/experiments';
import { formatSettings } from '@/experiments/helpers';
import { deleteReading, listReadings, type SavedReading } from '@/lib/readings';

type LoadState =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ready'; readings: SavedReading[] };

export default function NotebookPage() {
  const [loadState, setLoadState] = useState<LoadState>({ status: 'loading' });
  const [actionError, setActionError] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    listReadings()
      .then((readings) => {
        if (active) setLoadState({ status: 'ready', readings });
      })
      .catch((error: unknown) => {
        if (active) {
          setLoadState({
            status: 'error',
            message: error instanceof Error ? error.message : 'Something went wrong.',
          });
        }
      });
    return () => {
      active = false;
    };
  }, []);

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    setActionError('');
    try {
      await deleteReading(id);
      setLoadState((previous) =>
        previous.status === 'ready'
          ? { status: 'ready', readings: previous.readings.filter((reading) => reading.id !== id) }
          : previous,
      );
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Could not delete that reading.');
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <section className="mx-auto max-w-7xl px-6 py-12 lg:py-16">
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-amber-300">Notebook</p>
      <h1 className="mt-2 text-3xl font-semibold tracking-tight text-ink-50 sm:text-4xl">Lab notebook</h1>
      <p className="mt-3 max-w-2xl text-base leading-relaxed text-ink-300">
        Every reading you save from an experiment appears here, with the settings you used and the results.
      </p>

      {actionError && (
        <p role="alert" className="mt-6 rounded-lg border border-red-400/30 bg-red-400/10 px-4 py-3 text-sm text-red-200">
          {actionError}
        </p>
      )}

      <div className="mt-10">
        {loadState.status === 'loading' && (
          <div className="flex items-center gap-3 text-sm text-ink-300">
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
            Loading your readings
          </div>
        )}

        {loadState.status === 'error' && (
          <div className="rounded-2xl border border-red-400/30 bg-red-400/5 p-6">
            <p className="text-base font-semibold text-red-200">The notebook could not be loaded</p>
            <p className="mt-2 text-sm text-ink-300">{loadState.message}</p>
          </div>
        )}

        {loadState.status === 'ready' && loadState.readings.length === 0 && (
          <div className="flex flex-col items-start gap-4 rounded-2xl border border-dashed border-ink-500 bg-ink-850 p-8">
            <BookOpen className="h-8 w-8 text-ink-400" aria-hidden />
            <div>
              <p className="text-base font-semibold text-ink-50">No readings saved yet</p>
              <p className="mt-2 text-sm text-ink-300">Run an experiment and save a reading to see it here.</p>
            </div>
            <a
              href="#/experiments"
              className="rounded-lg bg-cyan-400 px-4 py-2 text-sm font-semibold text-ink-950 hover:bg-cyan-300"
            >
              Browse experiments
            </a>
          </div>
        )}

        {loadState.status === 'ready' && loadState.readings.length > 0 && (
          <ul className="grid gap-4">
            {loadState.readings.map((reading) => {
              const experiment = getExperiment(reading.experimentSlug);
              const style = ACCENT_STYLES[experiment?.accent ?? 'cyan'];
              return (
                <li
                  key={reading.id}
                  className="rounded-2xl border border-ink-600 bg-ink-850 p-5 sm:p-6"
                >
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div className="min-w-0">
                      <p className={`font-mono text-xs uppercase tracking-wider ${style.text}`}>
                        {experiment?.title ?? 'Unknown experiment'}
                      </p>
                      <h2 className="mt-1 text-lg font-semibold text-ink-50">{reading.label}</h2>
                      <p className="mt-1 font-mono text-xs text-ink-400">
                        {new Date(reading.createdAt).toLocaleString('en-GB', {
                          dateStyle: 'medium',
                          timeStyle: 'short',
                        })}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {experiment && (
                        <a
                          href={`#/experiments/${experiment.slug}`}
                          className="rounded-lg border border-ink-500 px-3 py-1.5 text-sm text-ink-100 transition-colors hover:border-ink-400 hover:text-ink-50"
                        >
                          Open
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={() => handleDelete(reading.id)}
                        disabled={deletingId === reading.id}
                        aria-label={`Delete reading ${reading.label}`}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-ink-500 px-3 py-1.5 text-sm text-ink-300 transition-colors hover:border-red-400/50 hover:text-red-300 disabled:opacity-50"
                      >
                        {deletingId === reading.id ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                        ) : (
                          <Trash2 className="h-3.5 w-3.5" aria-hidden />
                        )}
                        Delete
                      </button>
                    </div>
                  </div>

                  {experiment && (
                    <p className="mt-4 text-sm text-ink-300">{formatSettings(experiment, reading.settings)}</p>
                  )}

                  <dl className="mt-4 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-ink-600 bg-ink-600 sm:grid-cols-4">
                    {reading.results.map((result) => (
                      <div key={result.label} className="bg-ink-900 px-4 py-3">
                        <dt className="font-mono text-[11px] uppercase tracking-wider text-ink-400">{result.label}</dt>
                        <dd className={`mt-1 font-mono text-sm ${TONE_TEXT[result.tone ?? 'neutral']}`}>
                          {result.value}
                          {result.unit && <span className="ml-1 text-xs text-ink-400">{result.unit}</span>}
                        </dd>
                      </div>
                    ))}
                  </dl>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </section>
  );
}
