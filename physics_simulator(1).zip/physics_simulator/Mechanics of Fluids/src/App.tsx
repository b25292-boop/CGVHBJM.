import { useEffect } from 'react';
import Header from '@/components/Header';
import ExperimentPage from '@/pages/ExperimentPage';
import ExperimentsPage from '@/pages/ExperimentsPage';
import FormulasPage from '@/pages/FormulasPage';
import HomePage from '@/pages/HomePage';
import NotebookPage from '@/pages/NotebookPage';
import { useRoute, type Route } from '@/lib/router';

function renderRoute(route: Route) {
  switch (route.name) {
    case 'experiments':
      return <ExperimentsPage />;
    case 'experiment':
      return <ExperimentPage slug={route.slug} />;
    case 'formulas':
      return <FormulasPage />;
    case 'notebook':
      return <NotebookPage />;
    case 'home':
      return <HomePage />;
  }
}

export default function App() {
  const route = useRoute();

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [route.key]);

  return (
    <div className="flex min-h-screen flex-col bg-ink-900 text-ink-100">
      <Header activeRoute={route.name} />
      <main className="flex-1">{renderRoute(route)}</main>
      <footer className="border-t border-ink-700">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-6 py-6 text-xs text-ink-400 sm:flex-row sm:items-center sm:justify-between">
          <span className="font-mono tracking-[0.2em]">FLUIDLAB</span>
          <span>Interactive fluid mechanics for Class 11 students.</span>
        </div>
      </footer>
    </div>
  );
}
