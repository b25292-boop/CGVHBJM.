import { useEffect, useState } from 'react';

export type Route =
  | { name: 'home'; key: string }
  | { name: 'experiments'; key: string }
  | { name: 'experiment'; key: string; slug: string }
  | { name: 'formulas'; key: string }
  | { name: 'notebook'; key: string };

export function parseRoute(hash: string): Route {
  const segments = hash.replace(/^#/, '').split('/').filter(Boolean);
  const key = `/${segments.join('/')}`;
  if (segments[0] === 'experiments' && segments[1]) {
    return { name: 'experiment', key, slug: segments[1] };
  }
  if (segments[0] === 'experiments') return { name: 'experiments', key };
  if (segments[0] === 'formulas') return { name: 'formulas', key };
  if (segments[0] === 'notebook') return { name: 'notebook', key };
  return { name: 'home', key: '/' };
}

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(() => parseRoute(window.location.hash));

  useEffect(() => {
    const onChange = () => setRoute(parseRoute(window.location.hash));
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);

  return route;
}
