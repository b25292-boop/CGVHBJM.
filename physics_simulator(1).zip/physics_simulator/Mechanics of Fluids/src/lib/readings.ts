import { supabase } from '@/lib/supabase';
import type { Readout, Settings } from '@/experiments/types';

export interface SavedReading {
  id: string;
  experimentSlug: string;
  label: string;
  settings: Settings;
  results: Readout[];
  createdAt: string;
}

export interface NewReading {
  experimentSlug: string;
  label: string;
  settings: Settings;
  results: Readout[];
}

interface ReadingRow {
  id: string;
  experiment_slug: string;
  label: string;
  settings: Settings;
  results: Readout[];
  created_at: string;
}

const NOT_CONNECTED_MESSAGE = 'The notebook is not connected yet, so readings cannot be saved.';

function requireClient() {
  if (!supabase) throw new Error(NOT_CONNECTED_MESSAGE);
  return supabase;
}

function isReadingRow(value: unknown): value is ReadingRow {
  if (typeof value !== 'object' || value === null) return false;
  const row = value as Record<string, unknown>;
  return (
    typeof row.id === 'string' &&
    typeof row.experiment_slug === 'string' &&
    typeof row.label === 'string' &&
    typeof row.created_at === 'string' &&
    Array.isArray(row.results)
  );
}

export async function listReadings(): Promise<SavedReading[]> {
  const { data, error } = await requireClient()
    .from('experiment_readings')
    .select('id, experiment_slug, label, settings, results, created_at')
    .order('created_at', { ascending: false })
    .limit(200);

  if (error) throw new Error(error.message);
  return (data ?? []).filter(isReadingRow).map((row) => ({
    id: row.id,
    experimentSlug: row.experiment_slug,
    label: row.label,
    settings: row.settings ?? {},
    results: row.results,
    createdAt: row.created_at,
  }));
}

export async function saveReading(reading: NewReading): Promise<void> {
  const { error } = await requireClient().from('experiment_readings').insert({
    experiment_slug: reading.experimentSlug,
    label: reading.label,
    settings: reading.settings,
    results: reading.results,
  });

  if (error) throw new Error(error.message);
}

export async function deleteReading(id: string): Promise<void> {
  const { error } = await requireClient().from('experiment_readings').delete().eq('id', id);
  if (error) throw new Error(error.message);
}
