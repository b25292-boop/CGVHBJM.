import { ArrowUpRight } from 'lucide-react';
import type { ExperimentDef } from '@/experiments/types';
import type { FormulaEntry } from '@/experiments/formulaReference';
import { ACCENT_STYLES } from '@/components/accentStyles';

interface FormulaCardProps {
  experiment: ExperimentDef;
  entry: FormulaEntry;
  index: number;
}

export default function FormulaCard({ experiment, entry, index }: FormulaCardProps) {
  const style = ACCENT_STYLES[experiment.accent];

  return (
    <article className={`rounded-2xl border bg-ink-850 p-6 sm:p-8 ${style.border}`}>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className={`font-mono text-[11px] tracking-wider ${style.text}`}>
            {String(index + 1).padStart(2, '0')}
          </p>
          <h2 className="mt-1 text-xl font-semibold text-ink-50">{experiment.title}</h2>
        </div>
        <a
          href={`#/experiments/${experiment.slug}`}
          className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-sm transition-colors ${style.chip} hover:brightness-110`}
        >
          Open experiment
          <ArrowUpRight className="h-4 w-4" aria-hidden />
        </a>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xl border border-ink-600 bg-ink-900 px-5 py-4">
        <p className={`font-mono text-lg tracking-tight sm:text-xl ${style.text}`}>{experiment.formula}</p>
      </div>

      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        <div>
          <h3 className="text-sm font-semibold uppercase tracking-[0.15em] text-ink-300">What each part means</h3>
          <dl className="mt-3 divide-y divide-ink-700">
            {entry.symbols.map((item) => (
              <div key={item.symbol} className="grid grid-cols-[auto_1fr] gap-x-4 py-3">
                <dt className={`font-mono text-sm ${style.text}`}>{item.symbol}</dt>
                <dd className="text-sm leading-relaxed text-ink-200">
                  {item.meaning}
                  <span className="ml-2 font-mono text-xs text-ink-400">{item.unit}</span>
                </dd>
              </div>
            ))}
          </dl>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-[0.15em] text-ink-300">How to read it</h3>
          <ol className="mt-3 space-y-3">
            {entry.explanation.map((step, stepIndex) => (
              <li key={step} className="flex gap-3 text-sm leading-relaxed text-ink-200">
                <span className={`mt-0.5 font-mono text-xs ${style.text}`}>{stepIndex + 1}</span>
                <span>{step}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>

      <div className={`mt-8 rounded-xl border-l-2 bg-ink-900/60 px-5 py-4 ${style.border}`}>
        <p className={`font-mono text-xs uppercase tracking-[0.15em] ${style.text}`}>Worked example</p>
        <p className="mt-2 text-sm leading-relaxed text-ink-200">{entry.example}</p>
      </div>
    </article>
  );
}
