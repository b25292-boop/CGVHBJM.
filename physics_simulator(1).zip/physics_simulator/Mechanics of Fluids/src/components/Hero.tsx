import { useEffect, useState } from 'react';
import { ArrowRight, BookOpen } from 'lucide-react';
import FluidCanvas from '@/components/FluidCanvas';
import { TONE_DOT } from '@/components/accentStyles';
import { venturi } from '@/experiments/venturi';
import type { Settings } from '@/experiments/types';

const TICK_MS = 120;

export default function Hero() {
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => setTick((value) => value + TICK_MS / 1000), TICK_MS);
    return () => window.clearInterval(timer);
  }, []);

  const speed = 2.4 + 0.9 * Math.sin(tick * 0.6);
  const settings: Settings = { speed, throatRatio: 0.55 };
  const readouts = venturi.readouts(settings).slice(0, 4);
  const draw = (ctx: CanvasRenderingContext2D, width: number, height: number, time: number) =>
    venturi.draw(ctx, width, height, settings, time);

  return (
    <section className="relative overflow-hidden border-b border-ink-700">
      <div
        aria-hidden
        className="pointer-events-none absolute -left-32 -top-40 h-[28rem] w-[28rem] rounded-full bg-cyan-500/10 blur-3xl"
      />
      <div className="relative mx-auto grid max-w-7xl gap-12 px-6 py-16 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:items-center lg:py-24">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full border border-ink-600 bg-ink-850 px-3 py-1 font-mono text-[11px] uppercase tracking-wider text-ink-300">
            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" aria-hidden />
            Fluid mechanics for Class 11
          </p>
          <h1 className="mt-6 text-4xl font-semibold leading-[1.1] tracking-tight text-ink-50 sm:text-5xl lg:text-6xl">
            Run real fluid experiments in your browser
          </h1>
          <p className="mt-6 max-w-md text-base leading-relaxed text-ink-300">
            Nine guided simulations with sliders, live readings, and step-by-step instructions. Change one thing at a
            time and see what the fluid does.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#/experiments"
              className="inline-flex items-center gap-2 rounded-lg bg-cyan-400 px-5 py-2.5 text-sm font-semibold text-ink-950 shadow-glow transition-colors hover:bg-cyan-300"
            >
              Start simulating
              <ArrowRight className="h-4 w-4" aria-hidden />
            </a>
            <a
              href="#/notebook"
              className="inline-flex items-center gap-2 rounded-lg border border-ink-500 bg-ink-850 px-5 py-2.5 text-sm font-medium text-ink-100 transition-colors hover:border-ink-400 hover:text-ink-50"
            >
              <BookOpen className="h-4 w-4" aria-hidden />
              Lab notebook
            </a>
          </div>
        </div>

        <div className="rounded-2xl border border-ink-600 bg-ink-850/80 p-4 shadow-2xl shadow-black/40 sm:p-5">
          <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_200px] xl:items-center">
            <FluidCanvas height={280} running draw={draw} ariaLabel="Animated water flowing through a Venturi tube" />
            <dl className="grid grid-cols-2 gap-x-4 gap-y-4 xl:grid-cols-1">
              {readouts.map((readout) => (
                <div key={readout.label}>
                  <dt className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-ink-300">
                    <span className={`h-2 w-2 rounded-full ${TONE_DOT[readout.tone ?? 'neutral']}`} aria-hidden />
                    {readout.label}
                  </dt>
                  <dd className="mt-1 font-mono text-2xl tabular-nums text-ink-50">
                    {readout.value}
                    {readout.unit && <span className="ml-1 text-sm text-ink-300">{readout.unit}</span>}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
          <p className="mt-4 font-mono text-[11px] text-ink-400">Live demo: Venturi tube, inlet speed varies</p>
        </div>
      </div>
    </section>
  );
}
