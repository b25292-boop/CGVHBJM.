import { Waves } from 'lucide-react';
import type { Route } from '@/lib/router';

interface HeaderProps {
  activeRoute: Route['name'];
}

const NAV_ITEMS = [
  { label: 'Home', href: '#/', route: 'home' },
  { label: 'Experiments', href: '#/experiments', route: 'experiments' },
  { label: 'Formulas', href: '#/formulas', route: 'formulas' },
  { label: 'Notebook', href: '#/notebook', route: 'notebook' },
] as const;

export default function Header({ activeRoute }: HeaderProps) {
  const activeNav = activeRoute === 'experiment' ? 'experiments' : activeRoute;

  return (
    <header className="sticky top-0 z-30 border-b border-ink-700 bg-ink-900/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-6 px-6">
        <a href="#/" className="flex items-center gap-2.5 rounded-lg">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-400/15 ring-1 ring-cyan-400/40">
            <Waves className="h-4.5 w-4.5 text-cyan-300" aria-hidden />
          </span>
          <span className="font-mono text-sm font-semibold tracking-[0.2em] text-ink-50">FLUIDLAB</span>
        </a>

        <nav aria-label="Main" className="flex items-center gap-1 overflow-x-auto">
          {NAV_ITEMS.map((item) => {
            const active = item.route === activeNav;
            return (
              <a
                key={item.route}
                href={item.href}
                aria-current={active ? 'page' : undefined}
                className={`relative whitespace-nowrap rounded-md px-3 py-2 text-sm transition-colors ${
                  active ? 'text-ink-50' : 'text-ink-300 hover:text-ink-50'
                }`}
              >
                {item.label}
                {active && (
                  <span className="absolute inset-x-3 -bottom-px h-0.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                )}
              </a>
            );
          })}
        </nav>

        <a
          href="#/experiments"
          className="hidden whitespace-nowrap rounded-lg bg-cyan-400 px-4 py-2 text-sm font-semibold text-ink-950 transition-colors hover:bg-cyan-300 sm:inline-flex"
        >
          Launch simulator
        </a>
      </div>
    </header>
  );
}
