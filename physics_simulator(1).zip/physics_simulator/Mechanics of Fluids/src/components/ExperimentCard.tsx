import { ArrowUpRight } from 'lucide-react';
import type { ExperimentDef } from '@/experiments/types';
import { defaultSettings, num } from '@/experiments/helpers';
import { ACCENT_STYLES } from '@/components/accentStyles';

interface ExperimentCardProps {
  experiment: ExperimentDef;
  index: number;
}

export default function ExperimentCard({ experiment, index }: ExperimentCardProps) {
  const style = ACCENT_STYLES[experiment.accent];
  const settings = defaultSettings(experiment);
  const readouts = experiment.readouts(settings).slice(0, 2);
  const preview = experiment.controls.find((control) => control.kind === 'slider');
  const previewValue = preview?.kind === 'slider' ? num(settings, preview.key) : 0;
  const previewPercent =
    preview?.kind === 'slider' ? ((previewValue - preview.min) / (preview.max - preview.min)) * 100 : 0;

  return (
    <a
      href={`#/experiments/${experiment.slug}`}
      className={`group flex flex-col rounded-2xl border bg-ink-850 p-5 transition-all duration-300 hover:-translate-y-0.5 ${style.border} ${style.hoverBorder}`}
    >
      <div className="flex items-start justify-between gap-3">
        <span className={`font-mono text-[11px] tracking-wider ${style.text}`}>
          {String(index + 1).padStart(2, '0')}
        </span>
        <ArrowUpRight
          className="h-4 w-4 text-ink-400 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-ink-50"
          aria-hidden
        />
      </div>

      <h3 className="mt-3 text-base font-semibold leading-snug text-ink-50">{experiment.title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-ink-300">{experiment.tagline}</p>

      <dl className="mt-4 space-y-1 font-mono text-sm">
        {readouts.map((readout) => (
          <div key={readout.label} className="flex justify-between gap-3">
            <dt className="text-ink-400">{readout.label}</dt>
            <dd className="text-ink-100">
              {readout.value}
              {readout.unit && <span className="ml-1 text-ink-400">{readout.unit}</span>}
            </dd>
          </div>
        ))}
      </dl>

      {preview?.kind === 'slider' && (
        <div className="mt-auto pt-5">
          <div className="mb-2 flex items-center justify-between text-xs text-ink-300">
            <span>{preview.label}</span>
            <span className={`font-mono ${style.text}`}>
              {previewValue}
              {preview.unit && <span className="ml-1 text-ink-400">{preview.unit}</span>}
            </span>
          </div>
          <div className="relative h-1.5 rounded-full bg-ink-600">
            <div
              className={`absolute inset-y-0 left-0 rounded-full ${style.bar}`}
              style={{ width: `${previewPercent}%` }}
            />
            <div
              className={`absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full ${style.bar}`}
              style={{ left: `${previewPercent}%` }}
            />
          </div>
        </div>
      )}
    </a>
  );
}
