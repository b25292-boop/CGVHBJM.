import type { Accent, ReadoutTone } from '@/experiments/types';

export const ACCENT_STYLES: Record<
  Accent,
  {
    text: string;
    dot: string;
    bar: string;
    slider: string;
    chip: string;
    border: string;
    solid: string;
    hoverBorder: string;
  }
> = {
  cyan: {
    text: 'text-cyan-300',
    dot: 'bg-cyan-400 shadow-[0_0_12px_rgba(34,211,238,0.9)]',
    bar: 'bg-cyan-400',
    slider: 'accent-cyan-400',
    chip: 'border-cyan-400/30 bg-cyan-400/10 text-cyan-300',
    border: 'border-cyan-400/25',
    solid: 'bg-cyan-400 text-ink-950 hover:bg-cyan-300',
    hoverBorder: 'hover:border-cyan-400/60 hover:shadow-glow',
  },
  amber: {
    text: 'text-amber-300',
    dot: 'bg-amber-400 shadow-[0_0_12px_rgba(245,158,11,0.9)]',
    bar: 'bg-amber-400',
    slider: 'accent-amber-400',
    chip: 'border-amber-400/30 bg-amber-400/10 text-amber-300',
    border: 'border-amber-400/25',
    solid: 'bg-amber-400 text-ink-950 hover:bg-amber-300',
    hoverBorder: 'hover:border-amber-400/60 hover:shadow-glow-amber',
  },
};

export const TONE_TEXT: Record<ReadoutTone, string> = {
  cyan: 'text-cyan-300',
  amber: 'text-amber-300',
  neutral: 'text-ink-50',
  danger: 'text-red-300',
};

export const TONE_DOT: Record<ReadoutTone, string> = {
  cyan: 'bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.9)]',
  amber: 'bg-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.9)]',
  neutral: 'bg-ink-400',
  danger: 'bg-red-400',
};
