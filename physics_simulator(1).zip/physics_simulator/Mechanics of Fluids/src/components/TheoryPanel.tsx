import { useState } from 'react';
import { ACCENT_STYLES } from '@/components/accentStyles';
import { FORMULA_REFERENCE, type FormulaSymbol } from '@/experiments/formulaReference';
import type { ExperimentDef } from '@/experiments/types';

interface TheoryPanelProps {
  experiment: ExperimentDef;
  focusKey: string | null;
  onFocusControl: (key: string | null) => void;
}

export default function TheoryPanel({ experiment, focusKey, onFocusControl }: TheoryPanelProps) {
  const style = ACCENT_STYLES[experiment.accent];
  const symbols = FORMULA_REFERENCE[experiment.slug].symbols;
  const [hovered, setHovered] = useState<FormulaSymbol | null>(null);
  const hoveredControl = hovered?.control
    ? experiment.controls.find((control) => control.key === hovered.control)
    : undefined;

  return (
    <section aria-labelledby="theory-heading" className="rounded-2xl border border-ink-600 bg-ink-850 p-5 sm:p-6">
      <div className="flex flex-wrap items-center gap-3">
        <h2 id="theory-heading" className="text-xs font-semibold uppercase tracking-[0.15em] text-ink-300">
          Theory
        </h2>
        <p className="rounded-lg border border-ink-600 bg-ink-900 px-3 py-1 font-mono text-sm text-ink-100">
          {experiment.formula}
        </p>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-ink-300">{experiment.concept}</p>

      <ul className="mt-4 flex flex-wrap gap-2">
        {symbols.map((item) => {
          const linked = item.control !== undefined;
          const active = linked && item.control === focusKey;
          return (
            <li key={item.symbol}>
              <button
                type="button"
                onMouseEnter={() => {
                  setHovered(item);
                  onFocusControl(item.control ?? null);
                }}
                onFocus={() => {
                  setHovered(item);
                  onFocusControl(item.control ?? null);
                }}
                onMouseLeave={() => {
                  setHovered(null);
                  onFocusControl(null);
                }}
                onBlur={() => {
                  setHovered(null);
                  onFocusControl(null);
                }}
                className={`rounded-lg border px-2.5 py-1 font-mono text-sm transition-colors ${
                  active ? style.chip : 'border-ink-600 bg-ink-800 text-ink-200 hover:text-ink-50'
                }`}
              >
                {item.symbol}
              </button>
            </li>
          );
        })}
      </ul>

      <p className="mt-3 min-h-[1.25rem] text-xs leading-relaxed text-ink-300" aria-live="polite">
        {hovered
          ? `${hovered.symbol} means ${hovered.meaning.charAt(0).toLowerCase()}${hovered.meaning.slice(1)} (${hovered.unit}).${
              hoveredControl ? ` Change it with ${hoveredControl.label}.` : ''
            }`
          : 'Hover a symbol to see what it means and which control changes it.'}
      </p>
    </section>
  );
}
