import { ACCENT_STYLES } from '@/components/accentStyles';
import type { Accent, Control, Settings } from '@/experiments/types';
import { num, str } from '@/experiments/helpers';

interface ControlPanelProps {
  controls: Control[];
  settings: Settings;
  accent: Accent;
  highlightedKey: string | null;
  onHighlight: (key: string | null) => void;
  onChange: (key: string, value: number | string) => void;
}

export default function ControlPanel({
  controls,
  settings,
  accent,
  highlightedKey,
  onHighlight,
  onChange,
}: ControlPanelProps) {
  const style = ACCENT_STYLES[accent];

  return (
    <div className="space-y-2">
      {controls.map((control) => {
        const highlighted = control.key === highlightedKey;
        return (
          <div
            key={control.key}
            onMouseEnter={() => onHighlight(control.key)}
            onMouseLeave={() => onHighlight(null)}
            onFocus={() => onHighlight(control.key)}
            onBlur={() => onHighlight(null)}
            className={`-mx-3 rounded-xl border p-3 transition-colors duration-200 ${
              highlighted ? `${style.border} bg-ink-800/70` : 'border-transparent'
            }`}
          >
            {control.kind === 'slider' ? (
              <SliderField control={control} settings={settings} style={style} onChange={onChange} />
            ) : (
              <ChoiceField control={control} settings={settings} style={style} onChange={onChange} />
            )}
          </div>
        );
      })}
    </div>
  );
}

interface FieldProps<T extends Control> {
  control: T;
  settings: Settings;
  style: (typeof ACCENT_STYLES)[Accent];
  onChange: (key: string, value: number | string) => void;
}

function SliderField({ control, settings, style, onChange }: FieldProps<Extract<Control, { kind: 'slider' }>>) {
  const value = num(settings, control.key);
  return (
    <>
      <div className="mb-2 flex items-baseline justify-between">
        <label htmlFor={`control-${control.key}`} className="text-sm font-medium text-ink-100">
          {control.label}
        </label>
        <span className={`font-mono text-sm tabular-nums ${style.text}`}>
          {value.toLocaleString('en-US', { maximumFractionDigits: 2 })}
          {control.unit && <span className="ml-1 text-ink-300">{control.unit}</span>}
        </span>
      </div>
      <input
        id={`control-${control.key}`}
        type="range"
        min={control.min}
        max={control.max}
        step={control.step}
        value={value}
        onChange={(event) => onChange(control.key, Number(event.target.value))}
        className={`w-full cursor-pointer ${style.slider}`}
      />
      <div className="mt-1 flex justify-between font-mono text-[11px] text-ink-400">
        <span>{control.min}</span>
        <span>{control.max}</span>
      </div>
    </>
  );
}

function ChoiceField({ control, settings, style, onChange }: FieldProps<Extract<Control, { kind: 'choice' }>>) {
  const current = str(settings, control.key);
  return (
    <fieldset>
      <legend className="mb-2 text-sm font-medium text-ink-100">{control.label}</legend>
      <div className="flex flex-wrap gap-2">
        {control.options.map((option) => {
          const selected = option.value === current;
          return (
            <button
              key={option.value}
              type="button"
              aria-pressed={selected}
              onClick={() => onChange(control.key, option.value)}
              className={`rounded-lg border px-3 py-1.5 text-sm transition-colors ${
                selected
                  ? style.chip
                  : 'border-ink-600 bg-ink-800 text-ink-200 hover:border-ink-500 hover:text-ink-50'
              }`}
            >
              {option.label}
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}
