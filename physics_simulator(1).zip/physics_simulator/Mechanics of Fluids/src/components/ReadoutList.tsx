import type { Readout } from '@/experiments/types';
import { TONE_TEXT } from '@/components/accentStyles';

interface ReadoutListProps {
  readouts: Readout[];
}

export default function ReadoutList({ readouts }: ReadoutListProps) {
  return (
    <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-ink-600 bg-ink-600 sm:grid-cols-3">
      {readouts.map((readout) => (
        <div key={readout.label} className="bg-ink-850 px-4 py-3">
          <dt className="font-mono text-[11px] uppercase tracking-wider text-ink-300">{readout.label}</dt>
          <dd
            className={`mt-1 font-mono text-xl font-medium leading-tight ${TONE_TEXT[readout.tone ?? 'neutral']} ${
              readout.value.length > 14 ? 'text-sm' : ''
            }`}
          >
            {readout.value}
            {readout.unit && <span className="ml-1 text-xs text-ink-300">{readout.unit}</span>}
          </dd>
        </div>
      ))}
    </dl>
  );
}
