import { useEffect, useRef } from 'react';

type DrawFrame = (ctx: CanvasRenderingContext2D, width: number, height: number, time: number) => void;

interface FluidCanvasProps {
  draw: DrawFrame;
  height: number;
  running: boolean;
  ariaLabel: string;
}

export default function FluidCanvas({ draw, height, running, ariaLabel }: FluidCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawRef = useRef(draw);
  const runningRef = useRef(running);

  useEffect(() => {
    drawRef.current = draw;
    runningRef.current = running;
  }, [draw, running]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    let width = 0;
    let time = 0;
    let last = performance.now();
    let frame = 0;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      width = rect.width;
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const loop = (now: number) => {
      const elapsed = (now - last) / 1000;
      last = now;
      if (runningRef.current) time += elapsed;
      drawRef.current(ctx, width, height, time);
      frame = requestAnimationFrame(loop);
    };

    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    frame = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
    };
  }, [height]);

  return (
    <canvas
      ref={canvasRef}
      role="img"
      aria-label={ariaLabel}
      style={{ height }}
      className="block w-full rounded-xl"
    />
  );
}
