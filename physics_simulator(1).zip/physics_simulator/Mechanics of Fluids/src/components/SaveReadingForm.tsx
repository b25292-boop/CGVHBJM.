import { useState, type FormEvent } from 'react';
import { CheckCircle2, Loader2 } from 'lucide-react';
import type { ExperimentDef, Readout, Settings } from '@/experiments/types';
import { saveReading } from '@/lib/readings';
import { ACCENT_STYLES } from '@/components/accentStyles';

interface SaveReadingFormProps {
  experiment: ExperimentDef;
  settings: Settings;
  readouts: Readout[];
}

type SaveStatus = 'idle' | 'saving' | 'saved' | 'error';

export default function SaveReadingForm({ experiment, settings, readouts }: SaveReadingFormProps) {
  const [label, setLabel] = useState('');
  const [status, setStatus] = useState<SaveStatus>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const style = ACCENT_STYLES[experiment.accent];

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = label.trim();
    if (!trimmed) return;

    setStatus('saving');
    setErrorMessage('');
    try {
      await saveReading({
        experimentSlug: experiment.slug,
        label: trimmed,
        settings,
        results: readouts,
      });
      setStatus('saved');
      setLabel('');
    } catch (error) {
      setStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Something went wrong while saving.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <label htmlFor="reading-label" className="block text-sm font-medium text-ink-100">
        Save this reading
      </label>
      <p className="text-xs text-ink-300">Give it a short name so you can find it in your notebook later.</p>
      <div className="flex gap-2">
        <input
          id="reading-label"
          type="text"
          value={label}
          maxLength={60}
          placeholder="e.g. Trial 3, high speed"
          onChange={(event) => {
            setLabel(event.target.value);
            if (status !== 'idle') setStatus('idle');
          }}
          className="min-w-0 flex-1 rounded-lg border border-ink-600 bg-ink-900 px-3 py-2 text-sm text-ink-50 placeholder:text-ink-400 focus:border-ink-400 focus:outline-none"
        />
        <button
          type="submit"
          disabled={status === 'saving' || label.trim().length === 0}
          className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-40 ${style.solid}`}
        >
          {status === 'saving' && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
          Save
        </button>
      </div>
      {status === 'saved' && (
        <p className="flex items-center gap-2 text-sm text-emerald-300">
          <CheckCircle2 className="h-4 w-4" aria-hidden />
          Saved. <a href="#/notebook" className="underline underline-offset-4 hover:text-emerald-200">Open notebook</a>
        </p>
      )}
      {status === 'error' && <p className="text-sm text-red-300">Could not save: {errorMessage}</p>}
    </form>
  );
}
