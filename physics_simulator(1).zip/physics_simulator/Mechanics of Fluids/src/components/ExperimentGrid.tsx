import { EXPERIMENTS } from '@/experiments';
import ExperimentCard from '@/components/ExperimentCard';

export default function ExperimentGrid() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {EXPERIMENTS.map((experiment, index) => (
        <ExperimentCard key={experiment.slug} experiment={experiment} index={index} />
      ))}
    </div>
  );
}
