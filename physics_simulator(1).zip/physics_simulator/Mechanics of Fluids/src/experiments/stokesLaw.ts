import type { ExperimentDef, Readout } from './types';
import { formatDuration, formatNumber, num, str } from './helpers';
import { PALETTE, drawArrow, drawGlowCircle, drawLabel, paintBackground } from './drawing';
import {
  SYRUP_FLUIDS,
  findSyrupFluid,
  sphereReynolds,
  terminalVelocity,
} from './physics';

const DROP_METRES = 0.2;
const RADIUS_MIN_MM = 0.2;
const RADIUS_MAX_MM = 1.5;

export const stokesLaw: ExperimentDef = {
  slug: 'stokes-law',
  title: "Stokes' Law (Terminal Velocity)",
  tagline: 'Find the steady speed a falling sphere reaches and how size changes it.',
  concept:
    'A falling ball speeds up until the drag from the fluid balances its weight. The speed at that point is the terminal velocity, and it grows with the square of the radius.',
  formula: 'v = (2/9) · (ρball − ρfluid) · g · r² / μ',
  accent: 'cyan',
  controls: [
    {
      kind: 'slider',
      key: 'radius',
      label: 'Ball radius',
      min: RADIUS_MIN_MM,
      max: RADIUS_MAX_MM,
      step: 0.1,
      unit: 'mm',
      defaultValue: 0.6,
    },
    {
      kind: 'slider',
      key: 'ballDensity',
      label: 'Ball density',
      min: 1500,
      max: 8000,
      step: 100,
      unit: 'kg/m³',
      defaultValue: 2500,
    },
    {
      kind: 'choice',
      key: 'fluid',
      label: 'Fluid',
      options: SYRUP_FLUIDS.map((fluid) => ({ value: fluid.id, label: fluid.name })),
      defaultValue: 'glycerin',
    },
  ],
  steps: [
    'Keep the default ball and fluid. Read the terminal speed in the readouts.',
    'Double the ball radius. Look at the graph and check that the speed rises about four times.',
    'Change the ball density and see how the speed changes when the ball is lighter than the fluid.',
    'Switch the fluid to honey and watch the same ball fall far more slowly.',
    'If the Reynolds number is above 1, Stokes law becomes rough. Find the settings where this happens.',
  ],
  readouts(settings) {
    const fluid = findSyrupFluid(str(settings, 'fluid'));
    const radiusM = num(settings, 'radius') / 1000;
    const velocity = terminalVelocity(radiusM, num(settings, 'ballDensity'), fluid.density, fluid.viscosity);
    const reynolds = sphereReynolds(velocity, radiusM, fluid.density, fluid.viscosity);
    const readouts: Readout[] = [
      { label: 'Terminal speed', value: formatNumber(velocity * 100, 2), unit: 'cm/s', tone: 'cyan' },
      { label: 'Time to fall 20 cm', value: formatDuration(DROP_METRES / velocity), tone: 'amber' },
      { label: 'Reynolds number', value: formatNumber(reynolds, 2) },
    ];
    if (reynolds > 1) {
      readouts.push({ label: 'Check', value: 'Stokes law is rough at this speed', tone: 'danger' });
    }
    return readouts;
  },
  draw(ctx, width, height, settings, time) {
    const fluid = findSyrupFluid(str(settings, 'fluid'));
    const radiusMm = num(settings, 'radius');
    const ballDensity = num(settings, 'ballDensity');
    const velocityAt = (mm: number) =>
      terminalVelocity(mm / 1000, ballDensity, fluid.density, fluid.viscosity) * 100;
    const maxSpeed = velocityAt(RADIUS_MAX_MM) * 1.1;

    paintBackground(ctx, width, height);

    const plotLeft = width * 0.12;
    const plotRight = width * 0.6;
    const plotTop = height * 0.12;
    const plotBottom = height * 0.8;
    const toPlotX = (mm: number) =>
      plotLeft + ((mm - RADIUS_MIN_MM) / (RADIUS_MAX_MM - RADIUS_MIN_MM)) * (plotRight - plotLeft);
    const toPlotY = (speed: number) => plotBottom - (speed / maxSpeed) * (plotBottom - plotTop);

    ctx.save();
    ctx.strokeStyle = PALETTE.wall;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(plotLeft, plotTop);
    ctx.lineTo(plotLeft, plotBottom);
    ctx.lineTo(plotRight, plotBottom);
    ctx.stroke();
    ctx.strokeStyle = PALETTE.cyan;
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let i = 0; i <= 60; i++) {
      const mm = RADIUS_MIN_MM + ((RADIUS_MAX_MM - RADIUS_MIN_MM) * i) / 60;
      const px = toPlotX(mm);
      const py = toPlotY(velocityAt(mm));
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();
    ctx.restore();

    drawGlowCircle(ctx, toPlotX(radiusMm), toPlotY(velocityAt(radiusMm)), 5, PALETTE.amber);
    drawLabel(ctx, 'Radius (mm)', (plotLeft + plotRight) / 2, plotBottom + 22, {
      align: 'center',
      size: 11,
      color: PALETTE.muted,
    });
    drawLabel(ctx, 'Speed (cm/s)', plotLeft, plotTop - 14, { size: 11, color: PALETTE.muted });

    const tubeX = width * 0.76;
    const tubeTop = height * 0.12;
    const tubeBottom = height * 0.84;
    const ballPx = 5 + radiusMm * 6;
    const cyclesPerSecond = 0.1 + 0.5 * (velocityAt(radiusMm) / maxSpeed);
    const progress = (time * cyclesPerSecond) % 1;
    const ballY = tubeTop + ballPx + progress * (tubeBottom - tubeTop - ballPx * 2);

    ctx.save();
    ctx.fillStyle = fluid.color;
    ctx.globalAlpha = 0.12;
    ctx.fillRect(tubeX - 40, tubeTop, 80, tubeBottom - tubeTop);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = PALETTE.wall;
    ctx.lineWidth = 2;
    ctx.strokeRect(tubeX - 40, tubeTop, 80, tubeBottom - tubeTop);
    ctx.restore();

    drawGlowCircle(ctx, tubeX, ballY, ballPx, PALETTE.text);
    drawArrow(ctx, tubeX + 56, tubeTop + 10, tubeX + 56, tubeTop + 60, PALETTE.muted);
    drawLabel(ctx, 'g', tubeX + 66, tubeTop + 36, { size: 11, mono: true, color: PALETTE.muted });
    drawLabel(ctx, fluid.name, tubeX, tubeBottom + 22, { align: 'center', size: 12, color: PALETTE.text });
  },
};
