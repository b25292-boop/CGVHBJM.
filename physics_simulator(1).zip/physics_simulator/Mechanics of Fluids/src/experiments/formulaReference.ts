export interface FormulaSymbol {
  symbol: string;
  meaning: string;
  unit: string;
  control?: string;
}

export interface FormulaEntry {
  symbols: FormulaSymbol[];
  explanation: string[];
  example: string;
}

export const COMMON_SYMBOLS: FormulaSymbol[] = [
  { symbol: 'ρ', meaning: 'Density: how much mass is packed into each cubic metre', unit: 'kg/m³' },
  { symbol: 'g', meaning: 'Gravity: pull of the Earth on each kilogram', unit: 'm/s²' },
  { symbol: 'μ', meaning: 'Viscosity: how thick or sticky the fluid is', unit: 'Pa·s' },
  { symbol: 'P', meaning: 'Pressure: force pushing on each square metre', unit: 'Pa' },
  { symbol: 'v', meaning: 'Speed of the fluid or of a falling object', unit: 'm/s' },
  { symbol: 'A', meaning: 'Area of a cross-section, such as a pipe opening', unit: 'm²' },
  { symbol: 'h', meaning: 'Height or depth measured from a fixed level', unit: 'm' },
];

export const FORMULA_REFERENCE: Record<string, FormulaEntry> = {
  'laminar-turbulent': {
    symbols: [
      { symbol: 'Re', meaning: 'Reynolds number: a pure number that predicts the type of flow', unit: 'none' },
      { symbol: 'ρ', meaning: 'Density of the fluid', unit: 'kg/m³' },
      { symbol: 'v', meaning: 'Average speed of the fluid', unit: 'm/s', control: 'speed' },
      { symbol: 'D', meaning: 'Diameter of the pipe', unit: 'm', control: 'diameter' },
      { symbol: 'μ', meaning: 'Viscosity of the fluid', unit: 'Pa·s' },
    ],
    explanation: [
      'Multiply density, speed, and pipe diameter together.',
      'Divide the result by the viscosity.',
      'Below 2300 the flow is smooth and layered (laminar).',
      'Between 2300 and 4000 the flow is unsettled (transitional).',
      'Above 4000 the flow is chaotic and swirling (turbulent).',
    ],
    example:
      'Water (ρ = 998, μ = 0.001) flowing at 0.1 m/s in a 2 cm pipe gives Re = 998 × 0.1 × 0.02 ÷ 0.001 ≈ 2000, so the flow is still laminar.',
  },
  venturi: {
    symbols: [
      { symbol: 'A₁, A₂', meaning: 'Area of the wide part and the narrow part of the pipe', unit: 'm²', control: 'throatRatio' },
      { symbol: 'v₁, v₂', meaning: 'Speed of the water in the wide part and the narrow part', unit: 'm/s', control: 'speed' },
      { symbol: 'P₁, P₂', meaning: 'Pressure in the wide part and the narrow part', unit: 'Pa' },
      { symbol: 'ρ', meaning: 'Density of the water', unit: 'kg/m³' },
    ],
    explanation: [
      'Continuity (first part): the same water passes every section each second, so A₁v₁ = A₂v₂. A narrower section forces the water to move faster.',
      'Bernoulli (second part): in a level pipe, faster water has lower pressure. So P₂ is smaller than P₁ where the pipe narrows.',
      'The pressure difference between the two points therefore reveals the flow speed, which is how a Venturi meter works.',
    ],
    example:
      'If the narrow part has half the area (A₂ = A₁ ÷ 2), the water there moves twice as fast (v₂ = 2v₁).',
  },
  bernoulli: {
    symbols: [
      { symbol: 'P', meaning: 'Pressure energy stored in the fluid', unit: 'Pa' },
      { symbol: '½ρv²', meaning: 'Kinetic energy per cubic metre: energy of motion', unit: 'Pa', control: 'speed' },
      { symbol: 'ρgh', meaning: 'Potential energy per cubic metre: energy of height', unit: 'Pa', control: 'rise' },
      { symbol: 'g', meaning: 'Gravity', unit: 'm/s²' },
    ],
    explanation: [
      'Every term has the unit of pressure, so each one is energy stored in one cubic metre of fluid.',
      'In an ideal flow with no friction, the three terms add up to the same total at every point along a streamline.',
      'If the fluid speeds up or rises, another term must shrink, usually the pressure.',
    ],
    example:
      'If the speed doubles, the kinetic term becomes four times bigger. The pressure must drop by three times the original kinetic term to keep the total the same.',
  },
  'viscosity-comparison': {
    symbols: [
      { symbol: 't', meaning: 'Time the ball takes to fall the distance', unit: 's' },
      { symbol: 'd', meaning: 'Distance the ball falls through the fluid', unit: 'm' },
      { symbol: 'v', meaning: 'Terminal velocity of the ball (from the Stokes law formula)', unit: 'm/s' },
      { symbol: 'μ', meaning: 'Viscosity of the fluid', unit: 'Pa·s' },
    ],
    explanation: [
      'Divide the distance by the terminal velocity to get the fall time: t = d ÷ v.',
      'Terminal velocity is inversely proportional to viscosity (v ∝ 1 ÷ μ), so a thicker fluid gives a slower speed and a longer fall time.',
      'The Stokes formula only holds for slow, smooth flow around the ball.',
    ],
    example:
      'If the viscosity doubles, the terminal velocity halves, and the same distance takes twice as long to fall.',
  },
  'stokes-law': {
    symbols: [
      { symbol: 'v', meaning: 'Terminal velocity: the steady speed the ball reaches', unit: 'm/s' },
      { symbol: 'r', meaning: 'Radius of the ball', unit: 'm', control: 'radius' },
      { symbol: 'ρball, ρfluid', meaning: 'Density of the ball and of the fluid', unit: 'kg/m³', control: 'ballDensity' },
      { symbol: 'g', meaning: 'Gravity', unit: 'm/s²' },
      { symbol: 'μ', meaning: 'Viscosity of the fluid', unit: 'Pa·s' },
    ],
    explanation: [
      'Weight pulls the ball down. Buoyancy and the drag from the fluid push it back up.',
      'Drag grows as the ball speeds up, until drag plus buoyancy exactly equals weight. From then on the speed stays constant: this is the terminal velocity.',
      'Solving that balance gives v = (2/9)(ρball − ρfluid)g r² ÷ μ.',
      'Because the radius is squared, a ball twice as wide falls four times as fast.',
    ],
    example:
      'A ball of radius 1 mm and density 2500 in glycerin (ρ = 1260, μ = 1.4) falls at (2/9) × 1240 × 9.81 × 0.001² ÷ 1.4 ≈ 0.002 m/s, which is 0.2 cm every second.',
  },
  'pressure-depth': {
    symbols: [
      { symbol: 'P', meaning: 'Pressure at the depth (extra pressure from the liquid)', unit: 'Pa' },
      { symbol: 'h', meaning: 'Depth below the surface', unit: 'm', control: 'depth' },
      { symbol: 'ρ', meaning: 'Density of the liquid', unit: 'kg/m³' },
      { symbol: 'g', meaning: 'Gravity', unit: 'm/s²' },
    ],
    explanation: [
      'The weight of the liquid above a point pushes down on it. The weight per square metre is ρgh.',
      'Pressure grows in a straight line with depth. Doubling the depth doubles the extra pressure.',
      'The total (absolute) pressure also includes the air pressure above the surface, about 101.3 kPa.',
    ],
    example:
      'At 10 m in water: P = 998 × 9.81 × 10 ≈ 97.9 kPa of extra pressure. Adding the air pressure gives about 199 kPa in total.',
  },
  archimedes: {
    symbols: [
      { symbol: 'F_b', meaning: 'Buoyant force: the upward push from the fluid', unit: 'N' },
      { symbol: 'ρfluid', meaning: 'Density of the fluid', unit: 'kg/m³', control: 'fluid' },
      { symbol: 'V', meaning: 'Volume of fluid pushed aside (the submerged volume)', unit: 'm³' },
      { symbol: 'g', meaning: 'Gravity', unit: 'm/s²' },
    ],
    explanation: [
      'The upward push equals the weight of the fluid the object displaces.',
      'An object floats when its density is less than the fluid. It then sinks only as far as needed to displace its own weight.',
      'The fraction submerged equals ρobject ÷ ρfluid.',
    ],
    example:
      'Ice (density about 917) in water (998) floats with 917 ÷ 998 ≈ 92% of its volume below the surface.',
  },
  'surface-tension': {
    symbols: [
      { symbol: 'h', meaning: 'Height the liquid climbs inside the tube', unit: 'm' },
      { symbol: 'γ', meaning: 'Surface tension: the skin-like pull of the surface', unit: 'N/m', control: 'liquid' },
      { symbol: 'θ', meaning: 'Contact angle between the liquid and the tube wall', unit: 'degrees' },
      { symbol: 'r', meaning: 'Inner radius of the tube', unit: 'm', control: 'radius' },
      { symbol: 'ρ, g', meaning: 'Density of the liquid and gravity', unit: 'kg/m³, m/s²' },
    ],
    explanation: [
      'Surface tension pulls the liquid up along the wall, around the whole circumference of the tube (2πr).',
      'The liquid column stops rising when its weight (πr²hρg) equals that upward pull.',
      'Balancing the two gives h = 2γ cos θ ÷ (ρgr). A thinner tube (smaller r) gives a higher rise.',
    ],
    example:
      'Water (γ = 0.072 N/m, θ ≈ 0°) in a tube of radius 0.5 mm rises about 0.144 ÷ (998 × 9.81 × 0.0005) ≈ 0.029 m, or 2.9 cm.',
  },
  torricelli: {
    symbols: [
      { symbol: 'v', meaning: 'Speed of water leaving the hole', unit: 'm/s' },
      { symbol: 'h', meaning: 'Height of the water above the hole', unit: 'm', control: 'height' },
      { symbol: 'Q', meaning: 'Flow rate: volume of water leaving each second', unit: 'm³/s' },
      { symbol: 'Cd', meaning: 'Discharge coefficient, about 0.62 for a sharp-edged hole', unit: 'none' },
      { symbol: 'a', meaning: 'Area of the hole', unit: 'm²', control: 'hole' },
    ],
    explanation: [
      'Potential energy at the top (ρgh) turns into kinetic energy at the hole (½ρv²).',
      'Balancing these gives v = √(2gh): the water leaves as fast as a free fall from the surface.',
      'Real holes waste a little energy, so the actual flow is Q = Cd · a · v.',
      'As the water level falls, h gets smaller and the flow slows down.',
    ],
    example:
      'With water 2 m above the hole, v = √(2 × 9.81 × 2) ≈ 6.3 m/s. A 1 cm² hole then gives Q ≈ 0.62 × 0.0001 × 6.3 ≈ 0.00039 m³/s.',
  },
};
