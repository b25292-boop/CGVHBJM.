import type { ExperimentDef, Readout } from './types';
import { formatNumber, num } from './helpers';
import { PALETTE, drawLabel, paintBackground, smoothstep } from './drawing';
import { drawWaterPipe } from './water';
import { WATER_DENSITY } from './physics';

const INLET_PRESSURE_KPA = 120;
const INLET_AREA_M2 = 4e-4;
const VAPOR_PRESSURE_KPA = 2.3;

interface VenturiState {
  throatSpeed: number;
  throatPressure: number;
  pressureDrop: number;
  flowRate: number;
}

export function venturiState(inletSpeed: number, throatRatio: number): VenturiState {
  const areaRatio = 1 / (throatRatio * throatRatio);
  const throatSpeed = inletSpeed * areaRatio;
  const pressureDrop = (0.5 * WATER_DENSITY * (throatSpeed ** 2 - inletSpeed ** 2)) / 1000;
  return {
    throatSpeed,
    throatPressure: INLET_PRESSURE_KPA - pressureDrop,
    pressureDrop,
    flowRate: INLET_AREA_M2 * inletSpeed * 1000 * 60,
  };
}

export const venturi: ExperimentDef = {
  slug: 'venturi',
  title: 'Venturi Tube',
  tagline: 'See fluid speed up and pressure fall as a pipe narrows.',
  concept:
    'When a pipe narrows, the same amount of water must move faster through the narrow part. Faster flow means lower pressure, which is how a Venturi meter measures flow.',
  formula: 'A₁v₁ = A₂v₂   and   P₁ + ½ρv₁² = P₂ + ½ρv₂²',
  accent: 'cyan',
  controls: [
    { kind: 'slider', key: 'speed', label: 'Inlet speed', min: 0.5, max: 5, step: 0.1, unit: 'm/s', defaultValue: 2 },
    {
      kind: 'slider',
      key: 'throatRatio',
      label: 'Throat width ratio',
      min: 0.4,
      max: 0.8,
      step: 0.05,
      unit: '',
      defaultValue: 0.6,
    },
  ],
  steps: [
    'Start with the default settings. Watch the streaks speed up as they enter the narrow throat.',
    'Read the throat velocity and the throat pressure in the readouts.',
    'Make the throat narrower by lowering the width ratio. Notice how the pressure at the throat drops.',
    'Raise the inlet speed. The pressure drop grows much faster than the speed does.',
    'If the throat pressure falls to almost zero, the water can boil. Find the settings where this warning appears.',
  ],
  readouts(settings) {
    const state = venturiState(num(settings, 'speed'), num(settings, 'throatRatio'));
    const readouts: Readout[] = [
      { label: 'Throat velocity', value: formatNumber(state.throatSpeed, 2), unit: 'm/s', tone: 'amber' },
      { label: 'Throat pressure', value: formatNumber(state.throatPressure, 1), unit: 'kPa', tone: 'cyan' },
      { label: 'Pressure drop', value: formatNumber(state.pressureDrop, 1), unit: 'kPa' },
      { label: 'Flow rate', value: formatNumber(state.flowRate, 1), unit: 'L/min' },
    ];
    if (state.throatPressure < VAPOR_PRESSURE_KPA) {
      readouts.push({ label: 'Warning', value: 'Water may boil at the throat', tone: 'danger' });
    }
    return readouts;
  },
  draw(ctx, width, height, settings, time) {
    const inletSpeed = num(settings, 'speed');
    const throatRatio = num(settings, 'throatRatio');
    const state = venturiState(inletSpeed, throatRatio);
    const centerY = height / 2;
    const bigHalf = height * 0.3;
    const smallHalf = bigHalf * throatRatio;
    const halfHeight = (x: number) => {
      const u = x / width;
      const narrowing = smoothstep(0.25, 0.45, u) - smoothstep(0.55, 0.75, u);
      return bigHalf - (bigHalf - smallHalf) * narrowing;
    };

    paintBackground(ctx, width, height);
    drawWaterPipe(ctx, width, () => centerY, halfHeight, time, inletSpeed);

    const manometerX = [width * 0.15, width * 0.5];
    const pressures = [INLET_PRESSURE_KPA, state.throatPressure];
    manometerX.forEach((x, index) => {
      const top = centerY - halfHeight(x) - 8;
      const barHeight = (Math.max(0, pressures[index]) / INLET_PRESSURE_KPA) * height * 0.28;
      ctx.save();
      ctx.fillStyle = index === 0 ? PALETTE.cyan : PALETTE.amber;
      ctx.globalAlpha = 0.85;
      ctx.fillRect(x - 6, top - barHeight, 12, barHeight);
      ctx.restore();
      drawLabel(ctx, `${formatNumber(pressures[index], 1)} kPa`, x, top - barHeight - 14, {
        align: 'center',
        mono: true,
        size: 11,
        color: PALETTE.text,
      });
    });
  },
};
