import type { ExperimentDef } from './types';
import { formatNumber, num } from './helpers';
import { PALETTE, drawLabel, paintBackground, smoothstep } from './drawing';
import { WATER_DENSITY, WATER_VISCOSITY } from './physics';

const PIPE_BLUE = '#2D73C5';
const PIPE_FILL = 'rgba(45, 115, 197, 0.16)';
const PIPE_DARK = 'rgba(29, 91, 165, 0.9)';
const STREAM_BLUE = '#2871C5';
const STREAM_LIGHT = 'rgba(73, 137, 211, 0.72)';

export function reynoldsNumber(speed: number, diameterM: number): number {
  return (WATER_DENSITY * speed * diameterM) / WATER_VISCOSITY;
}

export function regimeOf(reynolds: number): string {
  if (reynolds < 2300) return 'Laminar';
  if (reynolds < 4000) return 'Transitional';
  return 'Turbulent';
}

interface TubeLayout {
  left: number;
  right: number;
  centerY: number;
  inletRadius: number;
  throatRadius: number;
}

function tubeRadiusAt(layout: TubeLayout, x: number): number {
  const progress = (x - layout.left) / (layout.right - layout.left);
  const narrowing = smoothstep(0.12, 0.42, progress) - smoothstep(0.58, 0.88, progress);
  return layout.inletRadius - (layout.inletRadius - layout.throatRadius) * narrowing;
}

function traceTube(ctx: CanvasRenderingContext2D, layout: TubeLayout) {
  const samples = 48;
  ctx.beginPath();
  for (let index = 0; index <= samples; index += 1) {
    const x = layout.left + ((layout.right - layout.left) * index) / samples;
    const y = layout.centerY - tubeRadiusAt(layout, x);
    if (index === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  for (let index = samples; index >= 0; index -= 1) {
    const x = layout.left + ((layout.right - layout.left) * index) / samples;
    ctx.lineTo(x, layout.centerY + tubeRadiusAt(layout, x));
  }
  ctx.closePath();
}

function drawTube(ctx: CanvasRenderingContext2D, layout: TubeLayout) {
  ctx.save();
  traceTube(ctx, layout);
  ctx.fillStyle = PIPE_FILL;
  ctx.fill();
  ctx.strokeStyle = PIPE_BLUE;
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();
}

function drawDashedBoundary(ctx: CanvasRenderingContext2D, x: number, centerY: number, radius: number) {
  ctx.save();
  ctx.strokeStyle = PIPE_DARK;
  ctx.lineWidth = 1.5;
  ctx.setLineDash([2, 6]);
  ctx.beginPath();
  ctx.ellipse(x, centerY, 8, radius, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

function drawLaminarStream(ctx: CanvasRenderingContext2D, layout: TubeLayout, time: number, speed: number, intensity: number) {
  const lines = 8;
  ctx.save();
  ctx.globalAlpha = intensity;
  for (let line = 0; line < lines; line += 1) {
    const fraction = (line + 1) / (lines + 1);
    ctx.save();
    ctx.beginPath();
    for (let sample = 0; sample <= 70; sample += 1) {
      const progress = sample / 70;
      const x = layout.left + progress * (layout.right - layout.left);
      const radius = tubeRadiusAt(layout, x);
      const offset = (fraction - 0.5) * radius * 1.55;
      const y = layout.centerY + offset + Math.sin(progress * 18 + time * speed * 2) * 0.35;
      if (sample === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = line === 3 ? STREAM_BLUE : STREAM_LIGHT;
    ctx.lineWidth = line === 3 ? 2 : 1.5;
    ctx.stroke();
    ctx.restore();
  }

  const arrowX = layout.left + (layout.right - layout.left) * 0.52;
  for (let line = 1; line < lines; line += 1) {
    const offset = ((line / (lines + 1)) - 0.5) * tubeRadiusAt(layout, arrowX) * 1.55;
    const arrowY = layout.centerY + offset;
    ctx.save();
    ctx.fillStyle = STREAM_BLUE;
    ctx.beginPath();
    ctx.moveTo(arrowX + 14, arrowY);
    ctx.lineTo(arrowX + 3, arrowY - 5);
    ctx.lineTo(arrowX + 3, arrowY + 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
}

function drawTurbulentStream(ctx: CanvasRenderingContext2D, layout: TubeLayout, time: number, speed: number, intensity: number) {
  const paths = 7;
  ctx.save();
  ctx.globalAlpha = intensity;
  for (let path = 0; path < paths; path += 1) {
    const phase = path * 1.17;
    ctx.save();
    ctx.beginPath();
    for (let sample = 0; sample <= 80; sample += 1) {
      const progress = sample / 80;
      const x = layout.left + progress * (layout.right - layout.left);
      const radius = tubeRadiusAt(layout, x) * 0.86;
      const wave = Math.sin(progress * 26 + phase - time * speed * 3.4);
      const secondary = Math.sin(progress * 49 - phase * 1.8 + time * speed * 2.1);
      const offset = (wave * 0.55 + secondary * 0.25) * radius;
      const y = layout.centerY + offset;
      if (sample === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = path % 2 === 0 ? STREAM_BLUE : STREAM_LIGHT;
    ctx.lineWidth = path % 2 === 0 ? 1.7 : 1.2;
    ctx.stroke();
    ctx.restore();
  }

  const arrows = [0.19, 0.34, 0.5, 0.67, 0.82];
  arrows.forEach((progress, index) => {
    const x = layout.left + progress * (layout.right - layout.left);
    const radius = tubeRadiusAt(layout, x) * 0.74;
    const y = layout.centerY + Math.sin(progress * 26 + index * 1.17 - time * speed * 3.4) * radius * 0.55;
    const direction = index % 2 === 0 ? 1 : -1;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(direction * (0.35 + Math.sin(time * 2 + index) * 0.25));
    ctx.fillStyle = STREAM_BLUE;
    ctx.beginPath();
    ctx.moveTo(10, 0);
    ctx.lineTo(-3, -5);
    ctx.lineTo(-1, 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  });
  ctx.restore();
}



export const laminarTurbulent: ExperimentDef = {
  slug: 'laminar-turbulent',
  title: 'Laminar vs. Turbulent Flow',
  tagline: 'Watch a smooth stream turn wavy, then tangled, as the speed rises.',
  concept:
    'Water in a pipe can flow in smooth, orderly layers or in chaotic swirls. The Reynolds number tells you which one you will see.',
  formula: 'Re = ρ · v · D / μ',
  accent: 'cyan',
  controls: [
    { kind: 'slider', key: 'speed', label: 'Flow speed', min: 0.1, max: 4, step: 0.1, unit: 'm/s', defaultValue: 1 },
    { kind: 'slider', key: 'diameter', label: 'Pipe diameter', min: 0.5, max: 4, step: 0.1, unit: 'cm', defaultValue: 2 },
  ],
  steps: [
    'Set the flow speed low. The water should flow in smooth, orderly layers — that is laminar flow.',
    'Slowly raise the speed. Watch the Reynolds number climb as you increase it.',
    'When the Reynolds number passes 2300, the stream starts to wave and mix — that is transitional flow.',
    'Keep raising it past 4000. The stream breaks into chaotic, tangled swirls — that is turbulent flow.',
    'Change the pipe diameter. A wider pipe becomes turbulent at a lower speed.',
    'Write down the speed where the flow first turns turbulent, and compare it with your classmates.',
  ],
  readouts(settings) {
    const speed = num(settings, 'speed');
    const diameterM = num(settings, 'diameter') / 100;
    const reynolds = reynoldsNumber(speed, diameterM);
    const flowLitresPerMinute = Math.PI * (diameterM / 2) ** 2 * speed * 1000 * 60;
    return [
      { label: 'Reynolds number', value: formatNumber(reynolds, 0), tone: 'cyan' },
      { label: 'Flow regime', value: regimeOf(reynolds), tone: 'amber' },
      { label: 'Flow rate', value: formatNumber(flowLitresPerMinute, 1), unit: 'L/min' },
    ];
  },
  draw(ctx, width, height, settings, time) {
    const speed = num(settings, 'speed');
    const diameterCm = num(settings, 'diameter');
    const reynolds = reynoldsNumber(speed, diameterCm / 100);
    const activeRegime = regimeOf(reynolds);
    const turbulence = smoothstep(2300, 4000, reynolds);
    const sidePadding = Math.min(28, width * 0.08);
    const centerY = height * 0.54;
    const tubeWidth = width - sidePadding * 2;
    const diameterFraction = (diameterCm - 0.5) / (4 - 0.5);
    const inletRadius = Math.max(20, height * (0.07 + 0.15 * diameterFraction));
    const throatRadius = inletRadius * 0.54;
    const layout: TubeLayout = {
      left: sidePadding,
      right: sidePadding + tubeWidth,
      centerY,
      inletRadius,
      throatRadius,
    };

    paintBackground(ctx, width, height);
    drawLabel(ctx, `Re ${formatNumber(reynolds, 0)} · ${activeRegime.toUpperCase()}`, 16, 18, {
      color: PALETTE.amber,
      mono: true,
      size: 11,
    });

    drawTube(ctx, layout);
    drawDashedBoundary(ctx, layout.left, layout.centerY, layout.inletRadius);
    drawDashedBoundary(ctx, layout.right, layout.centerY, layout.inletRadius);
    if (turbulence < 1) drawLaminarStream(ctx, layout, time, speed, 1 - turbulence);
    if (turbulence > 0) drawTurbulentStream(ctx, layout, time, speed, turbulence);

    drawLabel(ctx, `${activeRegime} flow`, layout.left + 4, layout.centerY - layout.inletRadius - 28, {
      color: PALETTE.text,
      size: 22,
    });
    drawLabel(ctx, 'LIVE', layout.left + 6, layout.centerY + layout.inletRadius + 26, {
      color: PALETTE.amber,
      mono: true,
      size: 10,
    });
    drawLabel(ctx, `Pipe diameter ${formatNumber(diameterCm, 1)} cm`, width / 2, height - 18, {
      color: PALETTE.muted,
      align: 'center',
      size: 11,
    });
  },
};
