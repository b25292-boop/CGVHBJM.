import type { ExperimentDef, Readout } from './types';
import { formatNumber, num, str } from './helpers';
import { PALETTE, drawLabel, paintBackground } from './drawing';
import { GRAVITY } from './physics';

const LIQUIDS = [
  { id: 'water', label: 'Water', tension: 0.072, density: 998, color: '#22D3EE' },
  { id: 'soapy', label: 'Soapy water', tension: 0.04, density: 1000, color: '#F59E0B' },
  { id: 'ethanol', label: 'Ethanol', tension: 0.022, density: 789, color: '#34D399' },
] as const;

const MAX_DISPLAY_RISE_MM = 80;

function liquidFor(id: string) {
  return LIQUIDS.find((liquid) => liquid.id === id) ?? LIQUIDS[0];
}

function riseMillimetres(tension: number, density: number, radiusM: number): number {
  return ((2 * tension) / (density * GRAVITY * radiusM)) * 1000;
}

export const surfaceTension: ExperimentDef = {
  slug: 'surface-tension',
  title: 'Surface Tension & Capillary Rise',
  tagline: 'See how thin tubes pull liquid upward against gravity.',
  concept:
    'Surface tension is the skin-like pull at a liquid surface. In a thin tube it lifts the liquid up the walls, and the thinner the tube, the higher the liquid climbs.',
  formula: 'h = 2γ cos θ / (ρ · g · r)',
  accent: 'cyan',
  controls: [
    {
      kind: 'slider',
      key: 'radius',
      label: 'Tube radius',
      min: 0.2,
      max: 2,
      step: 0.1,
      unit: 'mm',
      defaultValue: 0.5,
    },
    {
      kind: 'choice',
      key: 'liquid',
      label: 'Liquid',
      options: LIQUIDS.map((liquid) => ({ value: liquid.id, label: liquid.label })),
      defaultValue: 'water',
    },
  ],
  steps: [
    'Start with water in a 0.5 mm tube. Read how high the water climbs.',
    'Make the tube narrower. The rise gets bigger, because the pull acts on a smaller area of liquid.',
    'Switch to soapy water. Its lower surface tension means a smaller rise.',
    'Compare the force holding up the column with the weight of the column. Which is bigger?',
    'Predict the rise for a 0.2 mm tube before changing the setting, then check your answer.',
  ],
  readouts(settings) {
    const liquid = liquidFor(str(settings, 'liquid'));
    const radiusM = num(settings, 'radius') / 1000;
    const rise = riseMillimetres(liquid.tension, liquid.density, radiusM);
    const force = 2 * Math.PI * radiusM * liquid.tension * 1000;
    const readouts: Readout[] = [
      { label: 'Rise height', value: formatNumber(rise, 1), unit: 'mm', tone: 'cyan' },
      { label: 'Pulling force', value: formatNumber(force, 2), unit: 'mN', tone: 'amber' },
      { label: 'Tube diameter', value: formatNumber(radiusM * 2000, 1), unit: 'mm' },
      { label: 'Surface tension', value: formatNumber(liquid.tension * 1000, 1), unit: 'mN/m' },
    ];
    return readouts;
  },
  draw(ctx, width, height, settings) {
    const liquid = liquidFor(str(settings, 'liquid'));
    const radiusM = num(settings, 'radius') / 1000;
    const rise = riseMillimetres(liquid.tension, liquid.density, radiusM);
    const tubeHalf = 6 + num(settings, 'radius') * 18;
    const centerX = width / 2;
    const levelY = height * 0.8;
    const tubeTop = height * 0.1;
    const scale = (levelY - tubeTop - 24) / MAX_DISPLAY_RISE_MM;
    const columnTop = levelY - Math.min(rise, MAX_DISPLAY_RISE_MM) * scale;

    paintBackground(ctx, width, height);

    ctx.save();
    ctx.fillStyle = liquid.color;
    ctx.globalAlpha = 0.18;
    ctx.fillRect(width * 0.15, levelY, width * 0.7, height * 0.92 - levelY);
    ctx.restore();

    ctx.save();
    ctx.strokeStyle = PALETTE.wall;
    ctx.lineWidth = 2;
    ctx.strokeRect(width * 0.15, levelY - height * 0.04, width * 0.7, height * 0.92 - levelY + height * 0.04);
    ctx.restore();

    ctx.save();
    ctx.strokeStyle = PALETTE.wall;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(centerX - tubeHalf, tubeTop);
    ctx.lineTo(centerX - tubeHalf, levelY + height * 0.1);
    ctx.moveTo(centerX + tubeHalf, tubeTop);
    ctx.lineTo(centerX + tubeHalf, levelY + height * 0.1);
    ctx.stroke();
    ctx.restore();

    ctx.save();
    ctx.fillStyle = liquid.color;
    ctx.globalAlpha = 0.55;
    ctx.fillRect(centerX - tubeHalf + 2, columnTop, tubeHalf * 2 - 4, levelY - columnTop);
    ctx.beginPath();
    ctx.ellipse(centerX, columnTop, tubeHalf - 2, 4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    drawLabel(ctx, `${formatNumber(rise, 1)} mm`, centerX + tubeHalf + 14, (columnTop + levelY) / 2, {
      mono: true,
      size: 12,
      color: PALETTE.text,
    });
    drawLabel(ctx, liquid.label, width * 0.2, levelY + height * 0.1, { size: 12, color: PALETTE.text });
  },
};
