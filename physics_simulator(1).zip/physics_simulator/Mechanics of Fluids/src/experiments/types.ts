export type Settings = Record<string, number | string>;

export interface SliderControl {
  kind: 'slider';
  key: string;
  label: string;
  min: number;
  max: number;
  step: number;
  unit: string;
  defaultValue: number;
}

export interface ChoiceControl {
  kind: 'choice';
  key: string;
  label: string;
  options: { value: string; label: string }[];
  defaultValue: string;
}

export type Control = SliderControl | ChoiceControl;

export type Accent = 'cyan' | 'amber';

export type ReadoutTone = 'cyan' | 'amber' | 'neutral' | 'danger';

export interface Readout {
  label: string;
  value: string;
  unit?: string;
  tone?: ReadoutTone;
}

export interface ExperimentDef {
  slug: string;
  title: string;
  tagline: string;
  concept: string;
  formula: string;
  accent: Accent;
  controls: Control[];
  steps: string[];
  readouts: (settings: Settings) => Readout[];
  draw: (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    settings: Settings,
    time: number,
  ) => void;
}
