import type { ExperimentDef, Readout } from './types';
import { formatDuration, formatNumber, num } from './helpers';
import { PALETTE, drawGlowCircle, drawLabel, paintBackground } from './drawing';
import { BALL_DENSITY, SYRUP_FLUIDS, terminalVelocity } from './physics';

const DROP_METRES = 0.2;

export const viscosityComparison: ExperimentDef = {
  slug: 'viscosity-comparison',
  title: 'Viscosity Comparison',
  tagline: 'Drop the same ball into three fluids and see which one slows it most.',
  concept:
    'Viscosity measures how thick and sticky a fluid is. The same ball falls much more slowly through a more viscous fluid.',
  formula: 'Fall time = distance ÷ terminal velocity',
  accent: 'amber',
  controls: [
    { kind: 'slider', key: 'radius', label: 'Ball radius', min: 0.2, max: 1.2, step: 0.1, unit: 'mm', defaultValue: 0.6 },
  ],
  steps: [
    'Look at the three tubes. The same ball is dropped into each one.',
    'Read the fall times in the readouts. The most viscous fluid takes the longest.',
    'Increase the ball radius. The times get shorter, because a bigger ball falls faster.',
    'Rank the three fluids from least to most viscous, then check the viscosity values in the concept notes.',
    'Note that the animation is sped up. Only the readout times are to scale.',
  ],
  readouts(settings) {
    const radiusM = num(settings, 'radius') / 1000;
    return SYRUP_FLUIDS.map((fluid): Readout => {
      const velocity = terminalVelocity(radiusM, BALL_DENSITY, fluid.density, fluid.viscosity);
      return {
        label: `${fluid.name} fall time`,
        value: formatDuration(DROP_METRES / velocity),
        tone: 'neutral',
      };
    });
  },
  draw(ctx, width, height, settings, time) {
    const radiusM = num(settings, 'radius') / 1000;
    const velocities = SYRUP_FLUIDS.map((fluid) =>
      terminalVelocity(radiusM, BALL_DENSITY, fluid.density, fluid.viscosity),
    );
    const maxVelocity = Math.max(...velocities);
    const ballPx = 5 + num(settings, 'radius') * 5;
    const tubeTop = height * 0.14;
    const tubeBottom = height * 0.84;
    const tubeWidth = width * 0.2;

    paintBackground(ctx, width, height);

    SYRUP_FLUIDS.forEach((fluid, index) => {
      const x0 = width * (0.1 + index * 0.3);
      const xCenter = x0 + tubeWidth / 2;
      const travel = tubeBottom - tubeTop - ballPx * 2;
      const cyclesPerSecond = 0.35 * (velocities[index] / maxVelocity) ** 0.4;
      const progress = (time * cyclesPerSecond) % 1;
      const ballY = tubeTop + ballPx + progress * travel;

      ctx.save();
      ctx.fillStyle = fluid.color;
      ctx.globalAlpha = 0.12;
      ctx.fillRect(x0, tubeTop, tubeWidth, tubeBottom - tubeTop);
      ctx.restore();

      ctx.save();
      ctx.strokeStyle = PALETTE.wall;
      ctx.lineWidth = 2;
      ctx.strokeRect(x0, tubeTop, tubeWidth, tubeBottom - tubeTop);
      ctx.restore();

      drawGlowCircle(ctx, xCenter, ballY, ballPx, PALETTE.text);
      drawLabel(ctx, fluid.name, xCenter, tubeBottom + 20, { align: 'center', size: 13, color: PALETTE.text });
      drawLabel(ctx, `μ = ${formatNumber(fluid.viscosity, 2)} Pa·s`, xCenter, tubeBottom + 38, {
        align: 'center',
        size: 11,
        mono: true,
        color: fluid.color,
      });
    });
  },
};
