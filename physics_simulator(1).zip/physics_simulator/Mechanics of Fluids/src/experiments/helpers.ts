import type { ExperimentDef, Settings } from './types';

export function num(settings: Settings, key: string): number {
  const value = settings[key];
  return typeof value === 'number' ? value : Number(value);
}

export function str(settings: Settings, key: string): string {
  return String(settings[key]);
}

export function defaultSettings(def: ExperimentDef): Settings {
  return Object.fromEntries(def.controls.map((control) => [control.key, control.defaultValue]));
}

export function formatNumber(value: number, digits = 2): string {
  return value.toLocaleString('en-US', { maximumFractionDigits: digits });
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds)) return 'Never';
  if (seconds < 60) return `${formatNumber(seconds, 1)} s`;
  if (seconds < 3600) return `${formatNumber(seconds / 60, 1)} min`;
  return `${formatNumber(seconds / 3600, 1)} h`;
}

export function formatSettings(def: ExperimentDef, settings: Settings): string {
  return def.controls
    .map((control) => {
      if (control.kind === 'slider') {
        return `${control.label}: ${formatNumber(num(settings, control.key), 2)} ${control.unit}`.trim();
      }
      const option = control.options.find((item) => item.value === str(settings, control.key));
      return `${control.label}: ${option?.label ?? str(settings, control.key)}`;
    })
    .join(' · ');
}
