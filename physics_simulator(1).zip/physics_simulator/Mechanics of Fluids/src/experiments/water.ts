import { PALETTE } from './drawing';

export interface WaterPoint {
  x: number;
  y: number;
  r: number;
}

interface Normal {
  nx: number;
  ny: number;
}

function normalsOf(path: WaterPoint[]): Normal[] {
  return path.map((point, i) => {
    const before = path[Math.max(0, i - 1)];
    const after = path[Math.min(path.length - 1, i + 1)];
    const dx = after.x - before.x;
    const dy = after.y - before.y;
    const length = Math.hypot(dx, dy) || 1;
    return { nx: -dy / length, ny: dx / length };
  });
}

function pointAt(point: WaterPoint, normal: Normal, offset: number): [number, number] {
  return [point.x + normal.nx * offset, point.y + normal.ny * offset];
}

function traceBand(ctx: CanvasRenderingContext2D, path: WaterPoint[], normals: Normal[], center: number, half: number) {
  ctx.beginPath();
  path.forEach((point, i) => {
    const [x, y] = pointAt(point, normals[i], point.r * (center + half));
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  for (let i = path.length - 1; i >= 0; i--) {
    const [x, y] = pointAt(path[i], normals[i], path[i].r * (center - half));
    ctx.lineTo(x, y);
  }
  ctx.closePath();
}

function traceCenterline(ctx: CanvasRenderingContext2D, path: WaterPoint[], normals: Normal[], center: number) {
  ctx.beginPath();
  path.forEach((point, i) => {
    const [x, y] = pointAt(point, normals[i], point.r * center);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
}

export function drawWaterBody(ctx: CanvasRenderingContext2D, path: WaterPoint[], time: number, speed: number) {
  if (path.length < 2) return;
  const normals = normalsOf(path);

  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  traceBand(ctx, path, normals, 0, 1);
  ctx.fillStyle = 'rgba(14, 116, 144, 0.55)';
  ctx.fill();

  traceBand(ctx, path, normals, -0.15, 0.6);
  ctx.fillStyle = 'rgba(56, 189, 248, 0.3)';
  ctx.fill();

  traceBand(ctx, path, normals, -0.5, 0.14);
  ctx.fillStyle = 'rgba(224, 247, 255, 0.45)';
  ctx.fill();

  traceBand(ctx, path, normals, 0, 1);
  ctx.strokeStyle = 'rgba(186, 230, 253, 0.35)';
  ctx.lineWidth = 1;
  ctx.stroke();

  traceCenterline(ctx, path, normals, -0.45);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
  ctx.lineWidth = 1.5;
  ctx.setLineDash([14, 46]);
  ctx.lineDashOffset = -time * speed * 50;
  ctx.stroke();

  ctx.restore();
}

export function drawWaterPipe(
  ctx: CanvasRenderingContext2D,
  width: number,
  center: (x: number) => number,
  half: (x: number) => number,
  time: number,
  speed: number,
) {
  const steps = Math.ceil(width / 6);
  const path: WaterPoint[] = Array.from({ length: steps + 1 }, (_, i) => {
    const x = (i / steps) * width;
    return { x, y: center(x), r: half(x) };
  });
  drawWaterBody(ctx, path, time, speed);

  ctx.save();
  ctx.strokeStyle = PALETTE.wall;
  ctx.lineWidth = 2;
  ctx.beginPath();
  path.forEach((point, i) => {
    if (i === 0) ctx.moveTo(point.x, point.y - point.r);
    else ctx.lineTo(point.x, point.y - point.r);
  });
  for (let i = path.length - 1; i >= 0; i--) {
    ctx.lineTo(path[i].x, path[i].y + path[i].r);
  }
  ctx.stroke();
  ctx.restore();
}
