import type { ExperimentDef, Readout } from './types';
import { formatNumber, num } from './helpers';
import { PALETTE, drawLabel, paintBackground, smoothstep } from './drawing';
import { drawWaterPipe } from './water';
import { GRAVITY, WATER_DENSITY } from './physics';

const INLET_PRESSURE_KPA = 120;
const MAX_RISE_M = 3;

interface BernoulliState {
  outletSpeed: number;
  outletPressure: number;
  inletEnergy: number;
  outletEnergy: number;
}

export function bernoulliState(inletSpeed: number, riseM: number, areaRatio: number): BernoulliState {
  const outletSpeed = inletSpeed * areaRatio;
  const kineticKpa = (0.5 * WATER_DENSITY * inletSpeed ** 2) / 1000;
  const outletKineticKpa = (0.5 * WATER_DENSITY * outletSpeed ** 2) / 1000;
  const elevationKpa = (WATER_DENSITY * GRAVITY * riseM) / 1000;
  const outletPressure = INLET_PRESSURE_KPA + kineticKpa - outletKineticKpa - elevationKpa;
  return {
    outletSpeed,
    outletPressure,
    inletEnergy: INLET_PRESSURE_KPA + kineticKpa,
    outletEnergy: outletPressure + outletKineticKpa + elevationKpa,
  };
}

export const bernoulli: ExperimentDef = {
  slug: 'bernoulli',
  title: "Bernoulli's Principle",
  tagline: 'Trade pressure for speed and height and check the energy balance.',
  concept:
    'In a flowing fluid, pressure, speed, and height exchange energy. The total energy per cubic metre stays the same along the pipe, so any gain in speed or height costs pressure.',
  formula: 'P + ½ρv² + ρgh = constant',
  accent: 'amber',
  controls: [
    { kind: 'slider', key: 'speed', label: 'Inlet speed', min: 0.5, max: 5, step: 0.1, unit: 'm/s', defaultValue: 2 },
    { kind: 'slider', key: 'rise', label: 'Height rise', min: 0, max: MAX_RISE_M, step: 0.1, unit: 'm', defaultValue: 1.5 },
    {
      kind: 'slider',
      key: 'narrowing',
      label: 'Outlet area ratio',
      min: 1,
      max: 4,
      step: 0.1,
      unit: 'x',
      defaultValue: 2,
    },
  ],
  steps: [
    'Set the height rise to 0 and the narrowing to 1. The pressure should be the same at both ends.',
    'Raise the pipe. Read how the outlet pressure drops by about 9.8 kPa for every metre of height.',
    'Set the narrowing to 2. Watch the outlet speed double and the outlet pressure fall.',
    'Compare the energy totals at the inlet and the outlet. They should match.',
    'Find a setting where the outlet pressure is lower than the inlet pressure because of height alone.',
  ],
  readouts(settings) {
    const state = bernoulliState(num(settings, 'speed'), num(settings, 'rise'), num(settings, 'narrowing'));
    const readouts: Readout[] = [
      { label: 'Inlet pressure', value: formatNumber(INLET_PRESSURE_KPA, 1), unit: 'kPa', tone: 'cyan' },
      { label: 'Outlet pressure', value: formatNumber(state.outletPressure, 1), unit: 'kPa', tone: 'amber' },
      { label: 'Outlet speed', value: formatNumber(state.outletSpeed, 2), unit: 'm/s' },
      { label: 'Energy at inlet', value: formatNumber(state.inletEnergy, 1), unit: 'kPa' },
      { label: 'Energy at outlet', value: formatNumber(state.outletEnergy, 1), unit: 'kPa' },
    ];
    return readouts;
  },
  draw(ctx, width, height, settings, time) {
    const inletSpeed = num(settings, 'speed');
    const riseM = num(settings, 'rise');
    const narrowing = num(settings, 'narrowing');
    const baseY = height * 0.78;
    const riseScale = (height * 0.45) / MAX_RISE_M;
    const inletHalf = height * 0.07;
    const outletHalf = inletHalf / Math.sqrt(narrowing);
    const riseAt = (x: number) => riseM * riseScale * smoothstep(0.2, 0.8, x / width);
    const centerY = (x: number) => baseY - riseAt(x);
    const halfAt = (x: number) => inletHalf - (inletHalf - outletHalf) * smoothstep(0.3, 0.7, x / width);

    paintBackground(ctx, width, height);
    drawWaterPipe(ctx, width, centerY, halfAt, time, inletSpeed);

    const state = bernoulliState(inletSpeed, riseM, narrowing);
    const gauges = [
      { x: width * 0.12, pressure: INLET_PRESSURE_KPA, color: PALETTE.cyan },
      { x: width * 0.88, pressure: state.outletPressure, color: PALETTE.amber },
    ];
    gauges.forEach((gauge) => {
      const top = centerY(gauge.x) - halfAt(gauge.x) - 8;
      const barHeight = (Math.max(0, gauge.pressure) / INLET_PRESSURE_KPA) * height * 0.3;
      ctx.save();
      ctx.fillStyle = gauge.color;
      ctx.globalAlpha = 0.85;
      ctx.fillRect(gauge.x - 6, top - barHeight, 12, barHeight);
      ctx.restore();
      drawLabel(ctx, `${formatNumber(gauge.pressure, 1)} kPa`, gauge.x, top - barHeight - 14, {
        align: 'center',
        mono: true,
        size: 11,
        color: PALETTE.text,
      });
    });
  },
};
