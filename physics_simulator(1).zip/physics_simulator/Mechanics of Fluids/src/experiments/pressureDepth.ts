import type { ExperimentDef } from './types';
import { formatNumber, num, str } from './helpers';
import { PALETTE, drawArrow, drawLabel, paintBackground } from './drawing';
import { ATMOSPHERE_KPA, GRAVITY } from './physics';

const LIQUIDS = [
  { id: 'fresh', label: 'Fresh water', density: 1000, color: '#22D3EE' },
  { id: 'sea', label: 'Sea water', density: 1025, color: '#2DD4BF' },
  { id: 'oil', label: 'Light oil', density: 850, color: '#F59E0B' },
  { id: 'mercury', label: 'Mercury', density: 13546, color: '#CBD5E1' },
] as const;

const MAX_DEPTH_M = 12;

function liquidFor(id: string) {
  return LIQUIDS.find((liquid) => liquid.id === id) ?? LIQUIDS[0];
}

export const pressureDepth: ExperimentDef = {
  slug: 'pressure-depth',
  title: 'Pressure with Depth',
  tagline: 'Open three outlets and watch deeper water push farther.',
  concept: 'Liquid pressure increases with depth because each lower point carries the weight of more liquid above it. The deeper outlet produces the fastest, longest jet.',
  formula: 'P = ρ · g · h',
  accent: 'cyan',
  controls: [
    { kind: 'slider', key: 'depth', label: 'Water depth', min: 1, max: MAX_DEPTH_M, step: 0.5, unit: 'm', defaultValue: 8 },
    { kind: 'choice', key: 'liquid', label: 'Liquid', options: LIQUIDS.map((liquid) => ({ value: liquid.id, label: liquid.label })), defaultValue: 'fresh' },
  ],
  steps: [
    'Fill the tank to 8 m and compare the three outlets.',
    'The top outlet has the smallest pressure because it has the least water above it.',
    'The lowest outlet has the largest pressure and sends water farthest.',
    'Switch to mercury or oil to compare how density changes every jet.',
    'Explain why dams and tanks need stronger walls near the bottom.',
  ],
  readouts(settings) {
    const liquid = liquidFor(str(settings, 'liquid'));
    const depth = num(settings, 'depth');
    const gaugeKpa = (liquid.density * GRAVITY * depth) / 1000;
    return [
      { label: 'Bottom pressure', value: formatNumber(gaugeKpa, 1), unit: 'kPa', tone: 'cyan' },
      { label: 'Absolute pressure', value: formatNumber(gaugeKpa + ATMOSPHERE_KPA, 1), unit: 'kPa', tone: 'amber' },
      { label: 'Pressure per metre', value: formatNumber((liquid.density * GRAVITY) / 1000, 2), unit: 'kPa/m' },
    ];
  },
  draw(ctx, width, height, settings, time) {
    const liquid = liquidFor(str(settings, 'liquid'));
    const depth = num(settings, 'depth');
    const tankLeft = width * 0.25;
    const tankRight = width * 0.58;
    const topY = height * 0.13;
    const bottomY = height * 0.86;
    const tankHeight = bottomY - topY;
    const depthY = (metres: number) => topY + (metres / MAX_DEPTH_M) * tankHeight;
    const outletDepths = [depth * 0.25, depth * 0.55, depth * 0.9];
    const outletLabels = ['P₁', 'P₂', 'Pmax'];

    paintBackground(ctx, width, height);
    ctx.save();
    ctx.fillStyle = liquid.color;
    ctx.globalAlpha = 0.22;
    ctx.fillRect(tankLeft + 2, topY, tankRight - tankLeft - 4, depthY(depth) - topY);
    ctx.restore();
    ctx.save();
    ctx.strokeStyle = PALETTE.wall;
    ctx.lineWidth = 2;
    ctx.strokeRect(tankLeft, topY, tankRight - tankLeft, tankHeight);
    ctx.strokeStyle = liquid.color;
    ctx.beginPath(); ctx.moveTo(tankLeft, depthY(depth)); ctx.lineTo(tankRight, depthY(depth)); ctx.stroke();
    ctx.restore();

    for (let metres = 0; metres <= MAX_DEPTH_M; metres += 2) {
      drawLabel(ctx, `${metres} m`, tankLeft - 12, depthY(metres), { align: 'right', mono: true, size: 11, color: PALETTE.muted });
    }
    drawLabel(ctx, 'h', tankLeft - 48, topY + tankHeight * 0.43, { size: 22, color: PALETTE.amber });
    ctx.save(); ctx.strokeStyle = PALETTE.amber; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(tankLeft - 40, topY); ctx.lineTo(tankLeft - 40, depthY(depth)); ctx.stroke(); ctx.restore();

    outletDepths.forEach((fraction, index) => {
      const outletDepth = Math.min(depth - 0.1, Math.max(0.1, fraction));
      const y = depthY(outletDepth);
      const pressure = liquid.density * GRAVITY * outletDepth / 1000;
      const jetLength = Math.min(width * 0.34, 20 + pressure * 4.5);
      ctx.save();
      ctx.fillStyle = PALETTE.wall;
      ctx.fillRect(tankRight - 3, y - 5, 18, 10);
      ctx.strokeStyle = liquid.color;
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(tankRight + 12, y); ctx.quadraticCurveTo(tankRight + jetLength * 0.55, y + 4, tankRight + jetLength, y + 28 + index * 8); ctx.stroke();
      ctx.restore();
      drawArrow(ctx, tankRight + jetLength - 18, y + 26 + index * 8, tankRight + jetLength, y + 28 + index * 8, liquid.color);
      drawLabel(ctx, outletLabels[index], tankRight + 30, y - 4, { mono: true, size: 14, color: PALETTE.text });
      drawLabel(ctx, `${formatNumber(pressure, 1)} kPa`, tankRight + 30, y + 16, { mono: true, size: 10, color: PALETTE.muted });
    });

    drawLabel(ctx, `ρ = ${formatNumber(liquid.density, 0)} kg/m³`, width * 0.72, topY + 18, { mono: true, size: 11, color: liquid.color });
    drawLabel(ctx, 'Pressure grows with depth', width * 0.72, bottomY - 18, { size: 13, color: PALETTE.text });
    drawLabel(ctx, 'P = ρgh', width * 0.72, bottomY + 6, { mono: true, size: 16, color: PALETTE.amber });
    drawLabel(ctx, `${formatNumber(depth, 1)} m water column`, width / 2, height - 16, { align: 'center', mono: true, size: 11, color: PALETTE.muted });
    void time;
  },
};
