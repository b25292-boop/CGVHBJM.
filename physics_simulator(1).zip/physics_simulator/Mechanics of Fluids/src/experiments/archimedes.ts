import type { ExperimentDef, Readout, Settings } from './types';
import { formatNumber, num, str } from './helpers';
import { PALETTE, drawArrow, drawLabel, paintBackground } from './drawing';
import { GRAVITY } from './physics';

const OBJECTS = [
  { id: 'boat', label: 'Wooden boat', density: 520, volume: 0.08, color: '#B9783E' },
  { id: 'ship', label: 'Cargo ship', density: 300, volume: 3.2, color: '#64748B' },
  { id: 'submarine', label: 'Submarine', density: 980, volume: 0.12, color: '#3E647C' },
  { id: 'lifeJacket', label: 'Life jacket', density: 120, volume: 0.035, color: '#F59E0B' },
  { id: 'tube', label: 'Inflatable tube', density: 90, volume: 0.045, color: '#F97316' },
  { id: 'log', label: 'Floating wooden log', density: 650, volume: 0.055, color: '#A16207' },
  { id: 'balloon', label: 'Hot air balloon', density: 0.3, volume: 18, color: '#EF4444' },
] as const;

const FLUIDS = [
  { id: 'air', label: 'Air', density: 1.225, color: '#CBD5E1' },
  { id: 'oil', label: 'Light oil', density: 850, color: '#F59E0B' },
  { id: 'water', label: 'Fresh water', density: 1000, color: '#22D3EE' },
  { id: 'seawater', label: 'Sea water', density: 1025, color: '#2DD4BF' },
  { id: 'glycerin', label: 'Glycerin', density: 1261, color: '#60A5FA' },
] as const;

function objectFor(id: string) {
  return OBJECTS.find((object) => object.id === id) ?? OBJECTS[0];
}

function fluidFor(id: string) {
  return FLUIDS.find((fluid) => fluid.id === id) ?? FLUIDS[2];
}

function stateFor(settings: Settings) {
  const object = objectFor(str(settings, 'object'));
  const fluid = fluidFor(str(settings, 'fluid'));
  const cargoKg = object.id === 'boat' || object.id === 'ship' ? num(settings, 'cargo') : 0;
  const ballastWaterKg = object.id === 'submarine' ? num(settings, 'ballast') : 0;
  const baseMassKg = object.density * object.volume;
  const totalMassKg = baseMassKg + cargoKg + ballastWaterKg;
  const weight = totalMassKg * GRAVITY;
  const maxBuoyantForce = fluid.density * object.volume * GRAVITY;
  const displacedVolume = Math.min(object.volume, totalMassKg / fluid.density);
  const buoyancy = fluid.density * displacedVolume * GRAVITY;
  const fraction = Math.min(1, displacedVolume / object.volume);
  const outcome = totalMassKg / object.volume < fluid.density ? 'Floats' : totalMassKg / object.volume === fluid.density ? 'Neutral' : 'Sinks';
  return { object, fluid, cargoKg, ballastWaterKg, totalMassKg, weight, maxBuoyantForce, buoyancy, displacedVolume, fraction, outcome };
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number) {
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, radius);
  ctx.fill();
  ctx.stroke();
}

function drawBoat(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, color: string, cargo: number) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.strokeStyle = '#F6C77B';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x - width / 2, y - height * 0.25);
  ctx.lineTo(x + width / 2, y - height * 0.25);
  ctx.lineTo(x + width * 0.34, y + height * 0.42);
  ctx.quadraticCurveTo(x, y + height * 0.72, x - width * 0.34, y + height * 0.42);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#EAB308';
  for (let index = 0; index < Math.min(5, Math.round(cargo / 100)); index += 1) {
    ctx.fillRect(x - width * 0.25 + index * 12, y - height * 0.18, 9, 9);
  }
  ctx.restore();
}

function drawSubmarine(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, color: string, time: number) {
  ctx.save();
  ctx.translate(x, y + Math.sin(time * 1.5) * 3);
  ctx.fillStyle = color;
  ctx.strokeStyle = '#B7D8E8';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(0, 0, width / 2, height / 2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.fillRect(-width * 0.08, -height * 0.65, width * 0.16, height * 0.35);
  ctx.strokeRect(-width * 0.08, -height * 0.65, width * 0.16, height * 0.35);
  ctx.restore();
}

function drawObject(ctx: CanvasRenderingContext2D, state: ReturnType<typeof stateFor>, x: number, y: number, size: number, time: number) {
  const { object } = state;
  if (object.id === 'boat' || object.id === 'ship') drawBoat(ctx, x, y, size * 1.35, size * 0.7, object.color, state.cargoKg);
  else if (object.id === 'submarine') drawSubmarine(ctx, x, y, size * 1.55, size * 0.55, object.color, time);
  else if (object.id === 'lifeJacket') {
    ctx.save(); ctx.fillStyle = object.color; ctx.strokeStyle = '#FFE4A3'; ctx.lineWidth = 2;
    roundRect(ctx, x - size * 0.48, y - size * 0.5, size * 0.35, size, 16);
    roundRect(ctx, x + size * 0.13, y - size * 0.5, size * 0.35, size, 16); ctx.restore();
  } else if (object.id === 'tube') {
    ctx.save(); ctx.strokeStyle = object.color; ctx.lineWidth = size * 0.27; ctx.beginPath(); ctx.arc(x, y, size * 0.42, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  } else if (object.id === 'balloon') {
    ctx.save(); ctx.fillStyle = object.color; ctx.strokeStyle = '#FFE4A3'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, y - size * 0.12, size * 0.46, size * 0.6, 0, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.strokeStyle = '#E2E8F0'; ctx.beginPath(); ctx.moveTo(x - 12, y + size * 0.4); ctx.lineTo(x - 6, y + size * 0.7); ctx.lineTo(x + 6, y + size * 0.7); ctx.lineTo(x + 12, y + size * 0.4); ctx.stroke(); ctx.restore();
  } else {
    ctx.save(); ctx.fillStyle = object.color; ctx.strokeStyle = '#EAB308'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, y, size * 0.6, size * 0.28, -0.1, 0, Math.PI * 2); ctx.fill(); ctx.stroke(); ctx.restore();
  }
}

export const archimedes: ExperimentDef = {
  slug: 'archimedes',
  title: "Archimedes' Buoyancy",
  tagline: 'Choose an object and discover why it floats, sinks, or stays neutrally buoyant.',
  concept: 'The buoyant force equals the weight of the fluid displaced. Add cargo, fill a submarine ballast tank, or compare trapped air with solid materials.',
  formula: 'Fᵦ = ρfluid · Vdisplaced · g',
  accent: 'amber',
  controls: [
    { kind: 'choice', key: 'object', label: 'Object', options: OBJECTS.map((object) => ({ value: object.id, label: object.label })), defaultValue: 'boat' },
    { kind: 'choice', key: 'fluid', label: 'Fluid', options: FLUIDS.map((fluid) => ({ value: fluid.id, label: fluid.label })), defaultValue: 'water' },
    { kind: 'slider', key: 'cargo', label: 'Cargo load', min: 0, max: 800, step: 25, unit: 'kg', defaultValue: 0 },
    { kind: 'slider', key: 'ballast', label: 'Submarine ballast water', min: 0, max: 40, step: 1, unit: 'kg', defaultValue: 0 },
  ],
  steps: [
    'Choose any object and fluid, then watch its position and floating condition update.',
    'Choose Wooden boat and add cargo. The boat displaces more water and sinks deeper.',
    'Choose Submarine and fill the ballast tank with water to dive. Empty it to rise again.',
    'Compare the life jacket and inflatable tube. Their trapped air gives them a low average density.',
    'Choose Hot air balloon and Air to explore buoyancy in a gas.',
  ],
  readouts(settings) {
    const state = stateFor(settings);
    const readouts: Readout[] = [
      { label: 'Condition', value: state.outcome, tone: 'amber' },
      { label: 'Buoyant force', value: formatNumber(state.buoyancy, 2), unit: 'N', tone: 'cyan' },
      { label: 'Weight', value: formatNumber(state.weight, 2), unit: 'N' },
      { label: 'Displaced fluid', value: formatNumber(state.displacedVolume * 1000, 2), unit: 'L' },
      { label: 'Submerged', value: formatNumber(state.fraction * 100, 0), unit: '%' },
    ];
    return readouts;
  },
  draw(ctx, width, height, settings, time) {
    const state = stateFor(settings);
    const tankLeft = width * 0.2;
    const tankRight = width * 0.8;
    const surfaceY = height * 0.35;
    const bottomY = height * 0.9;
    const size = Math.min(width, height) * 0.2;
    const centerX = width / 2;
    const objectDepth = state.outcome === 'Sinks' ? bottomY - size * 0.25 : surfaceY + state.fraction * size * 0.35;

    paintBackground(ctx, width, height);
    ctx.save();
    ctx.fillStyle = state.fluid.color;
    ctx.globalAlpha = state.fluid.id === 'air' ? 0.06 : 0.2;
    ctx.fillRect(tankLeft, surfaceY, tankRight - tankLeft, bottomY - surfaceY);
    ctx.restore();
    ctx.save();
    ctx.strokeStyle = PALETTE.wall;
    ctx.lineWidth = 2;
    ctx.strokeRect(tankLeft, surfaceY - height * 0.16, tankRight - tankLeft, bottomY - surfaceY + height * 0.16);
    ctx.strokeStyle = state.fluid.color;
    ctx.beginPath(); ctx.moveTo(tankLeft, surfaceY); ctx.lineTo(tankRight, surfaceY); ctx.stroke(); ctx.restore();

    drawObject(ctx, state, centerX, objectDepth, size, time);
    const objectWidth = state.object.id === 'submarine' || state.object.id === 'boat' || state.object.id === 'ship' ? size * 0.8 : size * 0.5;
    const maxForce = Math.max(state.weight, state.buoyancy, 1);
    const arrowScale = size / maxForce;
    drawArrow(ctx, centerX - objectWidth, objectDepth, centerX - objectWidth, objectDepth - Math.max(18, state.buoyancy * arrowScale), PALETTE.cyan);
    drawArrow(ctx, centerX + objectWidth, objectDepth, centerX + objectWidth, objectDepth + Math.max(18, state.weight * arrowScale), PALETTE.amber);
    drawLabel(ctx, state.object.label, centerX, surfaceY - height * 0.1, { align: 'center', size: 15, color: PALETTE.text });
    drawLabel(ctx, `${state.outcome} · ${formatNumber(state.fraction * 100, 0)}% submerged`, centerX, bottomY + 18, { align: 'center', mono: true, size: 11, color: PALETTE.muted });
    drawLabel(ctx, state.fluid.label, tankLeft + 12, bottomY - 16, { size: 12, color: PALETTE.text });
  },
};
