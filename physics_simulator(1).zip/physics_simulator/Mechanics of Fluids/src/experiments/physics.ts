export const GRAVITY = 9.81;
export const WATER_DENSITY = 998;
export const WATER_VISCOSITY = 0.001;
export const ATMOSPHERE_KPA = 101.3;
export const BALL_DENSITY = 2500;

export const SYRUP_FLUIDS = [
  { id: 'oil', name: 'Sunflower oil', density: 920, viscosity: 0.06, color: '#F59E0B' },
  { id: 'glycerin', name: 'Glycerin', density: 1261, viscosity: 1.41, color: '#22D3EE' },
  { id: 'honey', name: 'Honey', density: 1420, viscosity: 5, color: '#FBBF24' },
] as const;

export type SyrupFluid = (typeof SYRUP_FLUIDS)[number];

export function findSyrupFluid(id: string): SyrupFluid {
  return SYRUP_FLUIDS.find((fluid) => fluid.id === id) ?? SYRUP_FLUIDS[0];
}

export function terminalVelocity(
  radiusM: number,
  ballDensity: number,
  fluidDensity: number,
  viscosity: number,
): number {
  return ((2 / 9) * (ballDensity - fluidDensity) * GRAVITY * radiusM * radiusM) / viscosity;
}

export function sphereReynolds(velocity: number, radiusM: number, fluidDensity: number, viscosity: number): number {
  return (fluidDensity * velocity * 2 * radiusM) / viscosity;
}
