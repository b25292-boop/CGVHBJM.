import type { ExperimentDef, Readout } from './types';
import { formatDuration, formatNumber, num, str } from './helpers';
import { PALETTE, drawGlowCircle, drawLabel, paintBackground } from './drawing';
import { GRAVITY } from './physics';

const TANK_AREA_M2 = 0.5;
const DISCHARGE_COEFFICIENT = 0.62;
const MAX_HEIGHT_M = 8;
const DRAIN_SECONDS = 12;
const PAUSE_SECONDS = 2;

function holeAreaM2(diameterMm: number): number {
  const radius = diameterMm / 2000;
  return Math.PI * radius * radius;
}

export const torricelli: ExperimentDef = {
  slug: 'torricelli',
  title: "Torricelli's Law",
  tagline: 'Open or close the hole and see how water speed depends on height.',
  concept: 'Water leaving a hole at the bottom of a tank moves as fast as it would falling freely from the water surface. Higher water means faster flow, but the level drops and the flow slows over time.',
  formula: 'v = √(2gh)   and   Q = Cd · a · v',
  accent: 'amber',
  controls: [
    { kind: 'slider', key: 'height', label: 'Water height', min: 0.5, max: MAX_HEIGHT_M, step: 0.1, unit: 'm', defaultValue: 4 },
    { kind: 'choice', key: 'opening', label: 'Hole state', options: [{ value: 'open', label: 'Open' }, { value: 'closed', label: 'Closed' }], defaultValue: 'open' },
    { kind: 'slider', key: 'hole', label: 'Hole diameter', min: 2, max: 60, step: 1, unit: 'mm', defaultValue: 12 },
  ],
  steps: [
    'Open the hole and read the exit speed and flow rate in the readouts.',
    'Close the hole to stop the jet and hold the water level steady.',
    'Double the hole diameter. The flow rate grows about four times, but the speed stays the same.',
    'Lower the water height. Watch the exit speed fall in proportion to the square root of the height.',
    'Watch the tank drain. The water level falls faster at first and then slows down.',
  ],
  readouts(settings) {
    const heightM = num(settings, 'height');
    const hole = holeAreaM2(num(settings, 'hole'));
    const isOpen = str(settings, 'opening') === 'open';
    const exitSpeed = isOpen ? Math.sqrt(2 * GRAVITY * heightM) : 0;
    const flowLitresPerMinute = isOpen ? DISCHARGE_COEFFICIENT * hole * exitSpeed * 1000 * 60 : 0;
    const emptySeconds = isOpen ? (TANK_AREA_M2 / (DISCHARGE_COEFFICIENT * hole)) * Math.sqrt((2 * heightM) / GRAVITY) : Infinity;
    const readouts: Readout[] = [
      { label: 'Exit speed', value: formatNumber(exitSpeed, 2), unit: 'm/s', tone: 'amber' },
      { label: 'Flow rate', value: formatNumber(flowLitresPerMinute, 1), unit: 'L/min', tone: 'cyan' },
      { label: 'Time to empty', value: formatDuration(emptySeconds) },
    ];
    return readouts;
  },
  draw(ctx, width, height, settings, time) {
    const startHeight = num(settings, 'height');
    const holeMm = num(settings, 'hole');
    const isOpen = str(settings, 'opening') === 'open';
    const hole = holeAreaM2(holeMm);
    const drainRate = (hole * DISCHARGE_COEFFICIENT) / TANK_AREA_M2;
    const k = drainRate * Math.sqrt(GRAVITY / 2);
    const emptySimSeconds = Math.sqrt(startHeight) / k;
    const cycle = (time % (DRAIN_SECONDS + PAUSE_SECONDS)) / DRAIN_SECONDS;
    const tau = isOpen ? Math.min(1, cycle) : 0;
    const levelM = Math.max(0, (Math.sqrt(startHeight) - k * emptySimSeconds * tau) ** 2);
    const tankLeft = width * 0.14;
    const tankRight = width * 0.44;
    const tankTop = height * 0.1;
    const tankBottom = height * 0.88;
    const tankHeight = tankBottom - tankTop;
    const levelY = tankBottom - (levelM / MAX_HEIGHT_M) * tankHeight;
    const holeY = tankBottom - height * 0.08;
    const holeRadius = 2 + holeMm * 0.25;
    const exitSpeed = Math.sqrt(2 * GRAVITY * levelM);

    paintBackground(ctx, width, height);
    ctx.save(); ctx.fillStyle = PALETTE.cyan; ctx.globalAlpha = 0.22; ctx.fillRect(tankLeft + 2, levelY, tankRight - tankLeft - 4, tankBottom - levelY); ctx.restore();
    ctx.save(); ctx.strokeStyle = PALETTE.wall; ctx.lineWidth = 2; ctx.strokeRect(tankLeft, tankTop, tankRight - tankLeft, tankHeight); ctx.restore();
    ctx.save(); ctx.fillStyle = PALETTE.background; ctx.beginPath(); ctx.arc(tankRight, holeY, holeRadius, 0, Math.PI * 2); ctx.fill(); ctx.restore();

    if (isOpen && levelM > 0.01) {
      const jetSteps = 28;
      const jetRange = Math.min(width * 0.5, exitSpeed * 42);
      ctx.save();
      for (let i = 0; i <= jetSteps; i += 1) {
        const s = i / jetSteps;
        drawGlowCircle(ctx, tankRight + holeRadius + s * jetRange, holeY + s * s * 110, 2.2, PALETTE.amber);
      }
      ctx.restore();
    }
    drawLabel(ctx, `${formatNumber(levelM, 2)} m`, tankLeft + 12, tankTop + 16, { mono: true, size: 12, color: PALETTE.text });
    drawLabel(ctx, `${isOpen ? 'Open' : 'Closed'} · ${formatNumber(holeMm, 0)} mm`, tankRight + 12, holeY - 22, { mono: true, size: 11, color: PALETTE.muted });
  },
};
