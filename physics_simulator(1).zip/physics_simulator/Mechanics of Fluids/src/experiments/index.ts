import type { ExperimentDef } from './types';
import { laminarTurbulent } from './laminarTurbulent';
import { venturi } from './venturi';
import { bernoulli } from './bernoulli';
import { stokesLaw } from './stokesLaw';
import { pressureDepth } from './pressureDepth';
import { archimedes } from './archimedes';
import { surfaceTension } from './surfaceTension';
import { torricelli } from './torricelli';

export const EXPERIMENTS: ExperimentDef[] = [
  laminarTurbulent,
  venturi,
  bernoulli,
  stokesLaw,
  pressureDepth,
  archimedes,
  surfaceTension,
  torricelli,
];

export function getExperiment(slug: string): ExperimentDef | undefined {
  return EXPERIMENTS.find((experiment) => experiment.slug === slug);
}
