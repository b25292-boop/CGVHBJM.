/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#060A13',
          900: '#0A0F1C',
          850: '#0D1424',
          800: '#111A2E',
          700: '#18233C',
          600: '#22304F',
          500: '#33446B',
          400: '#5B6B8C',
          300: '#8B98B0',
          200: '#B6C2D6',
          100: '#DCE4F0',
          50: '#F2F6FB',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(34,211,238,0.35), 0 0 32px -4px rgba(34,211,238,0.35)',
        'glow-amber': '0 0 0 1px rgba(245,158,11,0.35), 0 0 32px -4px rgba(245,158,11,0.3)',
      },
    },
  },
  plugins: [],
};
