const c=document.getElementById('scene'),ctx=c.getContext('2d');
const $=id=>document.getElementById(id);
let running=true,t=0,photons=[],electrons=[];
const W=1000,H=562;
function rand(a,b){return a+Math.random()*(b-a)}
function resetParticles(){photons=[];electrons=[];for(let i=0;i<100;i++)photons.push({x:430+rand(-18,18),y:185+rand(-30,55),p:rand(0,1),speed:rand(.004,.009)});for(let i=0;i<95;i++)electrons.push({x:215+rand(0,300),y:260+rand(-75,125),p:rand(0,1),speed:rand(.002,.006),r:rand(1.1,2.5)});}
function line(x1,y1,x2,y2,col,w=1){ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.strokeStyle=col;ctx.lineWidth=w;ctx.stroke()}
function glow(x,y,r,color){ctx.save();ctx.shadowBlur=r;ctx.shadowColor=color;ctx.fillStyle=color;ctx.beginPath();ctx.arc(x,y,2,0,Math.PI*2);ctx.fill();ctx.restore()}
function polygon(points,fill,stroke){ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke()}}
function draw(){
 ctx.clearRect(0,0,W,H);
 let bg=ctx.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#02040b');bg.addColorStop(.65,'#030712');bg.addColorStop(1,'#100b0d');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
 // chamber side rails and base
 polygon([[0,345],[1000,345],[1000,405],[0,405]],'#100d10','#632c27');
 polygon([[0,352],[1000,352],[1000,367],[0,367]],'#271613','#7e352c');
 polygon([[0,405],[1000,405],[1000,562],[0,562]],'#120d0d','#602b24');
 // perspective floor
 for(let i=0;i<19;i++){let x=330+i*38;line(500,365,x,550,'#8ca9b0',1.5);line(500,365,x,550,'#d5efff55',.5)}
 for(let y=390;y<560;y+=23){let yy=y;line(0,yy,1000,yy,'#4d555d55',1)}
 // side supports
 for(let x of [24,855]){polygon([[x,315],[x+70,315],[x+88,345],[x+88,530],[x+66,550],[x+5,550],[x-7,530]],'#1c1414','#77352e');polygon([[x+18,335],[x+62,335],[x+65,380],[x+18,380]],'#311c1b','#9b4537')}
 // light source glow behind bulb
 let g=ctx.createRadialGradient(440,150,8,440,150,150);g.addColorStop(0,'#fa45e8aa');g.addColorStop(.35,'#7030ff66');g.addColorStop(1,'#090b2200');ctx.fillStyle=g;ctx.fillRect(270,0,340,330);
 // photons traveling left and ending at cathode right-facing surface x=215
 const f=+$('freq').value,int=+$('intensity').value;
 let active=f>=2.5 && int>0;
 if(active){
   photons.forEach(p=>{p.p+=p.speed*(.4+int/70);if(p.p>1)p.p=0;let x=430-p.p*245,y=170+p.p*90;
     if(x>185){glow(x,y,7,'#ff55e9');ctx.fillStyle='#ff9cf4';ctx.beginPath();ctx.arc(x,y,2.2,0,7);ctx.fill();}
   });
   // Photon particles follow straight paths and stop at the cathode surface.
 }
 // cathode plate: illuminated white front face at x=185, dark metal thickness extends right
 polygon([[160,75],[185,90],[185,370],[160,352]],'#303b42','#718b99');
 polygon([[128,74],[160,75],[160,352],[128,337]],'#e7edf0','#ffffff');
 line(148,95,148,320,'#b8c6cc',2);
 // tiny illuminated contact at front/right edge
 polygon([[160,238],[184,252],[160,267]],'#f8a4f4','#ff5de8');
 // collector plate to right
 polygon([[625,235],[653,246],[653,430],[625,418]],'#89949a','#cbd8df');
 polygon([[600,230],[625,235],[625,418],[600,410]],'#dce3e5','#ffffff');
 // electron particles move from cathode face x=185 toward collector face x=600
 let voltage=+$('voltage').value,work=+$('material').value,energy=4.135667696e-15*f*1e14,ke=Math.max(0,energy-work);
 let emission=active&&ke>0;
 if(emission){
  electrons.forEach((p,i)=>{p.p+=p.speed*(.5+Math.max(-.3,voltage/5));if(p.p>1)p.p=0;let x=190+p.p*400,y=265+Math.sin(p.p*9+i)*50+(i%7-3)*10;
    if(x<600){glow(x,y,8,'#39cfff');ctx.fillStyle='#b8f5ff';ctx.beginPath();ctx.arc(x,y,p.r,0,Math.PI*2);ctx.fill();}
  });
 }
 // bulb body angled
 ctx.save();ctx.translate(440,130);ctx.rotate(-.45);
 let bulb=ctx.createRadialGradient(-10,-10,5,0,0,72);bulb.addColorStop(0,'#ffb5fa');bulb.addColorStop(.28,'#ff40dc');bulb.addColorStop(.68,'#7434ff');bulb.addColorStop(1,'#3014a8');
 ctx.shadowBlur=40;ctx.shadowColor='#7a3cff';ctx.fillStyle=bulb;ctx.beginPath();ctx.ellipse(0,0,43,75,0,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#d5dce5';ctx.fillRect(-12,-82,24,24);for(let y=-80;y<-58;y+=5)line(-12,y,12,y,'#7d8995',1.4);ctx.restore();
 // labels
 ctx.font='bold 17px Segoe UI';ctx.fillStyle='#e8f4ff';ctx.fillText('CATHODE',95,55);ctx.fillText('COLLECTOR',575,210);ctx.font='13px Segoe UI';ctx.fillStyle='#ff9df3';ctx.fillText('Incident photons',300,290);ctx.fillStyle='#74eaff';ctx.fillText('Photoelectrons',340,340);
 // Magnified inset removed as requested.
 // bottom small indicator
 ctx.fillStyle='#9fb4c9';ctx.font='12px Segoe UI';
 if(!emission){ctx.fillStyle='#ffb0e9';ctx.font='bold 14px Segoe UI';ctx.fillText(active?'Below threshold: no electrons emitted':'Light is off',350,385)}
 t+=1;
 requestAnimationFrame(draw);
}
function update(){
 let f=+$('freq').value,int=+$('intensity').value,v=+$('voltage').value,w=+$('material').value;
 let e=4.135667696e-15*f*1e14,ke=Math.max(0,e-w),cur=ke>0?int/100*Math.max(.0,1+v/7):0;
 $('freqVal').textContent=f.toFixed(1)+' × 10¹⁴ Hz';$('intVal').textContent=int+'%';$('voltVal').textContent=(v>=0?'+':'')+v.toFixed(1)+' V';$('matVal').textContent=$('material').selectedOptions[0].text;
 $('energy').textContent=e.toFixed(2)+' eV';$('ke').textContent=ke.toFixed(2)+' eV';$('current').textContent=(cur).toFixed(2)+' μA';
 $('status').textContent=ke>0&&int>0?'Electrons leave the cathode and move toward the collector.':'No photoelectron emission: increase frequency above the threshold.';
}
['freq','intensity','voltage','material'].forEach(id=>$(id).addEventListener('input',update));
$('toggle').onclick=()=>{running=!running;$('toggle').textContent=running?'Pause animation':'Resume animation';};
$('reset').onclick=()=>{$('freq').value=7;$('intensity').value=70;$('voltage').value=2;$('material').value=2.28;resetParticles();update()};
resetParticles();update();
let frame=()=>{if(running)draw();else requestAnimationFrame(frame)};draw();
