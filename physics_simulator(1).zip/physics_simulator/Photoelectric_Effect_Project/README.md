# Photoelectric Effect Interactive Simulator

## Files
- `index.html` — main simulator page.
- `style.css` — visual design and layout styles.
- `script.js` — animation, controls, and photoelectric-effect calculations.
- `standalone_simulator.html` — single-file version containing the HTML, CSS, and JavaScript together.
- `Project_Report.docx` — editable project report for academic submission.

## Run the experiment
1. Extract this ZIP folder.
2. Open `index.html` in a recent browser (Chrome, Edge, or Firefox).
3. Change light frequency, intensity, collector voltage, and cathode material.
4. Observe the photon energy, maximum kinetic energy, and simulated photocurrent.
5. For a one-file copy, open `standalone_simulator.html` instead.

No internet connection or software installation is required.

## Important
This is an educational computer simulation, not a physical apparatus. The displayed values and current response are illustrative. For a real laboratory experiment, use your institution's approved photoelectric-effect apparatus and follow your instructor's safety procedures.
