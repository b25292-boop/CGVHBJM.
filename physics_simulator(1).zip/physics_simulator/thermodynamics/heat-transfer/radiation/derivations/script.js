// ---------------------------------------------------------------------------
// Radiation: Derivations
// Tracks: Stefan-Boltzmann, Wien, Net exchange, Earth's equilibrium temperature
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);
const svg = el("derivation-svg");
const SVG_NS = "http://www.w3.org/2000/svg";
function makeEl(tag, attrs) {
  const node = document.createElementNS(SVG_NS, tag);
  Object.entries(attrs || {}).forEach(([k, v]) => node.setAttribute(k, v));
  return node;
}
function add(tag, attrs, text) {
  const node = makeEl(tag, attrs);
  if (text !== undefined) node.textContent = text;
  svg.appendChild(node);
  return node;
}

const H = 6.62607015e-34, C = 2.99792458e8, KB = 1.380649e-23;
const TEAL = "#4FA8B8", EMBER = "#E8734A", DIM = "#9AA1AC", LINE = "#262B33", TEXT = "#EDEAE2";

// ---------------------------- Step data ----------------------------

const TRACKS = {
  sb: {
    steps: [
      {
        title: "Start from Planck's Law",
        explanation: "A blackbody at temperature T emits power per unit area per unit wavelength given by Planck's law. We take this as the starting point.",
        formula: "M_\\lambda = \\dfrac{2\\pi h c^2}{\\lambda^5}\\,\\dfrac{1}{e^{hc/\\lambda k T}-1}",
        visual: "planck-curve",
      },
      {
        title: "Add Up Every Wavelength",
        explanation: "The total power radiated per unit area is the area under the whole spectrum curve — the integral of M\u03BB over all wavelengths.",
        formula: "M = \\int_0^\\infty M_\\lambda\\, d\\lambda",
        visual: "planck-area",
      },
      {
        title: "Substitute x = hc / \u03BBkT",
        explanation: "To make the integral dimensionless, let x = hc/(\u03BBkT). Every constant collects outside the integral, and the temperature dependence separates cleanly as T\u2074.",
        formula: "x = \\dfrac{hc}{\\lambda k T} \\;\\Rightarrow\\; M = \\dfrac{2\\pi k^4 T^4}{h^3 c^2}\\int_0^\\infty \\dfrac{x^3}{e^x - 1}\\,dx",
        visual: "x3-curve",
      },
      {
        title: "Evaluate the Integral",
        explanation: "The remaining integral is a pure number (it can be evaluated with the series expansion of 1/(e\u02E3 \u2212 1), giving a sum of 1/n\u2074 terms).",
        formula: "\\int_0^\\infty \\dfrac{x^3}{e^x-1}\\,dx = \\dfrac{\\pi^4}{15} \\approx 6.494",
        visual: "x3-value",
      },
      {
        title: "The Stefan-Boltzmann Law",
        explanation: "Multiplying out the constants gives the Stefan-Boltzmann constant. Total power per area depends only on T\u2074 — double the temperature and the power increases 16 times.",
        formula: "M = \\dfrac{2\\pi^5 k^4}{15\\, c^2 h^3}\\,T^4 = \\sigma T^4",
        visual: "sigma",
      },
    ],
  },
  wien: {
    steps: [
      {
        title: "Where is the Peak?",
        explanation: "The spectrum has a maximum at some wavelength \u03BBmax. At that point the slope of the curve is zero, so we set the derivative of Planck's law to zero.",
        formula: "\\dfrac{dM_\\lambda}{d\\lambda} = 0",
        visual: "planck-peak",
      },
      {
        title: "Differentiate",
        explanation: "With x = hc/(\u03BBkT), differentiating \u03BB\u207B\u2075/(e\u02E3 \u2212 1) gives a factor [x e\u02E3 \u2212 5(e\u02E3 \u2212 1)]. Setting that to zero:",
        formula: "(x - 5)\\,e^{x} + 5 = 0",
        visual: "planck-peak",
      },
      {
        title: "Solve for x",
        explanation: "Rearranged, this is x = 5(1 \u2212 e\u207B\u02E3). It has no neat closed form, but the curve and the line intersect at one non-trivial point (x = 0 is just the trivial root, not a peak).",
        formula: "x = 5\\left(1 - e^{-x}\\right) \\;\\Rightarrow\\; x \\approx 4.965",
        visual: "intersection",
      },
      {
        title: "Wien's Displacement Law",
        explanation: "Substitute x back: \u03BBmax = hc/(4.965 kT). The wavelength of peak emission is inversely proportional to temperature.",
        formula: "\\lambda_{max}\\, T = \\dfrac{hc}{4.965\\, k} = 2.898\\times10^{-3}\\ \\text{m·K}",
        visual: "intersection",
      },
    ],
  },
  exchange: {
    steps: [
      {
        title: "The Body Emits",
        explanation: "A body with emissivity \u03B5, area A and temperature T radiates energy to its surroundings.",
        formula: "P_{emit} = \\varepsilon \\sigma A T^4",
        visual: "exchange-0",
      },
      {
        title: "The Surroundings Radiate Back",
        explanation: "The surroundings, at temperature T\u2080, radiate too, and some of that lands on the body. By Kirchhoff's law the body absorbs the same fraction \u03B5 that it emits.",
        formula: "P_{abs} = \\varepsilon \\sigma A T_0^4",
        visual: "exchange-1",
      },
      {
        title: "Net Power Radiated",
        explanation: "The net loss is emitted minus absorbed. If T > T\u2080 the body cools; if T < T\u2080 it warms; at T = T\u2080 the exchange balances and the net is zero.",
        formula: "P_{net} = \\varepsilon \\sigma A \\left(T^4 - T_0^4\\right)",
        visual: "exchange-2",
      },
    ],
  },
  earth: {
    steps: [
      {
        title: "Sunlight Reaching Earth",
        explanation: "At Earth's distance, sunlight delivers a power per unit area called the solar constant.",
        formula: "S \\approx 1361\\ \\text{W/m}^2",
        visual: "earth-0",
      },
      {
        title: "Power Absorbed",
        explanation: "Earth intercepts sunlight over its circular cross-section \u03C0R\u00B2 (not its whole surface). A fraction \u03B1 \u2248 0.3 (the albedo) is reflected straight back.",
        formula: "P_{abs} = S\\,(1-\\alpha)\\,\\pi R^2",
        visual: "earth-1",
      },
      {
        title: "Power Emitted",
        explanation: "Earth radiates like a blackbody from its entire spherical surface, 4\u03C0R\u00B2 — four times the area that intercepts sunlight.",
        formula: "P_{emit} = \\sigma T^4 \\cdot 4\\pi R^2",
        visual: "earth-2",
      },
      {
        title: "Equilibrium Temperature",
        explanation: "In steady state, absorbed equals emitted. R cancels, leaving a temperature of about 255 K (\u221218 \u00B0C). The real average is about 288 K — the ~33 K difference is the greenhouse effect.",
        formula: "T = \\left[\\dfrac{S(1-\\alpha)}{4\\sigma}\\right]^{1/4} \\approx 255\\ \\text{K}",
        visual: "earth-3",
      },
    ],
  },
};

let currentTrack = "sb";
let currentStep = 0;
let isPlaying = false;
let playTimer = null;
let animHandle = null;

// ---------------------------- Drawing helpers ----------------------------

const PLOT = { left: 38, right: 304, top: 28, bottom: 222 };

function clearSVG() {
  if (animHandle) cancelAnimationFrame(animHandle);
  animHandle = null;
  svg.innerHTML = "";
}

function drawAxes(xLabel, yLabel) {
  add("line", { x1: PLOT.left, y1: PLOT.top, x2: PLOT.left, y2: PLOT.bottom, stroke: LINE, "stroke-width": 1.5 });
  add("line", { x1: PLOT.left, y1: PLOT.bottom, x2: PLOT.right, y2: PLOT.bottom, stroke: LINE, "stroke-width": 1.5 });
  add("text", { x: (PLOT.left + PLOT.right) / 2, y: 248, "text-anchor": "middle", fill: DIM, "font-size": 11, "font-family": "Inter, sans-serif" }, xLabel);
  add("text", { x: 12, y: (PLOT.top + PLOT.bottom) / 2, "text-anchor": "middle", fill: DIM, "font-size": 11, "font-family": "Inter, sans-serif", transform: `rotate(-90, 12, ${(PLOT.top + PLOT.bottom) / 2})` }, yLabel);
}

function mapPoint(x, y, xmin, xmax, ymin, ymax) {
  return [
    PLOT.left + ((x - xmin) / (xmax - xmin)) * (PLOT.right - PLOT.left),
    PLOT.bottom - ((y - ymin) / (ymax - ymin)) * (PLOT.bottom - PLOT.top),
  ];
}

function pathFrom(points) {
  return points.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ");
}

function label(x, y, text, color, anchor) {
  add("text", { x, y, fill: color || TEXT, "font-size": 11, "text-anchor": anchor || "start", "font-family": "Inter, sans-serif" }, text);
}

function arrow(x1, y1, x2, y2, color, width) {
  add("line", { x1, y1, x2, y2, stroke: color, "stroke-width": width || 2, "stroke-linecap": "round" });
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const size = 7;
  const a1 = angle + Math.PI - 0.45, a2 = angle + Math.PI + 0.45;
  add("path", {
    d: `M${x2} ${y2} L${x2 + size * Math.cos(a1)} ${y2 + size * Math.sin(a1)} L${x2 + size * Math.cos(a2)} ${y2 + size * Math.sin(a2)} Z`,
    fill: color,
  });
}

// ---------------------------- Planck spectrum (T = 5800 K, normalised) ----------------------------

const PLANCK_T = 5800;
const PLANCK_X_MAX = 2500; // nm
function planckRaw(lamNm) {
  const l = lamNm * 1e-9;
  return 1 / Math.pow(l, 5) / (Math.exp((H * C) / (l * KB * PLANCK_T)) - 1);
}
const PLANCK_PEAK = planckRaw((2.897772e-3 / PLANCK_T) * 1e9);
function planckNorm(lamNm) { return planckRaw(lamNm) / PLANCK_PEAK; }

function planckPoints(maxLam) {
  const pts = [];
  for (let l = 100; l <= maxLam; l += 12.5) {
    pts.push([l, planckNorm(l)]);
  }
  return pts;
}

function plotPlanck(maxLam, fillArea) {
  const pts = planckPoints(maxLam).map(([l, y]) => mapPoint(l, y, 0, PLANCK_X_MAX, 0, 1.1));
  if (fillArea && pts.length > 1) {
    const base = PLOT.bottom;
    add("path", {
      d: `M${pts[0][0].toFixed(1)} ${base} ` + pts.map((p) => `L${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ") + ` L${pts[pts.length - 1][0].toFixed(1)} ${base} Z`,
      fill: "rgba(232,115,74,0.25)",
    });
  }
  add("path", { d: pathFrom(pts), fill: "none", stroke: EMBER, "stroke-width": 2.5 });
}

// ---------------------------- Visual renderers ----------------------------

function visPlanckCurve() {
  drawAxes("Wavelength (nm)", "Power per wavelength");
  plotPlanck(PLANCK_X_MAX, false);
  label(PLOT.right - 4, PLOT.top + 12, "M\u03BB at T = 5800 K", EMBER, "end");
}

function visPlanckArea() {
  let progress = 0;
  function frame() {
    clearSVG();
    drawAxes("Wavelength (nm)", "Power per wavelength");
    const maxLam = 100 + progress * (PLANCK_X_MAX - 100);
    plotPlanck(maxLam, true);
    plotPlanck(PLANCK_X_MAX, false);
    label(PLOT.right - 4, PLOT.top + 12, "Shaded area = total M", EMBER, "end");
    progress = Math.min(1, progress + 0.012);
    if (progress < 1) animHandle = requestAnimationFrame(frame);
    else animHandle = null;
  }
  frame();
}

function x3Value(x) { return x < 1e-6 ? 0 : (x * x * x) / (Math.exp(x) - 1); }

function visX3(showValue) {
  drawAxes("x = hc / (\u03BBkT)", "x\u00B3 / (e\u02E3 \u2212 1)");
  const pts = [];
  for (let x = 0.05; x <= 12; x += 0.1) pts.push(mapPoint(x, x3Value(x), 0, 12, 0, 1.6));
  const base = PLOT.bottom;
  add("path", {
    d: `M${pts[0][0].toFixed(1)} ${base} ` + pts.map((p) => `L${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ") + ` L${pts[pts.length - 1][0].toFixed(1)} ${base} Z`,
    fill: "rgba(79,168,184,0.28)",
  });
  add("path", { d: pathFrom(pts), fill: "none", stroke: TEAL, "stroke-width": 2.5 });
  if (showValue) {
    label(PLOT.right - 6, PLOT.top + 16, "Area = \u03C0\u2074/15 \u2248 6.494", TEXT, "end");
  } else {
    label(PLOT.right - 6, PLOT.top + 16, "Integrand of the dimensionless integral", DIM, "end");
  }
}

function visSigma() {
  label(160, 58, "\u03C3 = 2\u03C0\u2075k\u2074 / (15 c\u00B2 h\u00B3)", TEXT, "middle");
  label(160, 84, "= 5.670 \u00D7 10\u207B\u2078 W m\u207B\u00B2 K\u207B\u2074", EMBER, "middle");

  const rows = [["300 K", "459 W/m\u00B2", 40], ["600 K", "7349 W/m\u00B2", 40 * 16]];
  const maxW = 220;
  rows.forEach((r, i) => {
    const y = 130 + i * 50;
    label(30, y + 14, r[0], DIM, "start");
    const w = i === 0 ? maxW / 16 : maxW;
    add("rect", { x: 80, y, width: w, height: 20, rx: 4, fill: i === 0 ? TEAL : EMBER });
    label(80 + w + 6 > 250 ? 80 + w - 6 : 80 + w + 6, y + 14, r[1], i === 0 ? TEXT : "#12161c", i === 0 ? "start" : "end");
  });
  label(160, 240, "Double T \u2192 16\u00D7 the power", DIM, "middle");
}

function visPlanckPeak() {
  drawAxes("Wavelength (nm)", "Power per wavelength");
  plotPlanck(PLANCK_X_MAX, false);
  const peakLam = (2.897772e-3 / PLANCK_T) * 1e9;
  const [px, py] = mapPoint(peakLam, 1, 0, PLANCK_X_MAX, 0, 1.1);
  add("line", { x1: px - 42, y1: py, x2: px + 42, y2: py, stroke: TEXT, "stroke-width": 1.5, "stroke-dasharray": "4 3" });
  add("circle", { cx: px, cy: py, r: 5, fill: TEXT });
  add("line", { x1: px, y1: py, x2: px, y2: PLOT.bottom, stroke: DIM, "stroke-width": 1, "stroke-dasharray": "3 3" });
  label(px + 50, py - 6, "slope = 0", TEXT, "start");
  label(px, PLOT.bottom + 0 - 6, "\u03BBmax", DIM, "middle");
}

function visIntersection() {
  drawAxes("x", "y");
  const xmax = 8, ymax = 7;
  add("path", { d: pathFrom([mapPoint(0, 0, 0, xmax, 0, ymax), mapPoint(7, 7, 0, xmax, 0, ymax)]), fill: "none", stroke: TEAL, "stroke-width": 2.5 });
  const pts = [];
  for (let x = 0; x <= xmax; x += 0.1) pts.push(mapPoint(x, 5 * (1 - Math.exp(-x)), 0, xmax, 0, ymax));
  add("path", { d: pathFrom(pts), fill: "none", stroke: EMBER, "stroke-width": 2.5 });

  const [ix, iy] = mapPoint(4.965, 4.965, 0, xmax, 0, ymax);
  add("circle", { cx: ix, cy: iy, r: 5, fill: TEXT });
  add("line", { x1: ix, y1: iy, x2: ix, y2: PLOT.bottom, stroke: DIM, "stroke-width": 1, "stroke-dasharray": "3 3" });
  label(ix + 8, iy + 16, "x \u2248 4.965", TEXT, "start");
  label(PLOT.left + 6, PLOT.top + 10, "y = x", TEAL, "start");
  label(PLOT.right - 4, PLOT.top + 30, "y = 5(1 \u2212 e\u207B\u02E3)", EMBER, "end");
}

function visExchange(stage) {
  const cx = 160, cy = 120;
  add("rect", { x: 28, y: 28, width: 264, height: 190, rx: 14, fill: "none", stroke: DIM, "stroke-width": 1.5, "stroke-dasharray": "6 4" });
  label(40, 46, "Surroundings, T\u2080", DIM, "start");
  add("circle", { cx, cy, r: 34, fill: EMBER });
  label(cx, cy + 4, "Body, T", "#12161c", "middle");

  const dirs = [[-1, -1], [1, -1], [-1, 1], [1, 1]];
  dirs.forEach(([dx, dy]) => {
    arrow(cx + dx * 30, cy + dy * 30, cx + dx * 70, cy + dy * 62, EMBER, stage === 2 ? 4 : 3);
  });
  label(cx, 240, "Emitted: \u03B5\u03C3AT\u2074", EMBER, "middle");

  if (stage >= 1) {
    dirs.forEach(([dx, dy]) => {
      arrow(cx + dx * 100, cy + dy * 84, cx + dx * 72, cy + dy * 64, TEAL, stage === 2 ? 2 : 3);
    });
    label(cx, 256, "Absorbed: \u03B5\u03C3AT\u2080\u2074", TEAL, "middle");
  }
  if (stage === 2) {
    label(cx, 124 + 62, "Net = \u03B5\u03C3A(T\u2074 \u2212 T\u2080\u2074)", TEXT, "middle");
  }
}

function visEarth(stage) {
  add("circle", { cx: 46, cy: 120, r: 28, fill: "#F7A25C" });
  label(46, 168, "Sun", DIM, "middle");
  const ex = 240, ey = 120, er = 32;
  add("circle", { cx: ex, cy: ey, r: er, fill: TEAL });
  label(ex, ey + 4, "Earth", "#12161c", "middle");

  [-24, -12, 0, 12, 24].forEach((dy) => arrow(82, ey + dy, ex - er - 8, ey + dy, "#F7A25C", 1.8));
  label(130, 82, "S", "#F7A25C", "middle");

  if (stage >= 1) {
    add("line", { x1: ex - er + 2, y1: ey - er, x2: ex - er + 2, y2: ey + er, stroke: TEXT, "stroke-width": 1.5, "stroke-dasharray": "4 3" });
    arrow(ex - er - 6, ey - 40, ex - er - 52, ey - 70, DIM, 1.8);
    label(ex - er - 56, ey - 76, "reflected (\u03B1)", DIM, "middle");
    label(ex, 190, "Intercepts \u03C0R\u00B2", TEXT, "middle");
  }
  if (stage >= 2) {
    for (let a = 0; a < 8; a++) {
      const ang = (a / 8) * Math.PI * 2;
      arrow(ex + Math.cos(ang) * (er + 3), ey + Math.sin(ang) * (er + 3), ex + Math.cos(ang) * (er + 24), ey + Math.sin(ang) * (er + 24), EMBER, 1.8);
    }
    label(ex, 206, "Emits over 4\u03C0R\u00B2", EMBER, "middle");
  }
  if (stage >= 3) {
    label(160, 244, "T \u2248 255 K  (observed \u2248 288 K)", TEXT, "middle");
  }
}

function renderVisual(key) {
  clearSVG();
  switch (key) {
    case "planck-curve": visPlanckCurve(); break;
    case "planck-area": visPlanckArea(); break;
    case "x3-curve": visX3(false); break;
    case "x3-value": visX3(true); break;
    case "sigma": visSigma(); break;
    case "planck-peak": visPlanckPeak(); break;
    case "intersection": visIntersection(); break;
    case "exchange-0": visExchange(0); break;
    case "exchange-1": visExchange(1); break;
    case "exchange-2": visExchange(2); break;
    case "earth-0": visEarth(0); break;
    case "earth-1": visEarth(1); break;
    case "earth-2": visEarth(2); break;
    case "earth-3": visEarth(3); break;
  }
}

// ---------------------------- Step rendering and navigation ----------------------------

function renderStep() {
  const steps = TRACKS[currentTrack].steps;
  const step = steps[currentStep];
  el("step-indicator").textContent = `Step ${currentStep + 1} of ${steps.length}`;
  el("step-title").textContent = step.title;
  el("step-explanation").textContent = step.explanation;

  const formulaEl = el("step-formula");
  formulaEl.innerHTML = "";
  try {
    katex.render(step.formula, formulaEl, { throwOnError: false, displayMode: true });
  } catch (e) {
    formulaEl.textContent = step.formula;
  }

  el("btn-prev").disabled = currentStep === 0;
  el("btn-next").disabled = currentStep === steps.length - 1;

  const dotsEl = el("step-dots");
  dotsEl.innerHTML = "";
  steps.forEach((_, i) => {
    const dot = document.createElement("div");
    dot.className = "dot" + (i === currentStep ? " active" : "");
    dotsEl.appendChild(dot);
  });

  renderVisual(step.visual);
}

function goToStep(index) {
  const steps = TRACKS[currentTrack].steps;
  if (index < 0 || index >= steps.length) return;
  currentStep = index;
  renderStep();
}

el("btn-prev").addEventListener("click", () => { stopAutoplay(); goToStep(currentStep - 1); });
el("btn-next").addEventListener("click", () => { stopAutoplay(); goToStep(currentStep + 1); });
el("btn-play").addEventListener("click", () => { if (isPlaying) stopAutoplay(); else startAutoplay(); });

function startAutoplay() {
  isPlaying = true;
  el("btn-play").textContent = "\u23F8 Pause";
  playTimer = setInterval(() => {
    if (currentStep >= TRACKS[currentTrack].steps.length - 1) { stopAutoplay(); return; }
    goToStep(currentStep + 1);
  }, 4200);
}

function stopAutoplay() {
  isPlaying = false;
  el("btn-play").textContent = "\u25B6 Play";
  if (playTimer) clearInterval(playTimer);
  playTimer = null;
}

document.querySelectorAll("#track-toggle button").forEach((btn) => {
  btn.addEventListener("click", () => {
    stopAutoplay();
    document.querySelectorAll("#track-toggle button").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    currentTrack = btn.dataset.track;
    currentStep = 0;
    renderStep();
  });
});

renderStep();