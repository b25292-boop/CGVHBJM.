// ---------------------------------------------------------------------------
// Radiation: Practical
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);
const SIGMA = 5.670374e-8;     // W/(m^2 K^4)
const WIEN_B = 2.897772e-3;    // m K
const H = 6.62607015e-34, C = 2.99792458e8, KB = 1.380649e-23;

function formatPower(watts) {
  if (watts >= 1e6) return `${(watts / 1e6).toFixed(2)} MW`;
  if (watts >= 1e3) return `${(watts / 1e3).toFixed(2)} kW`;
  return `${watts.toFixed(1)} W`;
}

function formatFlux(wm2) {
  if (wm2 >= 1e9) return `${(wm2 / 1e9).toFixed(2)} GW/m\u00B2`;
  if (wm2 >= 1e6) return `${(wm2 / 1e6).toFixed(2)} MW/m\u00B2`;
  if (wm2 >= 1e3) return `${(wm2 / 1e3).toFixed(2)} kW/m\u00B2`;
  return `${wm2.toFixed(1)} W/m\u00B2`;
}

// ---------------------------------------------------------------------------
// 1. Surface picker
// ---------------------------------------------------------------------------

const surfaceSelect = el("surface-select");
const sliderSurfT = el("slider-surfT");
const sliderSurfA = el("slider-surfA");

function updateSurface() {
  const eps = parseFloat(surfaceSelect.value);
  const tempK = parseFloat(sliderSurfT.value);
  const area = parseFloat(sliderSurfA.value);
  el("val-surfT").textContent = tempK;
  el("val-surfA").textContent = area.toFixed(1);

  el("value-abs").textContent = `${(eps * 100).toFixed(0)}%`;
  el("value-ref").textContent = `${((1 - eps) * 100).toFixed(0)}%`;
  el("bar-abs").style.width = `${eps * 100}%`;
  el("bar-ref").style.width = `${(1 - eps) * 100}%`;

  const bb = SIGMA * area * Math.pow(tempK, 4);
  el("value-emit").textContent = formatPower(eps * bb);
  el("value-bb").textContent = formatPower(bb);
}

[surfaceSelect, sliderSurfT, sliderSurfA].forEach((input) => {
  input.addEventListener("input", updateSurface);
  input.addEventListener("change", updateSurface);
});

// ---------------------------------------------------------------------------
// 2. T^4 demo
// ---------------------------------------------------------------------------

const sliderMult = el("slider-mult");
const T4_BASE = 300;

function updateT4() {
  const m = parseFloat(sliderMult.value);
  el("val-mult").textContent = m.toFixed(1);

  const tempK = T4_BASE * m;
  const power = SIGMA * Math.pow(tempK, 4);
  const pRatio = Math.pow(m, 4);

  el("value-tratio").textContent = `\u00D7${m.toFixed(1)}`;
  el("value-pratio").textContent = `\u00D7${pRatio.toFixed(1)}`;
  el("bar-tratio").style.width = `${(m / 4) * 100}%`;
  el("bar-pratio").style.width = `${(pRatio / 256) * 100}%`;

  el("value-t4T").textContent = `${tempK.toFixed(0)} K`;
  el("value-t4P").textContent = formatFlux(power);
  el("t4-note").textContent = `Temperature \u00D7${m.toFixed(1)} \u2192 power \u00D7${pRatio.toFixed(1)}. (Bars are scaled to the slider's maximum: \u00D74 temperature, \u00D7256 power.)`;
}

sliderMult.addEventListener("input", updateT4);

// ---------------------------------------------------------------------------
// 3. Live blackbody spectrum
// ---------------------------------------------------------------------------

const planckCanvas = el("planck-canvas");
const planckCtx = planckCanvas.getContext("2d");
const sliderPlanckT = el("slider-planckT");

function resizePlanckCanvas() {
  const wrap = planckCanvas.parentElement;
  planckCanvas.width = wrap.clientWidth * devicePixelRatio;
  planckCanvas.height = wrap.clientHeight * devicePixelRatio;
  planckCanvas.style.width = wrap.clientWidth + "px";
  planckCanvas.style.height = wrap.clientHeight + "px";
  planckCtx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
}

// Planck radiant exitance per unit wavelength, M_lambda (W / m^3), pi * B_lambda
function planckExitance(lamM, tempK) {
  const x = (H * C) / (lamM * KB * tempK);
  if (x > 700) return 0;
  return (2 * Math.PI * H * C * C) / (Math.pow(lamM, 5) * (Math.exp(x) - 1));
}

// Tanner Helland's approximation of blackbody colour (valid roughly 1000-40000 K)
function blackbodyRGB(tempK) {
  const t = Math.min(40000, Math.max(1000, tempK)) / 100;
  const clamp = (v) => Math.max(0, Math.min(255, v));
  const r = t <= 66 ? 255 : 329.698727446 * Math.pow(t - 60, -0.1332047592);
  const g = t <= 66 ? 99.4708025861 * Math.log(t) - 161.1195681661 : 288.1221695283 * Math.pow(t - 60, -0.0755148492);
  const b = t >= 66 ? 255 : t <= 19 ? 0 : 138.5177312231 * Math.log(t - 10) - 305.0447927307;
  return [clamp(r), clamp(g), clamp(b)];
}

function glowDescription(tempK) {
  if (tempK < 1000) return "No visible glow \u2014 emission is almost entirely infrared.";
  if (tempK < 1700) return "Dull red glow (like a just-glowing heating element).";
  if (tempK < 2500) return "Orange glow (candle flame, white-hot is still ahead).";
  if (tempK < 3500) return "Yellow-orange (incandescent bulb filament range).";
  if (tempK < 5000) return "Yellow-white.";
  if (tempK < 6500) return "White (Sun-like).";
  return "Blue-white (hotter than the Sun).";
}

function updateGlow(tempK) {
  const swatch = el("glow-swatch");
  if (tempK < 1000) {
    swatch.style.background = "#0F1216";
  } else {
    const [r, g, b] = blackbodyRGB(tempK);
    const intensity = tempK < 1800 ? Math.max(0.25, (tempK - 900) / 900) : 1;
    swatch.style.background = `rgb(${Math.round(r * intensity)}, ${Math.round(g * intensity)}, ${Math.round(b * intensity)})`;
  }
  el("value-glow").textContent = glowDescription(tempK);
}

function visibleFraction(tempK) {
  let visible = 0;
  for (let nm = 380; nm <= 700; nm += 1) visible += planckExitance(nm * 1e-9, tempK) * 1e-9;
  return visible / (SIGMA * Math.pow(tempK, 4));
}

function formatLength(m) {
  const nm = m * 1e9;
  return nm >= 1000 ? `${(nm / 1000).toFixed(2)} \u00B5m` : `${nm.toFixed(0)} nm`;
}

function drawPlanck() {
  const tempK = parseFloat(sliderPlanckT.value);
  el("val-planckT").textContent = tempK;

  const peakM = WIEN_B / tempK;
  el("value-peak").textContent = formatLength(peakM);
  el("value-total").textContent = formatFlux(SIGMA * Math.pow(tempK, 4));
  const frac = visibleFraction(tempK);
  el("value-visfrac").textContent = frac < 0.0001 ? "~0%" : `${(frac * 100).toFixed(1)}%`;
  updateGlow(tempK);

  const w = planckCanvas.clientWidth, h = planckCanvas.clientHeight;
  planckCtx.clearRect(0, 0, w, h);
  const pad = { left: 50, right: 20, top: 20, bottom: 40 };

  // x-axis range: at least 0-3000 nm, widened so the peak never sits at the far edge
  const peakNm = peakM * 1e9;
  const maxNm = Math.max(3000, Math.ceil((peakNm * 3.2) / 500) * 500);
  const peakVal = planckExitance(peakM, tempK);

  const toPx = (nm, v) => ({
    x: pad.left + (nm / maxNm) * (w - pad.left - pad.right),
    y: h - pad.bottom - (v / (peakVal * 1.08)) * (h - pad.top - pad.bottom),
  });

  // visible band
  const v0 = toPx(380, 0), v1 = toPx(700, 0);
  planckCtx.fillStyle = "rgba(237,234,226,0.18)";
  planckCtx.fillRect(v0.x, pad.top, Math.max(2, v1.x - v0.x), h - pad.top - pad.bottom);

  // axes
  planckCtx.strokeStyle = "#262B33";
  planckCtx.lineWidth = 1;
  planckCtx.beginPath();
  planckCtx.moveTo(pad.left, pad.top);
  planckCtx.lineTo(pad.left, h - pad.bottom);
  planckCtx.lineTo(w - pad.right, h - pad.bottom);
  planckCtx.stroke();

  planckCtx.fillStyle = "#9AA1AC";
  planckCtx.font = "12px Inter, sans-serif";
  planckCtx.textAlign = "center";
  planckCtx.fillText("Wavelength (nm)", (pad.left + w - pad.right) / 2, h - 10);
  planckCtx.save();
  planckCtx.translate(16, (pad.top + h - pad.bottom) / 2);
  planckCtx.rotate(-Math.PI / 2);
  planckCtx.fillText("Relative power per wavelength", 0, 0);
  planckCtx.restore();

  // x ticks
  planckCtx.font = "10px Inter, sans-serif";
  const tickStep = maxNm <= 3000 ? 500 : maxNm <= 8000 ? 1000 : maxNm <= 20000 ? 2500 : 5000;
  for (let nm = 0; nm <= maxNm; nm += tickStep) {
    const p = toPx(nm, 0);
    planckCtx.fillText(String(nm), p.x, h - pad.bottom + 14);
  }

  // curve
  planckCtx.strokeStyle = "#E8734A";
  planckCtx.lineWidth = 2.5;
  planckCtx.beginPath();
  const steps = 400;
  for (let i = 1; i <= steps; i++) {
    const nm = (i / steps) * maxNm;
    const p = toPx(nm, planckExitance(nm * 1e-9, tempK));
    if (i === 1) planckCtx.moveTo(p.x, p.y);
    else planckCtx.lineTo(p.x, p.y);
  }
  planckCtx.stroke();

  // peak marker
  const pk = toPx(peakNm, peakVal);
  planckCtx.fillStyle = "#EDEAE2";
  planckCtx.beginPath();
  planckCtx.arc(pk.x, pk.y, 5, 0, Math.PI * 2);
  planckCtx.fill();
  planckCtx.strokeStyle = "rgba(237,234,226,0.4)";
  planckCtx.setLineDash([4, 3]);
  planckCtx.lineWidth = 1;
  planckCtx.beginPath();
  planckCtx.moveTo(pk.x, pk.y);
  planckCtx.lineTo(pk.x, h - pad.bottom);
  planckCtx.stroke();
  planckCtx.setLineDash([]);
  planckCtx.font = "11px Inter, sans-serif";
  planckCtx.textAlign = pk.x > w - 90 ? "right" : "left";
  planckCtx.fillStyle = "#EDEAE2";
  planckCtx.fillText(`peak ${formatLength(peakM)}`, pk.x + (pk.x > w - 90 ? -8 : 8), pk.y - 6);
}

sliderPlanckT.addEventListener("input", drawPlanck);
window.addEventListener("resize", () => { resizePlanckCanvas(); drawPlanck(); });

// ---------------------------------------------------------------------------
// 4. Sun and Earth
// ---------------------------------------------------------------------------

const sliderSunLam = el("slider-sunLam");

function updateSun() {
  const lamNm = parseFloat(sliderSunLam.value);
  el("val-sunLam").textContent = lamNm;
  el("value-sunT").textContent = `${(WIEN_B / (lamNm * 1e-9)).toFixed(0)} K`;
}

sliderSunLam.addEventListener("input", updateSun);
el("btn-sun").addEventListener("click", () => {
  sliderSunLam.value = 502;
  updateSun();
});

const sliderAlbedo = el("slider-albedo");
const SOLAR_CONSTANT = 1361;
const EARTH_OBSERVED_K = 288;

function updateEarth() {
  const albedo = parseFloat(sliderAlbedo.value);
  el("val-albedo").textContent = albedo.toFixed(2);

  const tempK = Math.pow((SOLAR_CONSTANT * (1 - albedo)) / (4 * SIGMA), 0.25);
  el("value-earthK").textContent = `${tempK.toFixed(1)} K`;
  el("value-earthC").textContent = `${(tempK - 273.15).toFixed(1)} \u00B0C`;
  el("value-greenhouse").textContent = `${(EARTH_OBSERVED_K - tempK).toFixed(1)} K`;
}

sliderAlbedo.addEventListener("input", updateEarth);

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------

updateSurface();
updateT4();
resizePlanckCanvas();
drawPlanck();
updateSun();
updateEarth();