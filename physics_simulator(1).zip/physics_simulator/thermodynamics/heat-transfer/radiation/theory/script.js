// ---------------------------------------------------------------------------
// Radiation: Theory page
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);
const SVG_NS = "http://www.w3.org/2000/svg";
function makeEl(tag, attrs) {
  const node = document.createElementNS(SVG_NS, tag);
  Object.entries(attrs).forEach(([k, v]) => node.setAttribute(k, v));
  return node;
}

function renderFormula(elementId, latex, displayMode) {
  const target = el(elementId);
  try {
    katex.render(latex, target, { throwOnError: false, displayMode: !!displayMode });
  } catch (e) {
    target.textContent = latex;
  }
}

renderFormula("formula-art", "a + r + t = 1", true);
renderFormula("formula-sb", "P = \\varepsilon \\sigma A T^4");
renderFormula("formula-wien", "\\lambda_{max}\\, T = b = 2.898\\times10^{-3}\\ \\text{m·K}");
renderFormula("formula-planck", "M_\\lambda = \\dfrac{2\\pi h c^2}{\\lambda^5}\\,\\dfrac{1}{e^{hc/\\lambda k T}-1}");

// ---------------------------- EM spectrum strip ----------------------------

const svg = el("em-spectrum");

const REGIONS = [
  { name: "Radio", range: "> 1 mm", color: "#262B33" },
  { name: "Microwave", range: "1 mm – 1 cm", color: "#2c3239" },
  { name: "Infrared", range: "700 nm – 1 mm", color: "#E8734A", highlight: true },
  { name: "Visible", range: "380 – 700 nm", color: "url(#visibleGradient)", highlight: true },
  { name: "Ultraviolet", range: "10 – 380 nm", color: "#2c3239" },
  { name: "X-ray", range: "0.01 – 10 nm", color: "#262B33" },
  { name: "Gamma", range: "< 0.01 nm", color: "#2c3239" },
];

(function drawSpectrum() {
  const defs = makeEl("defs", {});
  const grad = makeEl("linearGradient", { id: "visibleGradient", x1: "0%", y1: "0%", x2: "100%", y2: "0%" });
  [["0%", "#8a4fff"], ["20%", "#4f6bff"], ["40%", "#4fd48a"], ["60%", "#e8e04f"], ["80%", "#ff9a3c"], ["100%", "#ff4f4f"]].forEach(([offset, color]) => {
    grad.appendChild(makeEl("stop", { offset, "stop-color": color }));
  });
  defs.appendChild(grad);
  svg.appendChild(defs);

  const boxW = 86, gap = 6, top = 36, boxH = 44;
  REGIONS.forEach((r, i) => {
    const x = 6 + i * (boxW + gap);
    svg.appendChild(makeEl("rect", { x, y: top, width: boxW, height: boxH, rx: 6, fill: r.color, stroke: r.highlight ? "#EDEAE2" : "#262B33", "stroke-width": r.highlight ? 1.5 : 1 }));

    const name = makeEl("text", { x: x + boxW / 2, y: top + boxH / 2 + 4, "text-anchor": "middle", fill: r.highlight ? "#12161c" : "#EDEAE2", "font-size": 12, "font-weight": 600, "font-family": "Inter, sans-serif" });
    name.textContent = r.name;
    svg.appendChild(name);

    const range = makeEl("text", { x: x + boxW / 2, y: top + boxH + 18, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 10, "font-family": "Inter, sans-serif" });
    range.textContent = r.range;
    svg.appendChild(range);
  });

  const title = makeEl("text", { x: 6, y: 20, fill: "#9AA1AC", "font-size": 11, "font-family": "Inter, sans-serif" });
  title.textContent = "Longer wavelength  →  shorter wavelength   (boxes not to scale)";
  svg.appendChild(title);

  const note = makeEl("text", { x: 320, y: 118, "text-anchor": "middle", fill: "#E8734A", "font-size": 11, "font-family": "Inter, sans-serif" });
  note.textContent = "Thermal radiation at everyday temperatures is mostly infrared";
  svg.appendChild(note);
})();