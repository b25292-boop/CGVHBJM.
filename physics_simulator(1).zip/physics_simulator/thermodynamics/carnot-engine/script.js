// Carnot Engine Lab: 1 mol ideal diatomic gas. Units: V in litres, P in kPa, T in K, energy in J.
const $ = (id) => document.getElementById(id);
const R = 8.314, G = 1.4, DUR = 4; // gas constant, heat-capacity ratio, seconds per step at 1x
const S = { Th: 600, Tc: 300, r: 2, speed: 1, log: false, play: true, ph: 0 };
const ACC = { Qin: 0, Qout: 0, W: 0, cyc: 0, tot: 0 };

const STEPS = [
  { t: "A → B  Isothermal expansion", c: "#ff6b57", tx: "The gas touches the hot reservoir and expands slowly at constant T<sub>H</sub>. Its internal energy does not change, so every joule of heat absorbed becomes work done by the gas. Entropy rises.", f: "Q_H = W_{AB} = nRT_H\\ln\\dfrac{V_B}{V_A}" },
  { t: "B → C  Adiabatic expansion", c: "#f2b134", tx: "The gas is insulated, so Q = 0. It keeps expanding and pays for the work from its own internal energy, so the temperature falls from T<sub>H</sub> to T<sub>C</sub>. Entropy stays constant.", f: "T_H V_B^{\\gamma-1} = T_C V_C^{\\gamma-1}" },
  { t: "C → D  Isothermal compression", c: "#4dabf7", tx: "The gas touches the cold reservoir and is compressed slowly at constant T<sub>C</sub>. Work done on the gas leaves as heat Q<sub>C</sub> into the cold reservoir. Entropy falls.", f: "Q_C = nRT_C\\ln\\dfrac{V_C}{V_D}" },
  { t: "D → A  Adiabatic compression", c: "#7bd88f", tx: "Insulated again, the gas is compressed until its temperature climbs back to T<sub>H</sub>. The gas returns exactly to state A and the cycle closes.", f: "T_C V_D^{\\gamma-1} = T_H V_A^{\\gamma-1}" },
];

// ---------- physics ----------
function geo() {
  const k = Math.pow(S.Th / S.Tc, 1 / (G - 1));
  const V = [1, S.r, S.r * k, k];
  return { V, dS: R * Math.log(S.r) };
}
function state(seg, t) {
  const g = geo(), a = g.V[seg], b = g.V[(seg + 1) % 4];
  const v = a * Math.pow(b / a, t); // geometric in V so entropy is linear in t on the isotherms
  let T;
  if (seg === 0) T = S.Th;
  else if (seg === 2) T = S.Tc;
  else if (seg === 1) T = S.Th * Math.pow(g.V[1] / v, G - 1);
  else T = S.Tc * Math.pow(g.V[3] / v, G - 1);
  const s = seg === 0 ? g.dS * t : seg === 1 ? g.dS : seg === 2 ? g.dS * (1 - t) : 0;
  return { seg, t, v, T, p: R * T / v, S: s };
}
function cur() {
  const i = Math.floor(S.ph), seg = i % 4;
  return state(seg, S.ph - i);
}
function theory() {
  const Qh = R * S.Th * Math.log(S.r), Qc = R * S.Tc * Math.log(S.r);
  return { Qh, Qc, W: Qh - Qc, eta: 1 - S.Tc / S.Th };
}

let CURVES = { pv: [], ts: [] }, CORNERS = [];
function rebuild() {
  CURVES = { pv: [], ts: [] };
  for (let i = 0; i < 4; i++) {
    const pts = [];
    for (let j = 0; j <= 60; j++) pts.push(state(i, j / 60));
    CURVES.pv.push(pts.map((s) => ({ ...s, x: s.v, y: s.p })));
    CURVES.ts.push(pts.map((s) => ({ ...s, x: s.S, y: s.T })));
  }
  CORNERS = [0, 1, 2, 3].map((i) => state(i, 0));
}
function resetAcc() { ACC.Qin = ACC.Qout = ACC.W = 0; }

function advance(dt) {
  const o = cur();
  S.ph += (dt * S.speed) / DUR;
  if (S.ph >= 4) {
    S.ph -= 4;
    ACC.cyc++; ACC.tot += ACC.W;
    ACC.Qin = ACC.Qout = ACC.W = 0;
  }
  const n = cur(), dW = ((n.p + o.p) / 2) * (n.v - o.v); // kPa·L = J
  ACC.W += dW;
  if (n.seg === 0) ACC.Qin += dW;
  if (n.seg === 2) ACC.Qout -= dW;
}

// ---------- canvas helpers ----------
function fit(cv, h) {
  const w = cv.parentElement.clientWidth, d = window.devicePixelRatio || 1;
  cv._w = w; cv._h = h;
  cv.width = w * d; cv.height = h * d;
  cv.style.width = w + "px"; cv.style.height = h + "px";
  cv.getContext("2d").setTransform(d, 0, 0, d, 0, 0);
}
function ticks(a, b, log) {
  const out = [];
  if (log) {
    for (let e = Math.floor(Math.log10(a)) - 1; e <= Math.ceil(Math.log10(b)); e++)
      for (const m of [1, 2, 5]) { const v = m * Math.pow(10, e); if (v >= a && v <= b) out.push(v); }
    return out;
  }
  const raw = (b - a) / 5, pw = Math.pow(10, Math.floor(Math.log10(raw))), m = raw / pw;
  const s = (m < 1.5 ? 1 : m < 3 ? 2 : m < 7 ? 5 : 10) * pw;
  for (let v = Math.ceil(a / s) * s; v <= b; v += s) out.push(+v.toFixed(10));
  return out;
}
const fmt = (v) => (v >= 1000 ? +(v / 1000).toFixed(1) + "k" : +v.toFixed(2) + "");
for (const id of ["pv", "ts"]) {
  const cv = $(id);
  cv.addEventListener("mousemove", (e) => { const r = cv.getBoundingClientRect(); cv._m = { x: e.clientX - r.left, y: e.clientY - r.top }; });
  cv.addEventListener("mouseleave", () => { cv._m = null; });
}

function chart(cv, o) {
  const c = cv.getContext("2d"), w = cv._w, h = cv._h, pd = { l: 58, r: 14, t: 12, b: 44 };
  const iw = w - pd.l - pd.r, ih = h - pd.t - pd.b;
  const A = o.curves.flatMap((k) => k);
  let x1 = Math.max(...A.map((p) => p.x)), y1 = Math.max(...A.map((p) => p.y)), x0 = 0, y0 = 0;
  if (o.log) { x0 = Math.min(...A.map((p) => p.x)) * 0.8; y0 = Math.min(...A.map((p) => p.y)) * 0.8; x1 *= 1.25; y1 *= 1.25; }
  else { x1 *= 1.06; y1 *= 1.08; }
  const L = Math.log;
  const X = (v) => pd.l + (o.log ? (L(v) - L(x0)) / (L(x1) - L(x0)) : (v - x0) / (x1 - x0)) * iw;
  const Y = (v) => pd.t + ih - (o.log ? (L(v) - L(y0)) / (L(y1) - L(y0)) : (v - y0) / (y1 - y0)) * ih;
  c.clearRect(0, 0, w, h);
  c.font = "11px system-ui"; c.lineWidth = 1; c.strokeStyle = "#202738"; c.fillStyle = "#8e97aa";
  c.textAlign = "center";
  for (const v of ticks(x0, x1, o.log)) { const x = X(v); c.beginPath(); c.moveTo(x, pd.t); c.lineTo(x, pd.t + ih); c.stroke(); c.fillText(fmt(v), x, pd.t + ih + 15); }
  c.textAlign = "right";
  for (const v of ticks(y0, y1, o.log)) { const y = Y(v); c.beginPath(); c.moveTo(pd.l, y); c.lineTo(pd.l + iw, y); c.stroke(); c.fillText(fmt(v), pd.l - 6, y + 4); }
  c.fillStyle = "#b5bccb"; c.font = "12px system-ui"; c.textAlign = "center";
  c.fillText(o.xl, pd.l + iw / 2, h - 8);
  c.save(); c.translate(13, pd.t + ih / 2); c.rotate(-Math.PI / 2); c.fillText(o.yl, 0, 0); c.restore();
  c.strokeStyle = "#3a4358"; c.beginPath(); c.moveTo(pd.l, pd.t); c.lineTo(pd.l, pd.t + ih); c.lineTo(pd.l + iw, pd.t + ih); c.stroke();

  c.beginPath();
  A.forEach((p, i) => (i ? c.lineTo(X(p.x), Y(p.y)) : c.moveTo(X(p.x), Y(p.y))));
  c.closePath(); c.fillStyle = "rgba(111,207,151,.13)"; c.fill();

  const act = cur().seg;
  o.curves.forEach((k, i) => {
    c.beginPath();
    k.forEach((p, j) => (j ? c.lineTo(X(p.x), Y(p.y)) : c.moveTo(X(p.x), Y(p.y))));
    c.strokeStyle = STEPS[i].c; c.globalAlpha = i === act ? 1 : 0.5; c.lineWidth = i === act ? 3.5 : 2;
    c.shadowColor = STEPS[i].c; c.shadowBlur = i === act ? 10 : 0; c.stroke();
    c.shadowBlur = 0; c.globalAlpha = 1;
  });
  c.font = "bold 12px system-ui"; c.textAlign = "center";
  CORNERS.forEach((s, i) => {
    const x = o.cx(s), y = Y(o.cy(s));
    c.fillStyle = "#e8eaf0"; c.beginPath(); c.arc(X(o.cx(s)), y, 3.5, 0, 6.3); c.fill();
    c.fillText("ABCD"[i], X(o.cx(s)) + (i === 0 || i === 3 ? -11 : 11), y + (i < 2 ? -8 : 15));
  });
  c.fillStyle = "#8fa89a"; c.font = "11.5px system-ui"; c.textAlign = "right";
  c.fillText(o.note, pd.l + iw - 4, pd.t + 14);

  const s = cur(), mx = X(o.cx(s)), my = Y(o.cy(s));
  c.fillStyle = STEPS[act].c; c.shadowColor = STEPS[act].c; c.shadowBlur = 14;
  c.beginPath(); c.arc(mx, my, 6.5, 0, 6.3); c.fill(); c.shadowBlur = 0;
  c.strokeStyle = "#fff"; c.lineWidth = 1.5; c.stroke();

  if (cv._m) {
    let b = null, bd = 500;
    for (const p of A) { const dx = X(p.x) - cv._m.x, dy = Y(p.y) - cv._m.y, d = dx * dx + dy * dy; if (d < bd) { bd = d; b = p; } }
    if (b) {
      const bx = X(b.x), by = Y(b.y);
      c.strokeStyle = "#fff"; c.lineWidth = 1.5; c.beginPath(); c.arc(bx, by, 5, 0, 6.3); c.stroke();
      const ln = [`V = ${b.v.toFixed(2)} L`, `P = ${b.p.toFixed(0)} kPa`, `T = ${b.T.toFixed(0)} K`, `S = ${b.S.toFixed(2)} J/K`];
      const tw = 112, th = 66, tx = bx + 14 + tw > w ? bx - 14 - tw : bx + 14, ty = Math.max(4, Math.min(h - th - 4, by - th / 2));
      c.fillStyle = "rgba(10,13,20,.94)"; c.strokeStyle = "#3a4358"; c.lineWidth = 1;
      c.beginPath(); c.roundRect(tx, ty, tw, th, 7); c.fill(); c.stroke();
      c.fillStyle = "#e8eaf0"; c.textAlign = "left"; c.font = "12px system-ui";
      ln.forEach((t, i) => c.fillText(t, tx + 10, ty + 18 + i * 15));
    }
  }
}

// ---------- engine cylinder ----------
const parts = Array.from({ length: 42 }, () => ({ u: Math.random(), v: Math.random(), a: Math.random() * 6.28 }));
function arrow(c, x, y, up, col, al) {
  c.globalAlpha = al; c.fillStyle = col; c.beginPath();
  const d = up ? 1 : -1;
  c.moveTo(x, y - d * 8); c.lineTo(x - 7, y + d * 5); c.lineTo(x + 7, y + d * 5); c.fill(); c.globalAlpha = 1;
}
function cyl(dt, now) {
  const cv = $("cyl"), c = cv.getContext("2d"), w = cv._w, h = cv._h, s = cur(), g = geo();
  c.clearRect(0, 0, w, h);
  const cw = Math.min(140, w - 70), x0 = (w - cw) / 2, base = h - 78, top = 34;
  const f = Math.log(s.v) / Math.log(g.V[2]);
  const gh = 40 + f * (base - top - 74), py = base - gh;

  const res = s.seg === 0 ? ["#ff6b57", "Hot reservoir " + S.Th + " K"] : s.seg === 2 ? ["#4dabf7", "Cold reservoir " + S.Tc + " K"] : ["#3a4152", "Insulating stand"];
  c.shadowColor = res[0]; c.shadowBlur = s.seg % 2 === 0 ? 22 : 0;
  c.fillStyle = res[0]; c.beginPath(); c.roundRect(x0 - 20, base, cw + 40, 54, 8); c.fill(); c.shadowBlur = 0;
  c.fillStyle = s.seg % 2 === 0 ? "#12151c" : "#c5cbd8"; c.font = "600 13px system-ui"; c.textAlign = "center";
  c.fillText(res[1], w / 2, base + 31);

  const hot = (s.T - S.Tc) / (S.Th - S.Tc);
  c.fillStyle = `rgba(${Math.round(70 + 185 * hot)},${Math.round(130 - 40 * hot)},${Math.round(240 - 170 * hot)},.3)`;
  c.fillRect(x0, py, cw, gh);
  const sp = Math.sqrt(s.T) * 9;
  c.fillStyle = "#f3f5fa";
  for (const p of parts) {
    p.u += Math.cos(p.a) * sp * dt / cw; p.v += Math.sin(p.a) * sp * dt / gh;
    if (p.u < 0 || p.u > 1) { p.a = Math.PI - p.a; p.u = Math.max(0, Math.min(1, p.u)); }
    if (p.v < 0 || p.v > 1) { p.a = -p.a; p.v = Math.max(0, Math.min(1, p.v)); }
    c.beginPath(); c.arc(x0 + p.u * cw, py + p.v * gh, 2.6, 0, 6.3); c.fill();
  }
  c.fillStyle = "#6b7385"; c.fillRect(x0 + 2, py - 14, cw - 4, 14);
  c.fillStyle = "#8a92a4"; c.fillRect(w / 2 - 5, top - 14, 10, py - top + 2);
  c.fillRect(w / 2 - 28, top - 20, 56, 8);
  c.strokeStyle = "#4a5368"; c.lineWidth = 4; c.lineJoin = "round";
  c.beginPath(); c.moveTo(x0, top); c.lineTo(x0, base); c.lineTo(x0 + cw, base); c.lineTo(x0 + cw, top); c.stroke();

  if (s.seg === 0 || s.seg === 2) {
    const up = s.seg === 0, col = up ? "#ff6b57" : "#4dabf7";
    for (let k = 0; k < 3; k++) {
      const o = ((now / 18 + k * 16) % 48), x = x0 + cw * (0.2 + 0.3 * k);
      const y = up ? base + 32 - o : base - 22 + o;
      arrow(c, x, y, up, col, 1 - o / 52);
    }
    c.fillStyle = col; c.font = "600 12px system-ui"; c.textAlign = "left";
    c.fillText(up ? "Q_H flows in" : "Q_C flows out", 8, h - 8);
  } else {
    c.fillStyle = "#8e97aa"; c.font = "12px system-ui"; c.textAlign = "left"; c.fillText("No heat exchange (Q = 0)", 8, h - 8);
  }
  c.fillStyle = "#e8eaf0"; c.font = "600 13px system-ui"; c.textAlign = "left";
  c.fillText("T = " + s.T.toFixed(0) + " K", 8, 18);
  c.textAlign = "right"; c.fillText("V = " + s.v.toFixed(2) + " L", w - 8, 18);
}

// ---------- UI ----------
let shownSeg = -1;
function showStep(i) {
  shownSeg = i;
  const st = STEPS[i];
  $("sTitle").textContent = st.t; $("sText").innerHTML = st.tx;
  const fe = $("sFormula"); fe.innerHTML = "";
  if (window.katex) katex.render(st.f, fe, { throwOnError: false, displayMode: true }); else fe.textContent = st.f;
  document.querySelectorAll(".chip").forEach((ch, k) => {
    ch.classList.toggle("on", k === i);
    ch.style.background = k === i ? STEPS[k].c : "transparent";
    ch.style.borderColor = STEPS[k].c;
  });
}
STEPS.forEach((st, i) => {
  const b = document.createElement("button");
  b.className = "chip"; b.textContent = st.t.split("  ")[0];
  b.addEventListener("click", () => { S.ph = i; resetAcc(); });
  $("chips").appendChild(b);
});

function readout() {
  const s = cur(), th = theory();
  $("sT").textContent = s.T.toFixed(0) + " K";
  $("sP").textContent = s.p.toFixed(0) + " kPa";
  $("sV").textContent = s.v.toFixed(2) + " L";
  $("sS").textContent = s.S.toFixed(2) + " J/K";
  $("eta").textContent = (th.eta * 100).toFixed(1) + "%";
  $("cyc").textContent = ACC.cyc + " · " + ACC.tot.toFixed(0) + " J";
  const bar = (id, tid, v, tot) => { $(id).style.width = Math.max(0, Math.min(100, (v / tot) * 100)) + "%"; $(tid).textContent = Math.max(0, v).toFixed(0) + " / " + tot.toFixed(0) + " J"; };
  bar("bQ", "tQ", ACC.Qin, th.Qh); bar("bC", "tC", ACC.Qout, th.Qh); bar("bW", "tW", ACC.W, th.Qh);
  $("bC").parentElement.title = "Bars are scaled to Q_H";
}

function sizes() {
  fit($("cyl"), 330);
  const ch = Math.max(280, Math.min(340, $("pv").parentElement.clientWidth * 0.78));
  fit($("pv"), ch); fit($("ts"), ch);
}
function params() {
  S.Th = +$("rTh").value; S.Tc = +$("rTc").value; S.r = +$("rR").value; S.speed = +$("rSp").value; S.log = $("cLog").checked;
  $("vTh").textContent = S.Th + " K"; $("vTc").textContent = S.Tc + " K";
  $("vR").textContent = S.r.toFixed(1); $("vSp").textContent = S.speed.toFixed(2).replace(/0$/, "") + "×";
  rebuild();
}
["rTh", "rTc", "rR"].forEach((id) => $(id).addEventListener("input", () => { params(); resetAcc(); }));
["rSp", "cLog"].forEach((id) => $(id).addEventListener("input", params));
$("bReset").addEventListener("click", () => { S.ph = 0; resetAcc(); ACC.cyc = 0; ACC.tot = 0; });
function toggle() { S.play = !S.play; $("bPlay").textContent = S.play ? "Pause" : "Play"; }
$("bPlay").addEventListener("click", toggle);
document.addEventListener("keydown", (e) => { if (e.code === "Space" && e.target.tagName !== "BUTTON" && e.target.tagName !== "INPUT") { e.preventDefault(); toggle(); } });
window.addEventListener("resize", sizes);

let last = performance.now();
function frame(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  if (S.play) advance(dt);
  const seg = cur().seg;
  if (seg !== shownSeg) showStep(seg);
  chart($("pv"), { curves: CURVES.pv, xl: "Volume V (L)", yl: "Pressure P (kPa)", log: S.log, cx: (s) => s.v, cy: (s) => s.p, note: "Enclosed area = net work W" });
  chart($("ts"), { curves: CURVES.ts, xl: "Entropy change ΔS (J/K)", yl: "Temperature T (K)", log: false, cx: (s) => s.S, cy: (s) => s.T, note: "Area under top edge = Q_H" });
  cyl(dt, now);
  readout();
  requestAnimationFrame(frame);
}
params(); sizes();
requestAnimationFrame(frame);