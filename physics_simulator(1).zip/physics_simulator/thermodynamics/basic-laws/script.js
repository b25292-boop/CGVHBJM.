// ---------------------------------------------------------------------------
// Basic Gas Laws simulator — talks to the FastAPI backend (physics.py/main.py)
// ---------------------------------------------------------------------------

const API_BASE = "http://127.0.0.1:8000"; // change to your deployed backend URL

let sessionId = null;
let currentLaw = "boyle";   // 'boyle' | 'charles' | 'gaylussac'
let currentGraph = "pv";     // 'pv' | 'pt' | 'vt'
let mode = "setup";          // 'setup' -> pick P, T, n freely (V computed) | 'running' -> law demo with 2 constants locked
let history = [];            // full log of every state this session (used to read "current" values)
let curvePoints = [];         // points belonging to the CURRENT curve only (resets on law switch / start)

// UI unit conversions: backend uses SI (Pa, m^3), sliders use kPa, L for readability
const kPaToPa = (kpa) => kpa * 1000;
const paTokPa = (pa) => pa / 1000;
const litersToM3 = (L) => L / 1000;
const m3ToLiters = (m3) => m3 * 1000;

const el = (id) => document.getElementById(id);
const statusEl = el("status");

const sliders = {
  P: el("slider-P"),
  V: el("slider-V"),
  T: el("slider-T"),
  n: el("slider-n"),
};
const vals = { P: el("val-P"), V: el("val-V"), T: el("val-T"), n: el("val-n") };
const reads = { P: el("read-P"), V: el("read-V"), T: el("read-T"), n: el("read-n") };
const ctrls = { P: el("ctrl-P"), V: el("ctrl-V"), T: el("ctrl-T"), n: el("ctrl-n") };

const els = { status: statusEl, disclaimer: el("disclaimer") };
const btnStart = el("btn-start");
const btnResetSetup = el("btn-reset-setup");

// During SETUP: Pressure, Temperature, and Moles are freely adjustable —
// Volume is the computed/dependent quantity (PV = nRT has 3 independent inputs).
// Pressing "Start Experiment" freezes the law's namesake constant AND moles,
// leaving exactly the two variables named by the law free to trade off.
const LAW_CONFIG = {
  boyle:      { locked: "T", pair: ["P", "V"],
                explain: (s) => `Fixed for this run: T = ${s.T.toFixed(0)} K and n = ${s.n.toFixed(2)} mol. Boyle's Law — only pressure and volume are allowed to change. Drag either slider; the other adjusts to keep PV = nRT.` },
  charles:    { locked: "P", pair: ["T", "V"],
                explain: (s) => `Fixed for this run: P = ${paTokPa(s.P).toFixed(1)} kPa and n = ${s.n.toFixed(2)} mol. Charles's Law — only temperature and volume are allowed to change.` },
  gaylussac:  { locked: "V", pair: ["T", "P"],
                explain: (s) => `Fixed for this run: V = ${m3ToLiters(s.V).toFixed(2)} L and n = ${s.n.toFixed(2)} mol. Gay-Lussac's Law — the container is sealed, so only temperature and pressure change.` },
};

function setStatus(msg, isError = false) {
  statusEl.textContent = msg;
  statusEl.classList.toggle("error", isError);
}

function updateReadouts(state) {
  // state is in SI units {P (Pa), V (m^3), T (K), n (mol)}
  reads.P.textContent = `${paTokPa(state.P).toFixed(1)} kPa`;
  reads.V.textContent = `${m3ToLiters(state.V).toFixed(2)} L`;
  reads.T.textContent = `${state.T.toFixed(0)} K`;
  reads.n.textContent = `${state.n.toFixed(2)} mol`;
}

function syncSlidersToState(state) {
  sliders.P.value = paTokPa(state.P).toFixed(1);
  sliders.V.value = m3ToLiters(state.V).toFixed(2);
  sliders.T.value = state.T.toFixed(0);
  sliders.n.value = state.n.toFixed(2);
  vals.P.textContent = sliders.P.value;
  vals.V.textContent = sliders.V.value;
  vals.T.textContent = sliders.T.value;
  vals.n.textContent = sliders.n.value;
}

function applySliderEnablement() {
  Object.keys(ctrls).forEach((key) => {
    ctrls[key].classList.remove("locked");
    sliders[key].disabled = false;
  });

  if (mode === "setup") {
    // Volume is the dependent variable during setup — P, T, n are the free inputs.
    ctrls.V.classList.add("locked");
    sliders.V.disabled = true;
  } else {
    // Running: the law's namesake variable AND moles are frozen for this run.
    const cfg = LAW_CONFIG[currentLaw];
    ctrls[cfg.locked].classList.add("locked");
    sliders[cfg.locked].disabled = true;
    ctrls.n.classList.add("locked");
    sliders.n.disabled = true;
  }
}

function setMode(newMode) {
  mode = newMode;
  applySliderEnablement();
  btnStart.classList.toggle("hidden", mode !== "setup");
  btnResetSetup.classList.toggle("hidden", mode !== "running");

  const last = history[history.length - 1];
  if (!last) return;

  if (mode === "setup") {
    curvePoints = [last];
    els.disclaimer.textContent = "Setup: adjust Pressure, Temperature, and Moles freely — Volume is calculated automatically. Pick a law above, then press \u201cStart Experiment\u201d to fix its constants and begin.";
  } else {
    curvePoints = [last];
    updateDisclaimer(last);
  }
  updateApparatus(last);
}

function updateDisclaimer(state) {
  const cfg = LAW_CONFIG[currentLaw];
  els.disclaimer.textContent = cfg.explain(state);
}

async function initSession() {
  setStatus("Connecting to simulator…");
  try {
    const res = await fetch(`${API_BASE}/simulations/init`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        pressure: kPaToPa(parseFloat(sliders.P.value)),
        volume: litersToM3(parseFloat(sliders.V.value)),
        temperature: parseFloat(sliders.T.value),
        moles: parseFloat(sliders.n.value),
      }),
    });
    if (!res.ok) throw new Error(`Server responded ${res.status}`);
    const data = await res.json();
    sessionId = data.session_id;
    history = [data.state];
    curvePoints = [data.state];
    updateReadouts(data.state);
    drawGraph();
    updateApparatus(data.state);
    setMode("setup");
    setStatus("Connected — adjust Pressure, Temperature, and Moles, then press Start Experiment.");
  } catch (err) {
    setStatus(
      `Couldn't reach the backend at ${API_BASE}. Is it running? (${err.message})`,
      true
    );
  }
}

// SI-unit converters keyed by variable, needed to send correct values to /solve
const toSI = {
  P: (kpa) => kPaToPa(parseFloat(kpa)),
  V: (L) => litersToM3(parseFloat(L)),
  T: (K) => parseFloat(K),
  n: (mol) => parseFloat(mol),
};

async function callSolve(body) {
  const res = await fetch(`${API_BASE}/simulations/${sessionId}/solve`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || `Server responded ${res.status}`);
  }
  return res.json();
}

// SETUP mode: whichever of P, T, n the user moves, Volume is always the
// computed/dependent variable, keeping the state physically consistent.
async function solveSetup(changedKey, newRawValue) {
  if (!sessionId) return;
  const last = history[history.length - 1];
  const body = {
    P: changedKey === "P" ? toSI.P(newRawValue) : last.P,
    T: changedKey === "T" ? toSI.T(newRawValue) : last.T,
    n: changedKey === "n" ? toSI.n(newRawValue) : last.n,
    V: null,
  };
  try {
    const newState = await callSolve(body);
    history.push(newState);
    curvePoints = [newState]; // setup preview is just a single point, not a curve
    updateReadouts(newState);
    syncSlidersToState(newState);
    drawGraph();
    updateApparatus(newState);
    setStatus(
      changedKey === "n"
        ? `Moles set to ${newState.n.toFixed(2)} mol — gas density (particle count) updated.`
        : `Volume calculated: ${m3ToLiters(newState.V).toFixed(2)} L.`
    );
  } catch (err) {
    setStatus(err.message, true);
  }
}

// RUNNING mode: the law's namesake variable and moles are frozen. Drag either
// member of the law's free pair; the other one recomputes via PV = nRT.
async function solveFrom(changedKey, newRawValue) {
  if (!sessionId) return;
  const cfg = LAW_CONFIG[currentLaw];
  const last = history[history.length - 1];
  const computedKey = cfg.pair.find((k) => k !== changedKey);
  if (!computedKey) return; // shouldn't happen — locked variable's slider is disabled

  const body = {};
  ["P", "V", "T", "n"].forEach((key) => {
    if (key === computedKey) body[key] = null;
    else if (key === changedKey) body[key] = toSI[key](newRawValue);
    else body[key] = last[key];
  });

  try {
    const newState = await callSolve(body);
    history.push(newState);
    curvePoints.push(newState);
    updateReadouts(newState);
    syncSlidersToState(newState);
    drawGraph();
    updateApparatus(newState);
    updateDisclaimer(newState);
    setStatus(`Applied ${labelForLaw(currentLaw)}.`);
  } catch (err) {
    setStatus(err.message, true);
  }
}

function labelForLaw(law) {
  return { boyle: "Boyle's Law", charles: "Charles's Law", gaylussac: "Gay-Lussac's Law" }[law];
}

// ---------------------------- Slider wiring ----------------------------

Object.entries(sliders).forEach(([key, slider]) => {
  slider.addEventListener("input", () => {
    vals[key].textContent = slider.value;
  });
  slider.addEventListener("change", () => {
    if (slider.disabled) return;
    if (mode === "setup") solveSetup(key, slider.value);
    else solveFrom(key, slider.value);
  });
});

// ---------------------------- Start / Reset buttons ----------------------------

btnStart.addEventListener("click", () => {
  setMode("running");
  setStatus(`${labelForLaw(currentLaw)} started — constants locked in.`);
});

btnResetSetup.addEventListener("click", () => {
  setMode("setup");
  setStatus("Back to setup — adjust Pressure, Temperature, or Moles, then start again.");
});

// ---------------------------- Law toggle buttons ----------------------------

document.querySelectorAll(".law-toggle button").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".law-toggle button").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    currentLaw = btn.dataset.law;
    updateApparatusMode(currentLaw);
    setMode("setup"); // switching laws means re-choosing constants before running
    setStatus(`Selected ${labelForLaw(currentLaw)} — set your starting values, then press Start.`);
  });
});

// ---------------------------- Graph tabs ----------------------------

document.querySelectorAll(".graph-tabs button").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".graph-tabs button").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    currentGraph = btn.dataset.graph;
    drawGraph();
  });
});

// ---------------------------- Canvas graph ----------------------------

const canvas = el("graph");
const ctx = canvas.getContext("2d");

function resizeCanvas() {
  const wrap = canvas.parentElement;
  canvas.width = wrap.clientWidth * devicePixelRatio;
  canvas.height = wrap.clientHeight * devicePixelRatio;
  canvas.style.width = wrap.clientWidth + "px";
  canvas.style.height = wrap.clientHeight + "px";
  ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
}
window.addEventListener("resize", () => { resizeCanvas(); drawGraph(); });

const AXES = {
  pv: { xKey: "V", yKey: "P", xLabel: "Volume (L)", yLabel: "Pressure (kPa)",
        xUnit: "L", yUnit: "kPa", xConv: m3ToLiters, yConv: paTokPa },
  pt: { xKey: "T", yKey: "P", xLabel: "Temperature (K)", yLabel: "Pressure (kPa)",
        xUnit: "K", yUnit: "kPa", xConv: (v) => v, yConv: paTokPa },
  vt: { xKey: "T", yKey: "V", xLabel: "Temperature (K)", yLabel: "Volume (L)",
        xUnit: "K", yUnit: "L", xConv: (v) => v, yConv: m3ToLiters },
};

function drawGraph() {
  if (!ctx || curvePoints.length === 0) return;
  const w = canvas.clientWidth, h = canvas.clientHeight;
  ctx.clearRect(0, 0, w, h);

  const pad = { left: 56, right: 20, top: 20, bottom: 44 };
  const axis = AXES[currentGraph];

  const points = curvePoints.map((s, i) => ({
    x: axis.xConv(s[axis.xKey]),
    y: axis.yConv(s[axis.yKey]),
    isLatest: i === curvePoints.length - 1,
  }));

  const xs = points.map((p) => p.x), ys = points.map((p) => p.y);
  const xMin = Math.min(...xs) * 0.9, xMax = Math.max(...xs) * 1.1 || 1;
  const yMin = Math.min(...ys) * 0.9, yMax = Math.max(...ys) * 1.1 || 1;

  const toPx = (p) => ({
    x: pad.left + ((p.x - xMin) / (xMax - xMin || 1)) * (w - pad.left - pad.right),
    y: h - pad.bottom - ((p.y - yMin) / (yMax - yMin || 1)) * (h - pad.top - pad.bottom),
  });

  // axes
  ctx.strokeStyle = "#262B33";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(pad.left, pad.top);
  ctx.lineTo(pad.left, h - pad.bottom);
  ctx.lineTo(w - pad.right, h - pad.bottom);
  ctx.stroke();

  // axis labels
  ctx.fillStyle = "#9AA1AC";
  ctx.font = "12px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(axis.xLabel, (pad.left + w - pad.right) / 2, h - 12);
  ctx.save();
  ctx.translate(16, (pad.top + h - pad.bottom) / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText(axis.yLabel, 0, 0);
  ctx.restore();

  if (points.length < 2) {
    // single point — just draw a dot
    const p = toPx(points[0]);
    ctx.fillStyle = "#E8734A";
    ctx.beginPath();
    ctx.arc(p.x, p.y, 5, 0, Math.PI * 2);
    ctx.fill();
    return;
  }

  // Connect points sorted along the x-axis, so the curve renders cleanly
  // even if the slider was dragged back and forth out of order.
  const sortedForLine = [...points].sort((a, b) => a.x - b.x);
  ctx.strokeStyle = "#4FA8B8";
  ctx.lineWidth = 2;
  ctx.beginPath();
  sortedForLine.forEach((p, i) => {
    const px = toPx(p);
    if (i === 0) ctx.moveTo(px.x, px.y);
    else ctx.lineTo(px.x, px.y);
  });
  ctx.stroke();

  // point markers (drawn in original/time order so the true latest point highlights correctly)
  points.forEach((p) => {
    const px = toPx(p);
    ctx.fillStyle = p.isLatest ? "#E8734A" : "#4FA8B8";
    ctx.beginPath();
    ctx.arc(px.x, px.y, p.isLatest ? 6 : 3.5, 0, Math.PI * 2);
    ctx.fill();
  });

  // Label the current point with its exact coordinates, e.g. "V = 10.0 L, P = 235.0 kPa"
  const latest = points.find((p) => p.isLatest);
  if (latest) {
    const px = toPx(latest);
    const label = `${axis.xKey} = ${latest.x.toFixed(1)} ${axis.xUnit}, ${axis.yKey} = ${latest.y.toFixed(1)} ${axis.yUnit}`;

    ctx.font = "12px Inter, sans-serif";
    const textWidth = ctx.measureText(label).width;
    const boxPad = 8;
    // Flip the label above/below and left/right depending on how close to the edges the point is,
    // so it never gets clipped off the canvas.
    const labelX = Math.min(Math.max(px.x - textWidth / 2 - boxPad, 4), w - textWidth - boxPad * 2 - 4);
    const labelY = px.y - 34 >= 0 ? px.y - 34 : px.y + 18;

    ctx.fillStyle = "#181C22";
    ctx.strokeStyle = "#E8734A";
    ctx.lineWidth = 1;
    const boxW = textWidth + boxPad * 2;
    const boxH = 22;
    ctx.beginPath();
    ctx.roundRect(labelX, labelY, boxW, boxH, 5);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = "#EDEAE2";
    ctx.textAlign = "left";
    ctx.fillText(label, labelX + boxPad, labelY + 15);
  }
}

// ---------------------------------------------------------------------------
// Apparatus visualization: cylinder + piston/weights + flame + thermometer + gauge
// ---------------------------------------------------------------------------

const SLIDER_RANGES = {
  P: { min: 20, max: 400 },   // kPa
  T: { min: 100, max: 900 },  // K
};

const CYL = { left: 76, right: 184, top: 45, bottom: 296 }; // usable interior bounds
const PISTON_Y_RANGE = { min: 65, max: 280 }; // piston travel range in px

let particles = [];
let currentPistonY = 180; // top of gas column (px), updated as state changes
let currentTNorm = 0.19;  // normalized 0..1, for particle speed/color
let currentParticleCount = 12;
let animationHandle = null;

function clamp01(x) { return Math.max(0, Math.min(1, x)); }
function lerp(a, b, t) { return a + (b - a) * t; }

// More moles = denser gas = more particles drawn. Slider range is 0.2–5 mol.
function particleCountForMoles(n) {
  return Math.max(6, Math.min(40, Math.round(n * 8)));
}

function initParticles(count) {
  const g = document.getElementById("particles");
  g.innerHTML = "";
  particles = [];
  currentParticleCount = count;
  for (let i = 0; i < count; i++) {
    const x = lerp(CYL.left + 6, CYL.right - 6, Math.random());
    const y = lerp(currentPistonY + 6, CYL.bottom - 6, Math.random());
    const angle = Math.random() * Math.PI * 2;
    particles.push({ x, y, vx: Math.cos(angle), vy: Math.sin(angle) });
    const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    circle.setAttribute("r", "3.5");
    circle.setAttribute("cx", x);
    circle.setAttribute("cy", y);
    circle.setAttribute("fill", "#4FA8B8");
    g.appendChild(circle);
  }
}

function stepParticles() {
  const g = document.getElementById("particles");
  const speed = lerp(0.6, 3.2, currentTNorm); // faster when hotter
  const topBound = currentPistonY + 6;

  particles.forEach((p, i) => {
    p.x += p.vx * speed;
    p.y += p.vy * speed;

    if (p.x < CYL.left + 5 || p.x > CYL.right - 5) p.vx *= -1;
    if (p.y < topBound || p.y > CYL.bottom - 5) p.vy *= -1;
    p.x = Math.max(CYL.left + 5, Math.min(CYL.right - 5, p.x));
    p.y = Math.max(topBound, Math.min(CYL.bottom - 5, p.y));

    const circle = g.children[i];
    if (circle) {
      circle.setAttribute("cx", p.x.toFixed(1));
      circle.setAttribute("cy", p.y.toFixed(1));
      // color shifts teal (cold) -> orange (hot)
      const hueMix = currentTNorm;
      circle.setAttribute("fill", hueMix > 0.55 ? "#E8734A" : "#4FA8B8");
    }
  });
}

function animationLoop() {
  stepParticles();
  animationHandle = requestAnimationFrame(animationLoop);
}

function updateGauge(pressurePa) {
  const pKPa = paTokPa(pressurePa);
  const norm = clamp01((pKPa - SLIDER_RANGES.P.min) / (SLIDER_RANGES.P.max - SLIDER_RANGES.P.min));
  const angleDeg = lerp(-90, 90, norm); // needle sweeps -90..+90
  const needle = document.getElementById("gauge-needle");
  needle.style.transform = `rotate(${angleDeg}deg)`;
}

function updateThermometer(tempK) {
  const norm = clamp01((tempK - SLIDER_RANGES.T.min) / (SLIDER_RANGES.T.max - SLIDER_RANGES.T.min));
  const fullHeight = 140; // matches thermometer tube height in SVG
  const mercuryHeight = lerp(14, fullHeight - 6, norm);
  const mercuryY = 166 - mercuryHeight; // tube bottom is around y=166 before the bulb
  const mercury = document.getElementById("thermo-mercury");
  mercury.setAttribute("y", mercuryY.toFixed(1));
  mercury.setAttribute("height", mercuryHeight.toFixed(1));
  const color = norm > 0.55 ? "#E8734A" : "#4FA8B8";
  mercury.setAttribute("fill", color);
  document.getElementById("thermo-bulb").setAttribute("fill", color);
  currentTNorm = norm;
}

function updatePistonAndWeights(state) {
  const volumeL = m3ToLiters(state.V);
  const vMin = 2, vMax = 80; // matches slider-V range
  const norm = clamp01((volumeL - vMin) / (vMax - vMin));
  // more volume -> piston sits higher (smaller y); less volume -> piston lower (larger y)
  const pistonY = lerp(PISTON_Y_RANGE.max, PISTON_Y_RANGE.min, norm);
  currentPistonY = pistonY;

  const piston = document.getElementById("piston");
  const rod = document.getElementById("piston-rod");
  piston.setAttribute("y", pistonY.toFixed(1));
  rod.setAttribute("y", (pistonY - 40).toFixed(1));
  rod.setAttribute("height", "40");

  // weight blocks stacked above the piston, count reflects pressure above baseline
  const pKPa = paTokPa(state.P);
  const weightCount = Math.max(0, Math.min(6, Math.round((pKPa - 101) / 45)));
  const weightsGroup = document.getElementById("weights");
  weightsGroup.innerHTML = "";
  for (let i = 0; i < weightCount; i++) {
    const blockY = pistonY - 40 - 14 - i * 15;
    const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    rect.setAttribute("x", "96");
    rect.setAttribute("y", blockY.toFixed(1));
    rect.setAttribute("width", "68");
    rect.setAttribute("height", "12");
    rect.setAttribute("rx", "2");
    rect.setAttribute("fill", "#E8734A");
    weightsGroup.appendChild(rect);
  }
}

function updateFlame(law, tempK) {
  const flame = document.getElementById("flame");
  const showFlame = law === "charles" || law === "gaylussac";
  flame.style.display = showFlame ? "block" : "none";
  if (!showFlame) return;
  const norm = clamp01((tempK - SLIDER_RANGES.T.min) / (SLIDER_RANGES.T.max - SLIDER_RANGES.T.min));
  const scale = lerp(0.6, 1.4, norm);
  flame.style.transform = `translate(130px, 385px) scale(${scale}) translate(-130px, -385px)`;
}

function updateApparatusMode(law) {
  const pistonGroup = document.getElementById("piston-group");
  const sealedCap = document.getElementById("sealed-cap");
  const caption = document.getElementById("apparatus-caption");

  if (law === "gaylussac") {
    pistonGroup.style.display = "none";
    sealedCap.style.display = "block";
    caption.textContent = "Gay-Lussac's Law: volume is fixed — heating a sealed container raises pressure.";
  } else {
    pistonGroup.style.display = "block";
    sealedCap.style.display = "none";
    caption.textContent = law === "boyle"
      ? "Boyle's Law: constant temperature — compressing the gas raises pressure as volume shrinks."
      : "Charles's Law: constant pressure — heating the gas expands it, pushing the piston up.";
  }
}

function updateApparatus(state) {
  updateGauge(state.P);
  updateThermometer(state.T);
  updatePistonAndWeights(state);
  updateFlame(currentLaw, state.T);

  const desiredCount = particleCountForMoles(state.n);
  if (desiredCount !== currentParticleCount) {
    initParticles(desiredCount);
  }
}

// ---------------------------- Init ----------------------------

applySliderEnablement();
resizeCanvas();
initParticles(particleCountForMoles(parseFloat(sliders.n.value)));
animationLoop();
updateApparatusMode(currentLaw);
initSession();