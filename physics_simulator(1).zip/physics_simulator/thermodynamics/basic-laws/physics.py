"""
Ideal Gas Law physics engine.

Covers:
  - Boyle's Law   (P1*V1 = P2*V2)      at constant T, n
  - Charles's Law (V1/T1 = V2/T2)      at constant P, n
  - Gay-Lussac's Law (P1/T1 = P2/T2)   at constant V, n
  - General Ideal Gas Law: PV = nRT

Units used throughout:
  P -> Pascals (Pa)
  V -> cubic meters (m^3)
  T -> Kelvin (K)
  n -> moles (mol)
"""

R = 8.314  # Universal gas constant, J/(mol*K)


class IdealGasState:
    """Represents one state of a fixed (or changing) amount of ideal gas."""

    def __init__(self, pressure: float, volume: float, temperature: float, moles: float):
        if pressure <= 0 or volume <= 0 or temperature <= 0 or moles <= 0:
            raise ValueError("Pressure, volume, temperature, and moles must all be positive.")
        self.P = pressure
        self.V = volume
        self.T = temperature
        self.n = moles

    def as_dict(self):
        return {"P": self.P, "V": self.V, "T": self.T, "n": self.n}

    def check_consistency(self, tolerance=1e-2):
        """Returns True if PV ≈ nRT within tolerance (fractional)."""
        lhs = self.P * self.V
        rhs = self.n * R * self.T
        return abs(lhs - rhs) / rhs < tolerance


class IdealGasSimulator:
    """
    Simulates transitions of an ideal gas between two states while holding
    one variable fixed, OR computes the missing variable from PV = nRT.
    """

    def __init__(self, initial: IdealGasState):
        self.state = initial
        self.history = [initial.as_dict()]

    # ---------- Named-law transitions (hold one variable constant) ----------

    def apply_boyles_law(self, new_pressure: float = None, new_volume: float = None):
        """Constant T, n. Provide either new_pressure or new_volume; solves for the other."""
        s = self.state
        if new_pressure is not None and new_volume is not None:
            raise ValueError("Provide only one of new_pressure or new_volume for Boyle's Law.")
        if new_pressure is not None:
            new_volume = (s.P * s.V) / new_pressure
        elif new_volume is not None:
            new_pressure = (s.P * s.V) / new_volume
        else:
            raise ValueError("Must provide new_pressure or new_volume.")
        self.state = IdealGasState(new_pressure, new_volume, s.T, s.n)
        self.history.append(self.state.as_dict())
        return self.state

    def apply_charles_law(self, new_temperature: float = None, new_volume: float = None):
        """Constant P, n. Provide either new_temperature or new_volume; solves for the other."""
        s = self.state
        if new_temperature is not None and new_volume is not None:
            raise ValueError("Provide only one of new_temperature or new_volume for Charles's Law.")
        if new_temperature is not None:
            new_volume = s.V * (new_temperature / s.T)
        elif new_volume is not None:
            new_temperature = s.T * (new_volume / s.V)
        else:
            raise ValueError("Must provide new_temperature or new_volume.")
        self.state = IdealGasState(s.P, new_volume, new_temperature, s.n)
        self.history.append(self.state.as_dict())
        return self.state

    def apply_gay_lussacs_law(self, new_temperature: float = None, new_pressure: float = None):
        """Constant V, n. Provide either new_temperature or new_pressure; solves for the other."""
        s = self.state
        if new_temperature is not None and new_pressure is not None:
            raise ValueError("Provide only one of new_temperature or new_pressure for Gay-Lussac's Law.")
        if new_temperature is not None:
            new_pressure = s.P * (new_temperature / s.T)
        elif new_pressure is not None:
            new_temperature = s.T * (new_pressure / s.P)
        else:
            raise ValueError("Must provide new_temperature or new_pressure.")
        self.state = IdealGasState(new_pressure, s.V, new_temperature, s.n)
        self.history.append(self.state.as_dict())
        return self.state

    # ---------- General law: solve for any one missing variable ----------

    def solve_missing_variable(self, P=None, V=None, T=None, n=None):
        """
        Given exactly 3 of (P, V, T, n), compute the 4th using PV = nRT.
        Updates and returns the new state. Also used when moles change
        (e.g. gas added/removed at fixed P, T -> V changes, or fixed P, V -> T changes).
        """
        provided = {"P": P, "V": V, "T": T, "n": n}
        missing = [k for k, v in provided.items() if v is None]
        if len(missing) != 1:
            raise ValueError("Provide exactly 3 of P, V, T, n — the 4th will be calculated.")

        target = missing[0]
        if target == "P":
            P = (n * R * T) / V
        elif target == "V":
            V = (n * R * T) / P
        elif target == "T":
            T = (P * V) / (n * R)
        elif target == "n":
            n = (P * V) / (R * T)

        self.state = IdealGasState(P, V, T, n)
        self.history.append(self.state.as_dict())
        return self.state

    def reset(self, state: IdealGasState):
        self.state = state
        self.history = [state.as_dict()]

    def get_history(self):
        return self.history