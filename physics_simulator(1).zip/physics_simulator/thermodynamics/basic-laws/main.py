"""
FastAPI backend for the Ideal Gas Law simulator.

Run with:
    uvicorn main:app --reload

Endpoints:
    POST /simulations/init                -> create a session, returns session_id + initial state
    GET  /simulations/{session_id}/state   -> current state
    POST /simulations/{session_id}/boyle   -> apply Boyle's Law (constant T, n)
    POST /simulations/{session_id}/charles -> apply Charles's Law (constant P, n)
    POST /simulations/{session_id}/gay-lussac -> apply Gay-Lussac's Law (constant V, n)
    POST /simulations/{session_id}/solve   -> general PV = nRT solver (any 3 of 4 vars)
    POST /simulations/{session_id}/reset   -> reset to a new initial state
    GET  /simulations/{session_id}/history -> list of all past states (for plotting)
    DELETE /simulations/{session_id}       -> delete a session
"""
# ///uvicorn main:app --reload
import uuid
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from physics import IdealGasSimulator, IdealGasState

app = FastAPI(title="Ideal Gas Law Simulator API")

# Allow the frontend (running on a different port/origin) to call this API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this to your actual frontend origin in production
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory session store: session_id -> IdealGasSimulator
sessions: dict[str, IdealGasSimulator] = {}


# ---------------------------- Request schemas ----------------------------

class InitRequest(BaseModel):
    pressure: float   # Pa
    volume: float      # m^3
    temperature: float  # K
    moles: float        # mol


class BoyleRequest(BaseModel):
    new_pressure: Optional[float] = None
    new_volume: Optional[float] = None


class CharlesRequest(BaseModel):
    new_temperature: Optional[float] = None
    new_volume: Optional[float] = None


class GayLussacRequest(BaseModel):
    new_temperature: Optional[float] = None
    new_pressure: Optional[float] = None


class SolveRequest(BaseModel):
    P: Optional[float] = None
    V: Optional[float] = None
    T: Optional[float] = None
    n: Optional[float] = None


# ------------------------------- Helpers -------------------------------

def get_sim(session_id: str) -> IdealGasSimulator:
    sim = sessions.get(session_id)
    if sim is None:
        raise HTTPException(status_code=404, detail="Session not found.")
    return sim


# ------------------------------- Routes -------------------------------

@app.post("/simulations/init")
def init_simulation(req: InitRequest):
    try:
        state = IdealGasState(req.pressure, req.volume, req.temperature, req.moles)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    session_id = str(uuid.uuid4())
    sessions[session_id] = IdealGasSimulator(state)
    return {"session_id": session_id, "state": state.as_dict()}


@app.get("/simulations/{session_id}/state")
def get_state(session_id: str):
    sim = get_sim(session_id)
    return sim.state.as_dict()


@app.post("/simulations/{session_id}/boyle")
def boyle(session_id: str, req: BoyleRequest):
    sim = get_sim(session_id)
    try:
        new_state = sim.apply_boyles_law(req.new_pressure, req.new_volume)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return new_state.as_dict()


@app.post("/simulations/{session_id}/charles")
def charles(session_id: str, req: CharlesRequest):
    sim = get_sim(session_id)
    try:
        new_state = sim.apply_charles_law(req.new_temperature, req.new_volume)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return new_state.as_dict()


@app.post("/simulations/{session_id}/gay-lussac")
def gay_lussac(session_id: str, req: GayLussacRequest):
    sim = get_sim(session_id)
    try:
        new_state = sim.apply_gay_lussacs_law(req.new_temperature, req.new_pressure)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return new_state.as_dict()


@app.post("/simulations/{session_id}/solve")
def solve(session_id: str, req: SolveRequest):
    sim = get_sim(session_id)
    try:
        new_state = sim.solve_missing_variable(req.P, req.V, req.T, req.n)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return new_state.as_dict()


@app.post("/simulations/{session_id}/reset")
def reset(session_id: str, req: InitRequest):
    sim = get_sim(session_id)
    try:
        state = IdealGasState(req.pressure, req.volume, req.temperature, req.moles)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    sim.reset(state)
    return state.as_dict()


@app.get("/simulations/{session_id}/history")
def history(session_id: str):
    sim = get_sim(session_id)
    return sim.get_history()


@app.delete("/simulations/{session_id}")
def delete_session(session_id: str):
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found.")
    del sessions[session_id]
    return {"deleted": session_id}


@app.get("/")
def root():
    return {"message": "Ideal Gas Law Simulator API is running. See /docs for interactive API docs."}