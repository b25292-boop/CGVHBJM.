// ---------------------------------------------------------------------------
// Degrees of Freedom & Energy page
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);
const R = 8.314;           // universal gas constant, J/(mol·K)
const K_B = 1.380649e-23;  // Boltzmann constant, J/K
const SVG_NS = "http://www.w3.org/2000/svg";
function makeEl(tag, attrs) {
  const node = document.createElementNS(SVG_NS, tag);
  Object.entries(attrs).forEach(([k, v]) => node.setAttribute(k, v));
  return node;
}

function renderFormula(elementId, latex, displayMode) {
  const target = el(elementId);
  try {
    katex.render(latex, target, { throwOnError: false, displayMode: !!displayMode });
  } catch (e) {
    target.textContent = latex;
  }
}

renderFormula(
  "formula-equipartition",
  "\\langle E \\rangle = \\dfrac{f}{2} k T \\qquad U_{mole} = \\dfrac{f}{2} R T",
  true
);

const MOLECULE_TYPES = {
  "monatomic":       { trans: 3, rot: 0, vib: 0, label: "Monatomic", shape: "single" },
  "diatomic-rigid":  { trans: 3, rot: 2, vib: 0, label: "Diatomic (rigid)", shape: "dumbbell" },
  "diatomic-vib":    { trans: 3, rot: 2, vib: 2, label: "Diatomic (with vibration)", shape: "dumbbell" },
  "nonlinear":       { trans: 3, rot: 3, vib: 0, label: "Nonlinear polyatomic", shape: "bent" },
};

const moleculeSelect = el("molecule-select");
const sliderT = el("slider-T");
const valT = el("val-T");

// ---------------------------- Breakdown list ----------------------------

function renderBreakdown() {
  const data = MOLECULE_TYPES[moleculeSelect.value];
  const total = data.trans + data.rot + data.vib;
  const container = el("dof-breakdown");
  container.innerHTML = `
    <div class="dof-breakdown-row"><span>Translational</span><span class="dof-count">${data.trans}</span></div>
    <div class="dof-breakdown-row"><span>Rotational</span><span class="dof-count">${data.rot}</span></div>
    <div class="dof-breakdown-row"><span>Vibrational</span><span class="dof-count">${data.vib}</span></div>
    <div class="dof-breakdown-row total"><span>Total (f)</span><span class="dof-count">${total}</span></div>
  `;
}

// ---------------------------- Animated diagram ----------------------------

const diagramSvg = el("dof-diagram");
let rotationAngle = 0;
let vibrationPhase = 0;

function drawDiagram() {
  diagramSvg.innerHTML = "";
  const data = MOLECULE_TYPES[moleculeSelect.value];
  const cx = 130, cy = 90;

  if (data.shape === "single") {
    diagramSvg.appendChild(makeEl("circle", { cx, cy, r: 14, fill: "#4FA8B8" }));
  } else if (data.shape === "dumbbell") {
    const baseSeparation = 45;
    const separation = data.vib > 0 ? baseSeparation + Math.sin(vibrationPhase) * 10 : baseSeparation;
    const group = makeEl("g", { transform: `rotate(${rotationAngle}, ${cx}, ${cy})` });
    const x1 = cx - separation, x2 = cx + separation;
    group.appendChild(makeEl("line", {
      x1, y1: cy, x2, y2: cy, stroke: data.vib > 0 ? "#9AA1AC" : "#4FA8B8",
      "stroke-width": 3, "stroke-dasharray": data.vib > 0 ? "4 3" : "none", "stroke-linecap": "round",
    }));
    group.appendChild(makeEl("circle", { cx: x1, cy, r: 12, fill: "#4FA8B8" }));
    group.appendChild(makeEl("circle", { cx: x2, cy, r: 12, fill: "#E8734A" }));
    diagramSvg.appendChild(group);
  } else if (data.shape === "bent") {
    const group = makeEl("g", { transform: `rotate(${rotationAngle}, ${cx}, ${cy})` });
    const armLen = 42, angleDeg = 52; // roughly water's bond angle for illustration
    const rad = (angleDeg * Math.PI) / 180;
    const x1 = cx - armLen * Math.sin(rad), y1 = cy + armLen * Math.cos(rad);
    const x2 = cx + armLen * Math.sin(rad), y2 = cy + armLen * Math.cos(rad);
    group.appendChild(makeEl("line", { x1: cx, y1: cy, x2: x1, y2: y1, stroke: "#9AA1AC", "stroke-width": 3, "stroke-linecap": "round" }));
    group.appendChild(makeEl("line", { x1: cx, y1: cy, x2: x2, y2: y2, stroke: "#9AA1AC", "stroke-width": 3, "stroke-linecap": "round" }));
    group.appendChild(makeEl("circle", { cx, cy, r: 13, fill: "#E8734A" }));
    group.appendChild(makeEl("circle", { cx: x1, cy: y1, r: 9, fill: "#4FA8B8" }));
    group.appendChild(makeEl("circle", { cx: x2, cy: y2, r: 9, fill: "#4FA8B8" }));
    diagramSvg.appendChild(group);
  }

  const caption = makeEl("text", { x: cx, y: 170, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 12, "font-family": "Inter, sans-serif" });
  caption.textContent = data.label + (data.rot > 0 ? " — rotating" : "") + (data.vib > 0 ? " + vibrating" : "");
  diagramSvg.appendChild(caption);
}

function animateDiagram() {
  const data = MOLECULE_TYPES[moleculeSelect.value];
  if (data.rot > 0) rotationAngle = (rotationAngle + 0.7) % 360;
  if (data.vib > 0) vibrationPhase += 0.12;
  drawDiagram();
  requestAnimationFrame(animateDiagram);
}

// ---------------------------- Equipartition calculator ----------------------------

function formatScientific(value, unit) {
  const exponent = Math.floor(Math.log10(Math.abs(value)));
  const mantissa = value / Math.pow(10, exponent);
  const supMap = { "-": "\u207B", 0: "\u2070", 1: "\u00B9", 2: "\u00B2", 3: "\u00B3", 4: "\u2074", 5: "\u2075", 6: "\u2076", 7: "\u2077", 8: "\u2078", 9: "\u2079" };
  const sup = String(exponent).split("").map((ch) => supMap[ch] ?? ch).join("");
  return `${mantissa.toFixed(2)} × 10${sup} ${unit}`;
}

function updateEquipartition() {
  const data = MOLECULE_TYPES[moleculeSelect.value];
  const f = data.trans + data.rot + data.vib;
  const tempK = parseFloat(sliderT.value);
  valT.textContent = tempK;

  const keMolecule = 0.5 * f * K_B * tempK;
  const uMole = 0.5 * f * R * tempK;

  el("value-ke-molecule").textContent = formatScientific(keMolecule, "J");
  el("value-u-mole").textContent = `${uMole.toFixed(1)} J/mol`;
}

function updateAll() {
  renderBreakdown();
  updateEquipartition();
}

moleculeSelect.addEventListener("change", updateAll);
sliderT.addEventListener("input", updateEquipartition);

// ---------------------------- Init ----------------------------

updateAll();
animateDiagram();