// ---------------------------------------------------------------------------
// Kinetic Theory → Gas Laws page (mostly static content — just formula rendering)
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);

function renderFormula(elementId, latex, displayMode) {
  const target = el(elementId);
  try {
    katex.render(latex, target, { throwOnError: false, displayMode: !!displayMode });
  } catch (e) {
    target.textContent = latex;
  }
}

renderFormula(
  "formula-chain",
  "PV = \\tfrac13 Nm\\langle v^2\\rangle \\;\\longrightarrow\\; PV = NkT \\;\\longrightarrow\\; PV = nRT",
  true
);

renderFormula("formula-boyle", "PV = \\text{constant} \\;\\Rightarrow\\; P \\propto \\dfrac{1}{V}");
renderFormula("formula-charles", "\\dfrac{V}{T} = \\text{constant} \\;\\Rightarrow\\; V \\propto T");
renderFormula("formula-gaylussac", "\\dfrac{P}{T} = \\text{constant} \\;\\Rightarrow\\; P \\propto T");