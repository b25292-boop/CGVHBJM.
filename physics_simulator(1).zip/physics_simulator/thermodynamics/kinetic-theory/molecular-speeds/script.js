// ---------------------------------------------------------------------------
// Molecular Speeds page
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);
const R = 8.314; // universal gas constant, J/(mol·K)

function renderFormula(elementId, latex, displayMode) {
  const target = el(elementId);
  try {
    katex.render(latex, target, { throwOnError: false, displayMode: !!displayMode });
  } catch (e) {
    target.textContent = latex;
  }
}

// ---------------------------- Static formula definitions ----------------------------

renderFormula("formula-vp", "v_p = \\sqrt{\\dfrac{2RT}{M}}");
renderFormula("formula-vavg", "\\bar{v} = \\sqrt{\\dfrac{8RT}{\\pi M}}");
renderFormula("formula-vrms", "v_{rms} = \\sqrt{\\dfrac{3RT}{M}}");

renderFormula("formula-ratio", "v_p : \\bar{v} : v_{rms} = \\sqrt{2} : \\sqrt{\\dfrac{8}{\\pi}} : \\sqrt{3}", true);

const ratioVp = Math.sqrt(2);
const ratioVavg = Math.sqrt(8 / Math.PI);
const ratioVrms = Math.sqrt(3);
el("ratio-decimal").textContent =
  `≈ ${(ratioVp / ratioVp).toFixed(3)} : ${(ratioVavg / ratioVp).toFixed(3)} : ${(ratioVrms / ratioVp).toFixed(3)}  (normalized so v_p = 1)`;

// ---------------------------- Live calculator ----------------------------

const gasSelect = el("gas-select");
const sliderT = el("slider-T");
const valT = el("val-T");

function speeds(tempK, molarMassKg) {
  const vp = Math.sqrt((2 * R * tempK) / molarMassKg);
  const vavg = Math.sqrt((8 * R * tempK) / (Math.PI * molarMassKg));
  const vrms = Math.sqrt((3 * R * tempK) / molarMassKg);
  return { vp, vavg, vrms };
}

function updateCalculator() {
  const tempK = parseFloat(sliderT.value);
  const molarMassKg = parseFloat(gasSelect.value);
  valT.textContent = tempK;

  const { vp, vavg, vrms } = speeds(tempK, molarMassKg);
  const maxSpeed = Math.max(vp, vavg, vrms);

  el("value-vp").textContent = `${vp.toFixed(1)} m/s`;
  el("value-vavg").textContent = `${vavg.toFixed(1)} m/s`;
  el("value-vrms").textContent = `${vrms.toFixed(1)} m/s`;

  el("bar-vp").style.width = `${(vp / maxSpeed) * 100}%`;
  el("bar-vavg").style.width = `${(vavg / maxSpeed) * 100}%`;
  el("bar-vrms").style.width = `${(vrms / maxSpeed) * 100}%`;
}

gasSelect.addEventListener("change", updateCalculator);
sliderT.addEventListener("input", updateCalculator);

updateCalculator();          