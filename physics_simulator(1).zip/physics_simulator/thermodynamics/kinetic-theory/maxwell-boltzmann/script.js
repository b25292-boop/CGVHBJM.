// ---------------------------------------------------------------------------
// Maxwell-Boltzmann Distribution page
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);
const R = 8.314;          // universal gas constant, J/(mol·K)
const K_B = 1.380649e-23; // Boltzmann constant, J/K
const N_A = 6.02214076e23; // Avogadro's number, 1/mol

function renderFormula(elementId, latex, displayMode) {
  const target = el(elementId);
  try {
    katex.render(latex, target, { throwOnError: false, displayMode: !!displayMode });
  } catch (e) {
    target.textContent = latex;
  }
}

renderFormula(
  "formula-mb",
  "f(v) = 4\\pi \\left(\\dfrac{m}{2\\pi k T}\\right)^{3/2} v^2\\, e^{-\\frac{mv^2}{2kT}}",
  true
);

// ---------------------------- Physics ----------------------------

function mbDensity(v, tempK, molarMassKg) {
  const m = molarMassKg / N_A; // mass of one molecule, kg
  const coeff = 4 * Math.PI * Math.pow(m / (2 * Math.PI * K_B * tempK), 1.5);
  return coeff * v * v * Math.exp((-m * v * v) / (2 * K_B * tempK));
}

function characteristicSpeeds(tempK, molarMassKg) {
  return {
    vp: Math.sqrt((2 * R * tempK) / molarMassKg),
    vavg: Math.sqrt((8 * R * tempK) / (Math.PI * molarMassKg)),
    vrms: Math.sqrt((3 * R * tempK) / molarMassKg),
  };
}

// ---------------------------- Canvas helpers ----------------------------

function resizeCanvas(canvas) {
  const wrap = canvas.parentElement;
  canvas.width = wrap.clientWidth * devicePixelRatio;
  canvas.height = wrap.clientHeight * devicePixelRatio;
  canvas.style.width = wrap.clientWidth + "px";
  canvas.style.height = wrap.clientHeight + "px";
  const ctx = canvas.getContext("2d");
  ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
  return ctx;
}

function drawAxes(ctx, w, h, pad, xLabel, yLabel) {
  ctx.strokeStyle = "#262B33";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(pad.left, pad.top);
  ctx.lineTo(pad.left, h - pad.bottom);
  ctx.lineTo(w - pad.right, h - pad.bottom);
  ctx.stroke();

  ctx.fillStyle = "#9AA1AC";
  ctx.font = "12px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(xLabel, (pad.left + w - pad.right) / 2, h - 10);

  ctx.save();
  ctx.translate(16, (pad.top + h - pad.bottom) / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText(yLabel, 0, 0);
  ctx.restore();
}

// ---------------------------- Section 2: interactive curve ----------------------------

const mainCanvas = el("mb-curve");
const gasSelect = el("gas-select");
const sliderT = el("slider-T");
const valT = el("val-T");

function drawMainCurve() {
  const ctx = resizeCanvas(mainCanvas);
  const w = mainCanvas.clientWidth, h = mainCanvas.clientHeight;
  ctx.clearRect(0, 0, w, h);

  const tempK = parseFloat(sliderT.value);
  const molarMassKg = parseFloat(gasSelect.value);
  valT.textContent = tempK;

  const speeds = characteristicSpeeds(tempK, molarMassKg);
  const vMax = speeds.vrms * 2.6;

  const pad = { left: 50, right: 20, top: 20, bottom: 40 };
  drawAxes(ctx, w, h, pad, "Speed (m/s)", "Probability density");

  const steps = 200;
  const points = [];
  let maxF = 0;
  for (let i = 0; i <= steps; i++) {
    const v = (i / steps) * vMax;
    const f = mbDensity(v, tempK, molarMassKg);
    points.push({ v, f });
    if (f > maxF) maxF = f;
  }

  const toPx = (v, f) => ({
    x: pad.left + (v / vMax) * (w - pad.left - pad.right),
    y: h - pad.bottom - (f / maxF) * (h - pad.top - pad.bottom),
  });

  // filled curve
  ctx.beginPath();
  points.forEach((p, i) => {
    const px = toPx(p.v, p.f);
    if (i === 0) ctx.moveTo(px.x, px.y);
    else ctx.lineTo(px.x, px.y);
  });
  const last = toPx(points[points.length - 1].v, 0);
  const first = toPx(points[0].v, 0);
  ctx.lineTo(last.x, h - pad.bottom);
  ctx.lineTo(first.x, h - pad.bottom);
  ctx.closePath();
  ctx.fillStyle = "rgba(79, 168, 184, 0.12)";
  ctx.fill();

  ctx.beginPath();
  points.forEach((p, i) => {
    const px = toPx(p.v, p.f);
    if (i === 0) ctx.moveTo(px.x, px.y);
    else ctx.lineTo(px.x, px.y);
  });
  ctx.strokeStyle = "#4FA8B8";
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // markers for vp, vavg, vrms
  const markers = [
    { v: speeds.vp, color: "#4FA8B8", label: "v\u209a" },
    { v: speeds.vavg, color: "#7FBFD4", label: "v\u0304" },
    { v: speeds.vrms, color: "#E8734A", label: "v_rms" },
  ];
  markers.forEach((m) => {
    const f = mbDensity(m.v, tempK, molarMassKg);
    const px = toPx(m.v, f);
    const base = toPx(m.v, 0);
    ctx.strokeStyle = m.color;
    ctx.setLineDash([4, 3]);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px.x, base.y);
    ctx.lineTo(px.x, px.y);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = m.color;
    ctx.beginPath();
    ctx.arc(px.x, px.y, 4.5, 0, Math.PI * 2);
    ctx.fill();
  });
}

gasSelect.addEventListener("change", drawMainCurve);
sliderT.addEventListener("input", drawMainCurve);
window.addEventListener("resize", drawMainCurve);

// ---------------------------- Section 3: temperature comparison ----------------------------

const compareCanvas = el("mb-compare");
const COMPARE_TEMPS = [
  { tempK: 200, color: "#7FBFD4" },
  { tempK: 500, color: "#4FA8B8" },
  { tempK: 900, color: "#E8734A" },
];

function drawCompareCurve() {
  const ctx = resizeCanvas(compareCanvas);
  const w = compareCanvas.clientWidth, h = compareCanvas.clientHeight;
  ctx.clearRect(0, 0, w, h);

  const molarMassKg = parseFloat(gasSelect.value);
  const pad = { left: 50, right: 20, top: 20, bottom: 40 };
  drawAxes(ctx, w, h, pad, "Speed (m/s)", "Probability density");

  // Shared v and f scale across all three curves, so peak heights are comparable
  const highestT = COMPARE_TEMPS[COMPARE_TEMPS.length - 1].tempK;
  const vMax = characteristicSpeeds(highestT, molarMassKg).vrms * 2.6;

  const steps = 200;
  let maxF = 0;
  const allSeries = COMPARE_TEMPS.map(({ tempK }) => {
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const v = (i / steps) * vMax;
      const f = mbDensity(v, tempK, molarMassKg);
      pts.push({ v, f });
      if (f > maxF) maxF = f;
    }
    return pts;
  });

  const toPx = (v, f) => ({
    x: pad.left + (v / vMax) * (w - pad.left - pad.right),
    y: h - pad.bottom - (f / maxF) * (h - pad.top - pad.bottom),
  });

  allSeries.forEach((pts, i) => {
    ctx.beginPath();
    pts.forEach((p, j) => {
      const px = toPx(p.v, p.f);
      if (j === 0) ctx.moveTo(px.x, px.y);
      else ctx.lineTo(px.x, px.y);
    });
    ctx.strokeStyle = COMPARE_TEMPS[i].color;
    ctx.lineWidth = 2.5;
    ctx.stroke();
  });
}

window.addEventListener("resize", drawCompareCurve);
gasSelect.addEventListener("change", drawCompareCurve);

// ---------------------------- Init ----------------------------

drawMainCurve();
drawCompareCurve();