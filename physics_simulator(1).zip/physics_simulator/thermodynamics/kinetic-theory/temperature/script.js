// ---------------------------------------------------------------------------
// Temperature & Kinetic Energy page
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);
const SVG_NS = "http://www.w3.org/2000/svg";
function makeEl(tag, attrs) {
  const node = document.createElementNS(SVG_NS, tag);
  Object.entries(attrs).forEach(([k, v]) => node.setAttribute(k, v));
  return node;
}
function lerp(a, b, t) { return a + (b - a) * t; }
function clamp01(x) { return Math.max(0, Math.min(1, x)); }

const K_B = 1.380649e-23; // Boltzmann constant, J/K
const T_RANGE = { min: 100, max: 1000 };

// Relative atomic masses (u) used only to set the *relative* speed ratio
// between the two comparison gases (real v_rms ∝ 1/√m at fixed T).
const MASS_LIGHT = 4;   // Helium
const MASS_HEAVY = 131; // Xenon

// ---------------------------------------------------------------------------
// Section 1: Temperature slider -> average KE readout + two gas boxes
// ---------------------------------------------------------------------------

const sliderT = el("slider-T");
const valT = el("val-T");
const readKE = el("read-ke");

function formatKE(joules) {
  const exponent = Math.floor(Math.log10(joules));
  const mantissa = joules / Math.pow(10, exponent);
  return `${mantissa.toFixed(2)} × 10${superscript(exponent)} J`;
}

function superscript(n) {
  const map = { "-": "\u207B", 0: "\u2070", 1: "\u00B9", 2: "\u00B2", 3: "\u00B3", 4: "\u2074", 5: "\u2075", 6: "\u2076", 7: "\u2077", 8: "\u2078", 9: "\u2079" };
  return String(n).split("").map((ch) => map[ch] ?? ch).join("");
}

function averageKE(tempK) {
  return 1.5 * K_B * tempK; // (3/2) k T
}

// --- Particle box builder, reused for both gas comparison boxes ---
function createGasBox(svgEl, massFactor) {
  const bounds = { left: 12, right: 188, top: 12, bottom: 148 };
  const count = 10;
  let particles = [];
  let animHandle = null;

  function init() {
    svgEl.innerHTML = "";
    particles = [];
    for (let i = 0; i < count; i++) {
      const x = lerp(bounds.left + 8, bounds.right - 8, Math.random());
      const y = lerp(bounds.top + 8, bounds.bottom - 8, Math.random());
      const angle = Math.random() * Math.PI * 2;
      const circle = makeEl("circle", { cx: x, cy: y, r: 5, fill: "#4FA8B8" });
      svgEl.appendChild(circle);
      particles.push({ el: circle, x, y, vx: Math.cos(angle), vy: Math.sin(angle) });
    }
  }

  function step(tNorm) {
    const speed = lerp(0.5, 3.2, tNorm) * massFactor;
    particles.forEach((p) => {
      p.x += p.vx * speed;
      p.y += p.vy * speed;
      if (p.x < bounds.left + 5 || p.x > bounds.right - 5) p.vx *= -1;
      if (p.y < bounds.top + 5 || p.y > bounds.bottom - 5) p.vy *= -1;
      p.x = Math.max(bounds.left + 5, Math.min(bounds.right - 5, p.x));
      p.y = Math.max(bounds.top + 5, Math.min(bounds.bottom - 5, p.y));
      p.el.setAttribute("cx", p.x.toFixed(1));
      p.el.setAttribute("cy", p.y.toFixed(1));
      p.el.setAttribute("fill", tNorm > 0.55 ? "#E8734A" : "#4FA8B8");
    });
  }

  init();
  return { step };
}

const massFactorLight = 1;
const massFactorHeavy = Math.sqrt(MASS_LIGHT / MASS_HEAVY); // heavier -> slower, same KE

const lightBox = createGasBox(el("gas-svg-light"), massFactorLight);
const heavyBox = createGasBox(el("gas-svg-heavy"), massFactorHeavy);

let currentTNorm = clamp01((parseFloat(sliderT.value) - T_RANGE.min) / (T_RANGE.max - T_RANGE.min));

function updateTemperatureSection() {
  const tempK = parseFloat(sliderT.value);
  valT.textContent = tempK;
  currentTNorm = clamp01((tempK - T_RANGE.min) / (T_RANGE.max - T_RANGE.min));
  readKE.textContent = formatKE(averageKE(tempK));
  drawKEGraph(tempK);
}

sliderT.addEventListener("input", updateTemperatureSection);

function animationLoop() {
  lightBox.step(currentTNorm);
  heavyBox.step(currentTNorm);
  requestAnimationFrame(animationLoop);
}

// ---------------------------------------------------------------------------
// Section 3: KE vs T graph, marker synced to the same slider
// ---------------------------------------------------------------------------

const keGraphSvg = el("ke-t-graph");

function drawKEGraph(tempK) {
  keGraphSvg.innerHTML = "";
  const pad = { left: 55, right: 20, top: 30, bottom: 44 };
  const w = 320, h = 260;

  keGraphSvg.appendChild(makeEl("line", { x1: pad.left, y1: pad.top, x2: pad.left, y2: h - pad.bottom, stroke: "#262B33", "stroke-width": 1.5 }));
  keGraphSvg.appendChild(makeEl("line", { x1: pad.left, y1: h - pad.bottom, x2: w - pad.right, y2: h - pad.bottom, stroke: "#262B33", "stroke-width": 1.5 }));

  const xLabel = makeEl("text", { x: (pad.left + w - pad.right) / 2, y: h - 10, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 12, "font-family": "Inter, sans-serif" });
  xLabel.textContent = "Temperature (K)";
  keGraphSvg.appendChild(xLabel);

  const yLabelY = (pad.top + h - pad.bottom) / 2;
  const yLabel = makeEl("text", { x: 16, y: yLabelY, fill: "#9AA1AC", "font-size": 12, "font-family": "Inter, sans-serif", "text-anchor": "middle", transform: `rotate(-90, 16, ${yLabelY})` });
  yLabel.textContent = "Average KE";
  keGraphSvg.appendChild(yLabel);

  // Straight line through origin: KE = (3/2) k T -> plot over the slider's T range
  const x0 = pad.left, y0 = h - pad.bottom;
  const x1 = w - pad.right, y1 = pad.top;
  keGraphSvg.appendChild(makeEl("line", { x1: x0, y1: y0, x2: x1, y2: y1, stroke: "#4FA8B8", "stroke-width": 2.5, "stroke-linecap": "round" }));

  // Marker at the current temperature (normalized along the plotted range)
  const norm = clamp01((tempK - T_RANGE.min) / (T_RANGE.max - T_RANGE.min));
  const markerX = lerp(x0, x1, norm);
  const markerY = lerp(y0, y1, norm);
  keGraphSvg.appendChild(makeEl("circle", { cx: markerX, cy: markerY, r: 6, fill: "#E8734A" }));

  const caption = makeEl("text", { x: 160, y: 20, "text-anchor": "middle", fill: "#EDEAE2", "font-size": 12, "font-family": "Inter, sans-serif" });
  caption.textContent = "\u27e8KE\u27e9 = (3/2)kT";
  keGraphSvg.appendChild(caption);
}

// ---------------------------------------------------------------------------
// Section 2: Average Kinetic Energy derivation stepper
// ---------------------------------------------------------------------------

const KE_STEPS = [
  {
    title: "Kinetic Energy of a Single Molecule",
    explanation: "From the pressure derivation, equating the kinetic theory expression for pressure with the ideal gas law gave us the average translational kinetic energy of one molecule.",
    formula: "\\langle KE \\rangle = \\tfrac12 m \\langle v^2 \\rangle = \\tfrac32 k T",
    visual: "one",
  },
  {
    title: "Total Kinetic Energy of N Molecules",
    explanation: "A gas sample contains N molecules. Since each one has this same average kinetic energy, the total kinetic energy of the whole sample is simply N times that value.",
    formula: "KE_{total} = N \\cdot \\tfrac32 kT = \\tfrac32 N k T",
    visual: "many",
  },
  {
    title: "In Terms of Moles",
    explanation: "Using N = nN_A (n moles, Avogadro's number N_A) and the fact that N_A k = R (the universal gas constant), the total kinetic energy can be written directly in terms of moles.",
    formula: "KE_{total} = \\tfrac32 n R T",
    visual: "moles",
  },
];

let keStep = 0;
const keSvg = el("ke-derivation-svg");

function renderKEStep() {
  const step = KE_STEPS[keStep];
  el("ke-step-indicator").textContent = `Step ${keStep + 1} of ${KE_STEPS.length}`;
  el("ke-step-title").textContent = step.title;
  el("ke-step-explanation").textContent = step.explanation;

  const formulaEl = el("ke-step-formula");
  formulaEl.innerHTML = "";
  try {
    katex.render(step.formula, formulaEl, { throwOnError: false, displayMode: true });
  } catch (e) {
    formulaEl.textContent = step.formula;
  }

  el("ke-btn-prev").disabled = keStep === 0;
  el("ke-btn-next").disabled = keStep === KE_STEPS.length - 1;

  renderKEDots();
  renderKEVisual(step.visual);
}

function renderKEDots() {
  const dotsEl = el("ke-step-dots");
  dotsEl.innerHTML = "";
  KE_STEPS.forEach((_, i) => {
    const dot = document.createElement("div");
    dot.className = "dot" + (i === keStep ? " active" : "");
    dotsEl.appendChild(dot);
  });
}

function renderKEVisual(type) {
  keSvg.innerHTML = "";

  if (type === "one") {
    keSvg.appendChild(makeEl("circle", { cx: 160, cy: 120, r: 10, fill: "#4FA8B8" }));
    const label = makeEl("text", { x: 160, y: 160, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 13, "font-family": "Inter, sans-serif" });
    label.textContent = "One molecule";
    keSvg.appendChild(label);
  } else if (type === "many") {
    const cols = 6, rows = 3;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const cx = 70 + c * 30;
        const cy = 70 + r * 30;
        keSvg.appendChild(makeEl("circle", { cx, cy, r: 6, fill: "#4FA8B8" }));
      }
    }
    const label = makeEl("text", { x: 160, y: 200, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 13, "font-family": "Inter, sans-serif" });
    label.textContent = "N molecules, each with the same average KE";
    keSvg.appendChild(label);
  } else if (type === "moles") {
    const circle = makeEl("circle", { cx: 160, cy: 110, r: 70, fill: "rgba(232,115,74,0.08)", stroke: "#E8734A", "stroke-width": 1.5 });
    keSvg.appendChild(circle);
    for (let i = 0; i < 14; i++) {
      const angle = (i / 14) * Math.PI * 2;
      const r = 30 + Math.random() * 30;
      const cx = 160 + Math.cos(angle) * r;
      const cy = 110 + Math.sin(angle) * r;
      keSvg.appendChild(makeEl("circle", { cx, cy, r: 4, fill: "#4FA8B8" }));
    }
    const label = makeEl("text", { x: 160, y: 210, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 13, "font-family": "Inter, sans-serif" });
    label.textContent = "n moles of gas";
    keSvg.appendChild(label);
  }
}

el("ke-btn-prev").addEventListener("click", () => { if (keStep > 0) { keStep--; renderKEStep(); } });
el("ke-btn-next").addEventListener("click", () => { if (keStep < KE_STEPS.length - 1) { keStep++; renderKEStep(); } });

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------

updateTemperatureSection();
animationLoop();
renderKEStep();