// ---------------------------------------------------------------------------
// Specific Heat & Internal Energy page
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);
const R = 8.314; // universal gas constant, J/(mol·K)

function renderFormula(elementId, latex, displayMode) {
  const target = el(elementId);
  try {
    katex.render(latex, target, { throwOnError: false, displayMode: !!displayMode });
  } catch (e) {
    target.textContent = latex;
  }
}

renderFormula("formula-cv", "C_v = \\dfrac{dU}{dT} = \\dfrac{f}{2} R", true);
renderFormula("formula-cp", "C_p = C_v + R = \\left(\\dfrac{f}{2} + 1\\right) R", true);
renderFormula("formula-gamma-def", "\\gamma = \\dfrac{C_p}{C_v} = \\dfrac{f+2}{f}");
renderFormula("formula-u", "U = \\dfrac{f}{2} n R T", true);

// Same DOF data as the previous topic, so the numbers stay consistent site-wide
const MOLECULE_TYPES = {
  "monatomic":      { f: 3 },
  "diatomic-rigid": { f: 5 },
  "diatomic-vib":   { f: 7 },
  "nonlinear":      { f: 6 },
};

const moleculeSelect = el("molecule-select");

function updateResults() {
  const { f } = MOLECULE_TYPES[moleculeSelect.value];
  const Cv = 0.5 * f * R;
  const Cp = Cv + R;
  const gamma = Cp / Cv;

  el("value-cv").textContent = `${Cv.toFixed(2)} J/(mol·K)`;
  el("value-cp").textContent = `${Cp.toFixed(2)} J/(mol·K)`;
  el("value-gamma").textContent = gamma.toFixed(3);

  const maxVal = Cp; // Cp is always larger, so scale both bars against it
  el("bar-cv").style.width = `${(Cv / maxVal) * 100}%`;
  el("bar-cp").style.width = `${(Cp / maxVal) * 100}%`;
}

moleculeSelect.addEventListener("change", updateResults);

updateResults();