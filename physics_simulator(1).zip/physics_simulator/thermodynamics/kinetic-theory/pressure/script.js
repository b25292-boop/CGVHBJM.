// ---------------------------------------------------------------------------
// Kinetic Theory derivation walkthrough — step data, navigation, and the
// SVG animations that sync to whichever step is currently showing.
// ---------------------------------------------------------------------------

const STEPS = [
  {
    title: "A Molecule Bouncing in a Box",
    explanation: "Picture a single molecule of mass m inside a cubic box of side L, moving with velocity component v\u2093 along the x-axis. It strikes the right-hand wall and bounces straight back.",
    formula: "v_x \\;\\; \\text{(elastic collision)}",
    visual: "single-bounce",
  },
  {
    title: "Momentum Change per Collision",
    explanation: "Since the collision is perfectly elastic, the molecule's velocity simply reverses. Its momentum changes from +mv\u2093 to \u2212mv\u2093 \u2014 a change of magnitude 2mv\u2093 is delivered to the wall on every hit.",
    formula: "\\Delta p = 2 m v_x",
    visual: "single-bounce",
  },
  {
    title: "Time Between Successive Hits",
    explanation: "After bouncing off the right wall, the molecule crosses the box, bounces off the left wall, and returns \u2014 a round trip of distance 2L \u2014 before it can strike the right wall again.",
    formula: "\\Delta t = \\dfrac{2L}{v_x}",
    visual: "single-bounce",
  },
  {
    title: "Force from One Molecule",
    explanation: "Force is the rate of change of momentum. Dividing the momentum delivered per collision by the time between collisions gives the average force this one molecule exerts on the wall.",
    formula: "F = \\dfrac{\\Delta p}{\\Delta t} = \\dfrac{m v_x^2}{L}",
    visual: "single-bounce",
  },
  {
    title: "Summing Over All N Molecules",
    explanation: "A real gas has an enormous number of molecules, N, all doing this at once with different speeds. The total force on the wall is the sum of every molecule's contribution \u2014 equivalent to N times the average of v\u2093\u00b2.",
    formula: "F_{total} = \\dfrac{N m \\langle v_x^2 \\rangle}{L}",
    visual: "multi-particle",
  },
  {
    title: "Pressure on the Wall",
    explanation: "Pressure is force per unit area. The wall's area is L\u00b2, and the box's volume is L\u00b3 = V, so dividing through gives pressure directly in terms of the molecules' average squared velocity.",
    formula: "P = \\dfrac{F_{total}}{L^2} = \\dfrac{N m \\langle v_x^2\\rangle}{V}",
    visual: "multi-particle",
  },
  {
    title: "Accounting for All Three Directions",
    explanation: "Motion is random and isotropic (Assumption 7) \u2014 no direction is preferred. So the averages of v\u2093\u00b2, v_y\u00b2, and v_z\u00b2 must all be equal, and together they make up the full mean square speed.",
    formula: "\\langle v_x^2\\rangle = \\langle v_y^2\\rangle = \\langle v_z^2\\rangle = \\tfrac{1}{3}\\langle v^2\\rangle",
    visual: "symmetry-axes",
  },
  {
    title: "The Kinetic Theory Pressure Equation",
    explanation: "Substituting that back in gives the central result of kinetic theory: pressure expressed purely in terms of the mean square speed of the molecules.",
    formula: "PV = \\tfrac{1}{3} N m \\langle v^2 \\rangle",
    visual: "formula-merge",
  },
  {
    title: "Connecting to Temperature",
    explanation: "Compare this to the ideal gas law, PV = NkT. Setting the two equal and simplifying reveals that a molecule's average kinetic energy depends on temperature alone \u2014 nothing else.",
    formula: "\\tfrac{1}{2} m \\langle v^2 \\rangle = \\tfrac{3}{2} k T",
    visual: "ke-graph",
  },
];

let currentStep = 0;
let isPlaying = false;
let playTimer = null;
let animHandle = null;

const el = (id) => document.getElementById(id);
const svg = el("derivation-svg");
const SVG_NS = "http://www.w3.org/2000/svg";

function makeEl(tag, attrs) {
  const node = document.createElementNS(SVG_NS, tag);
  Object.entries(attrs).forEach(([k, v]) => node.setAttribute(k, v));
  return node;
}

// ---------------------------- Step rendering ----------------------------

function renderStep() {
  const step = STEPS[currentStep];
  el("step-indicator").textContent = `Step ${currentStep + 1} of ${STEPS.length}`;
  el("step-title").textContent = step.title;
  el("step-explanation").textContent = step.explanation;

  const formulaEl = el("step-formula");
  formulaEl.innerHTML = "";
  try {
    katex.render(step.formula, formulaEl, { throwOnError: false, displayMode: true });
  } catch (e) {
    formulaEl.textContent = step.formula;
  }

  el("btn-prev").disabled = currentStep === 0;
  el("btn-next").disabled = currentStep === STEPS.length - 1;

  renderDots();
  renderVisual(step.visual);
}

function renderDots() {
  const dotsEl = el("step-dots");
  dotsEl.innerHTML = "";
  STEPS.forEach((_, i) => {
    const dot = document.createElement("div");
    dot.className = "dot" + (i === currentStep ? " active" : "");
    dotsEl.appendChild(dot);
  });
}

function goToStep(index) {
  if (index < 0 || index >= STEPS.length) return;
  currentStep = index;
  renderStep();
}

// ---------------------------- Navigation ----------------------------

el("btn-prev").addEventListener("click", () => {
  stopAutoplay();
  goToStep(currentStep - 1);
});

el("btn-next").addEventListener("click", () => {
  stopAutoplay();
  goToStep(currentStep + 1);
});

el("btn-play").addEventListener("click", () => {
  if (isPlaying) stopAutoplay();
  else startAutoplay();
});

function startAutoplay() {
  isPlaying = true;
  el("btn-play").textContent = "\u23F8 Pause";
  playTimer = setInterval(() => {
    if (currentStep >= STEPS.length - 1) {
      stopAutoplay();
      return;
    }
    goToStep(currentStep + 1);
  }, 3800);
}

function stopAutoplay() {
  isPlaying = false;
  el("btn-play").textContent = "\u25B6 Play";
  if (playTimer) clearInterval(playTimer);
  playTimer = null;
}

// ---------------------------- SVG visuals ----------------------------

// Shared box geometry (x-axis bounce box), viewBox is 0 0 320 260
const BOX = { left: 60, right: 260, top: 70, bottom: 190 };

function clearSVG() {
  if (animHandle) cancelAnimationFrame(animHandle);
  animHandle = null;
  svg.innerHTML = "";
}

function drawBoxWalls() {
  svg.appendChild(makeEl("line", { x1: BOX.left, y1: BOX.top, x2: BOX.left, y2: BOX.bottom, stroke: "#9AA1AC", "stroke-width": 3, "stroke-linecap": "round", id: "wall-left" }));
  svg.appendChild(makeEl("line", { x1: BOX.right, y1: BOX.top, x2: BOX.right, y2: BOX.bottom, stroke: "#9AA1AC", "stroke-width": 3, "stroke-linecap": "round", id: "wall-right" }));
  svg.appendChild(makeEl("line", { x1: BOX.left, y1: BOX.top, x2: BOX.right, y2: BOX.top, stroke: "#262B33", "stroke-width": 2 }));
  svg.appendChild(makeEl("line", { x1: BOX.left, y1: BOX.bottom, x2: BOX.right, y2: BOX.bottom, stroke: "#262B33", "stroke-width": 2 }));
}

// ---- Visual: single molecule bouncing along x-axis, with momentum flash ----
function renderSingleBounce() {
  clearSVG();
  drawBoxWalls();

  const label = makeEl("text", { x: 160, y: 40, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 12, "font-family": "Inter, sans-serif" });
  label.textContent = "One molecule, mass m";
  svg.appendChild(label);

  const particle = makeEl("circle", { cx: BOX.left + 20, cy: 130, r: 7, fill: "#4FA8B8" });
  svg.appendChild(particle);

  const arrowGroup = makeEl("g", { opacity: 0 });
  const arrow = makeEl("path", { d: "M0 0 L18 -6 L18 6 Z", fill: "#E8734A" });
  const arrowLabel = makeEl("text", { x: 0, y: -14, "font-size": 11, fill: "#E8734A", "font-family": "Inter, sans-serif", "text-anchor": "middle" });
  arrowLabel.textContent = "2mv\u2093";
  arrowGroup.appendChild(arrow);
  arrowGroup.appendChild(arrowLabel);
  svg.appendChild(arrowGroup);

  let x = BOX.left + 20;
  let vx = 2.4;
  const minX = BOX.left + 8, maxX = BOX.right - 8;

  function flashWall(side) {
    const wall = document.getElementById(side === "right" ? "wall-right" : "wall-left");
    wall.setAttribute("stroke", "#E8734A");
    setTimeout(() => wall && wall.setAttribute("stroke", "#9AA1AC"), 250);

    arrowGroup.setAttribute("transform", `translate(${side === "right" ? maxX : minX}, 130) ${side === "left" ? "rotate(180)" : ""}`);
    arrowGroup.setAttribute("opacity", "1");
    setTimeout(() => arrowGroup.setAttribute("opacity", "0"), 350);
  }

  function frame() {
    x += vx;
    if (x >= maxX) { x = maxX; vx *= -1; flashWall("right"); }
    if (x <= minX) { x = minX; vx *= -1; flashWall("left"); }
    particle.setAttribute("cx", x.toFixed(1));
    animHandle = requestAnimationFrame(frame);
  }
  frame();
}

// ---- Visual: several particles bouncing at once (illustrates "sum over N") ----
function renderMultiParticle() {
  clearSVG();
  drawBoxWalls();

  const label = makeEl("text", { x: 160, y: 40, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 12, "font-family": "Inter, sans-serif" });
  label.textContent = "N molecules, all colliding with the walls";
  svg.appendChild(label);

  const count = 8;
  const particles = [];
  for (let i = 0; i < count; i++) {
    const px = BOX.left + 15 + Math.random() * (BOX.right - BOX.left - 30);
    const py = BOX.top + 15 + Math.random() * (BOX.bottom - BOX.top - 30);
    const angle = Math.random() * Math.PI * 2;
    const speed = 1.3 + Math.random() * 1.4;
    const circle = makeEl("circle", { cx: px, cy: py, r: 5, fill: i % 2 === 0 ? "#4FA8B8" : "#E8734A" });
    svg.appendChild(circle);
    particles.push({ el: circle, x: px, y: py, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed });
  }

  function frame() {
    particles.forEach((p) => {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < BOX.left + 6 || p.x > BOX.right - 6) p.vx *= -1;
      if (p.y < BOX.top + 6 || p.y > BOX.bottom - 6) p.vy *= -1;
      p.x = Math.max(BOX.left + 6, Math.min(BOX.right - 6, p.x));
      p.y = Math.max(BOX.top + 6, Math.min(BOX.bottom - 6, p.y));
      p.el.setAttribute("cx", p.x.toFixed(1));
      p.el.setAttribute("cy", p.y.toFixed(1));
    });
    animHandle = requestAnimationFrame(frame);
  }
  frame();
}

// ---- Visual: static diagram showing equal average speeds along x, y, z ----
function renderSymmetryAxes() {
  clearSVG();
  const cx = 160, cy = 140, len = 75;

  const axes = [
    { dx: len, dy: 0, label: "x", labelDx: 14, labelDy: 4 },
    { dx: -len * 0.55, dy: -len * 0.6, label: "y", labelDx: -20, labelDy: -6 },
    { dx: 0, dy: len, label: "z", labelDx: 6, labelDy: 16 },
  ];

  axes.forEach((axis) => {
    const line = makeEl("line", {
      x1: cx, y1: cy, x2: cx + axis.dx, y2: cy + axis.dy,
      stroke: "#4FA8B8", "stroke-width": 2.5, "stroke-linecap": "round",
    });
    svg.appendChild(line);
    const arrowHead = makeEl("circle", { cx: cx + axis.dx, cy: cy + axis.dy, r: 4, fill: "#4FA8B8" });
    svg.appendChild(arrowHead);
    const label = makeEl("text", {
      x: cx + axis.dx + axis.labelDx, y: cy + axis.dy + axis.labelDy,
      fill: "#EDEAE2", "font-size": 14, "font-family": "Space Grotesk, sans-serif", "text-anchor": "middle",
    });
    label.textContent = axis.label;
    svg.appendChild(label);
  });

  svg.appendChild(makeEl("circle", { cx, cy, r: 4, fill: "#E8734A" }));

  const caption = makeEl("text", { x: 160, y: 235, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 12, "font-family": "Inter, sans-serif" });
  caption.textContent = "Equal average speed along every direction";
  svg.appendChild(caption);
}

// ---- Visual: two formulas converging (kinetic theory meets ideal gas law) ----
function renderFormulaMerge() {
  clearSVG();

  const box1 = makeEl("rect", { x: 30, y: 70, width: 110, height: 50, rx: 8, fill: "#181C22", stroke: "#4FA8B8", "stroke-width": 1.5 });
  svg.appendChild(box1);
  const label1 = makeEl("text", { x: 85, y: 100, "text-anchor": "middle", fill: "#4FA8B8", "font-size": 12, "font-family": "Inter, sans-serif" });
  label1.textContent = "Kinetic theory";
  svg.appendChild(label1);

  const box2 = makeEl("rect", { x: 180, y: 70, width: 110, height: 50, rx: 8, fill: "#181C22", stroke: "#E8734A", "stroke-width": 1.5 });
  svg.appendChild(box2);
  const label2 = makeEl("text", { x: 235, y: 100, "text-anchor": "middle", fill: "#E8734A", "font-size": 12, "font-family": "Inter, sans-serif" });
  label2.textContent = "Ideal gas law";
  svg.appendChild(label2);

  const arrow1 = makeEl("path", { d: "M140 95 L172 95", stroke: "#9AA1AC", "stroke-width": 2 });
  svg.appendChild(arrow1);
  const eq = makeEl("text", { x: 160, y: 100, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 16, "font-family": "Space Grotesk, sans-serif" });
  eq.textContent = "=";
  svg.appendChild(eq);

  const both = makeEl("text", { x: 160, y: 160, "text-anchor": "middle", fill: "#EDEAE2", "font-size": 13, "font-family": "Inter, sans-serif" });
  both.textContent = "Both equal PV";
  svg.appendChild(both);
}

// ---- Visual: average KE grows linearly with T ----
function renderKEGraph() {
  clearSVG();

  const pad = { left: 50, right: 20, top: 30, bottom: 40 };
  const w = 320, h = 260;

  svg.appendChild(makeEl("line", { x1: pad.left, y1: pad.top, x2: pad.left, y2: h - pad.bottom, stroke: "#262B33", "stroke-width": 1.5 }));
  svg.appendChild(makeEl("line", { x1: pad.left, y1: h - pad.bottom, x2: w - pad.right, y2: h - pad.bottom, stroke: "#262B33", "stroke-width": 1.5 }));

  const xLabel = makeEl("text", { x: (pad.left + w - pad.right) / 2, y: h - 10, "text-anchor": "middle", fill: "#9AA1AC", "font-size": 12, "font-family": "Inter, sans-serif" });
  xLabel.textContent = "Temperature (T)";
  svg.appendChild(xLabel);

  const yLabel = makeEl("text", { x: 16, y: (pad.top + h - pad.bottom) / 2, fill: "#9AA1AC", "font-size": 12, "font-family": "Inter, sans-serif", "text-anchor": "middle", transform: `rotate(-90, 16, ${(pad.top + h - pad.bottom) / 2})` });
  yLabel.textContent = "Average KE";
  svg.appendChild(yLabel);

  const line = makeEl("line", {
    x1: pad.left, y1: h - pad.bottom,
    x2: w - pad.right, y2: pad.top,
    stroke: "#E8734A", "stroke-width": 2.5, "stroke-linecap": "round",
  });
  svg.appendChild(line);

  const caption = makeEl("text", { x: 160, y: 20, "text-anchor": "middle", fill: "#EDEAE2", "font-size": 12, "font-family": "Inter, sans-serif" });
  caption.textContent = "\u27e8KE\u27e9 = (3/2)kT \u2014 a straight line through the origin";
  svg.appendChild(caption);
}

function renderVisual(type) {
  const renderers = {
    "single-bounce": renderSingleBounce,
    "multi-particle": renderMultiParticle,
    "symmetry-axes": renderSymmetryAxes,
    "formula-merge": renderFormulaMerge,
    "ke-graph": renderKEGraph,
  };
  (renderers[type] || renderSingleBounce)();
}

// ---------------------------- Init ----------------------------

renderStep();