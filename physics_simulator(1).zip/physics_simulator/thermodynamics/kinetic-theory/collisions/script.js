// ---------------------------------------------------------------------------
// Molecular Collisions page
// ---------------------------------------------------------------------------

const el = (id) => document.getElementById(id);
const R = 8.314;           // universal gas constant, J/(mol·K)
const K_B = 1.380649e-23;  // Boltzmann constant, J/K

function renderFormula(elementId, latex, displayMode) {
  const target = el(elementId);
  try {
    katex.render(latex, target, { throwOnError: false, displayMode: !!displayMode });
  } catch (e) {
    target.textContent = latex;
  }
}

renderFormula("formula-lambda", "\\lambda = \\dfrac{1}{\\sqrt{2}\\,\\pi d^2 n}");
renderFormula("formula-z", "z = \\dfrac{\\bar v}{\\lambda} = \\sqrt{2}\\,\\pi d^2 n \\bar v");
renderFormula("formula-tau", "\\tau = \\dfrac{1}{z} = \\dfrac{\\lambda}{\\bar v}");

// Approximate kinetic diameters (m) — standard textbook values
const GASES = {
  H2:  { M: 0.002, d: 2.89e-10, label: "Hydrogen" },
  He:  { M: 0.004, d: 2.60e-10, label: "Helium" },
  N2:  { M: 0.028, d: 3.64e-10, label: "Nitrogen" },
  O2:  { M: 0.032, d: 3.46e-10, label: "Oxygen" },
  CO2: { M: 0.044, d: 3.30e-10, label: "Carbon Dioxide" },
};

function vAvg(tempK, molarMassKg) {
  return Math.sqrt((8 * R * tempK) / (Math.PI * molarMassKg));
}
function numberDensity(tempK, pressurePa) {
  return pressurePa / (K_B * tempK); // molecules per m^3, ideal gas
}
function meanFreePath(tempK, pressurePa, diameterM) {
  const n = numberDensity(tempK, pressurePa);
  return 1 / (Math.sqrt(2) * Math.PI * diameterM * diameterM * n);
}
function collisionFrequency(tempK, pressurePa, molarMassKg, diameterM) {
  return vAvg(tempK, molarMassKg) / meanFreePath(tempK, pressurePa, diameterM);
}

function formatScientific(value, unit) {
  const exponent = Math.floor(Math.log10(Math.abs(value)));
  const mantissa = value / Math.pow(10, exponent);
  const supMap = { "-": "\u207B", 0: "\u2070", 1: "\u00B9", 2: "\u00B2", 3: "\u00B3", 4: "\u2074", 5: "\u2075", 6: "\u2076", 7: "\u2077", 8: "\u2078", 9: "\u2079" };
  const sup = String(exponent).split("").map((ch) => supMap[ch] ?? ch).join("");
  return `${mantissa.toFixed(2)} × 10${sup} ${unit}`;
}

// ---------------------------- Controls ----------------------------

const gasSelect = el("gas-select");
const sliderT = el("slider-T");
const sliderP = el("slider-P");
const valT = el("val-T");
const valP = el("val-P");

let currentTau = 1e-10; // seconds, updated on every recalculation

function updateCalculator() {
  const gas = GASES[gasSelect.value];
  const tempK = parseFloat(sliderT.value);
  const pressurePa = parseFloat(sliderP.value) * 1000;
  valT.textContent = tempK;
  valP.textContent = (pressurePa / 1000).toFixed(1);

  const lambda = meanFreePath(tempK, pressurePa, gas.d);
  const z = collisionFrequency(tempK, pressurePa, gas.M, gas.d);
  const tau = 1 / z;
  currentTau = tau;

  el("value-lambda").textContent = `${(lambda * 1e9).toFixed(1)} nm`;
  el("value-z").textContent = formatScientific(z, "collisions/s");
  el("value-tau").textContent = formatScientific(tau, "s");

  updateCaption(tau);
}

function updateCaption(tau) {
  const descriptor = tau < 5e-11 ? "extremely frequent" : tau < 5e-10 ? "very frequent" : "relatively rare";
  el("zigzag-caption").textContent = `Collisions happen roughly every ${formatScientific(tau, "s")} — shown here as ${descriptor} direction changes.`;
}

gasSelect.addEventListener("change", updateCalculator);
sliderT.addEventListener("input", updateCalculator);
sliderP.addEventListener("input", updateCalculator);

// ---------------------------- Zigzag path animation ----------------------------

const svg = el("zigzag-svg");
const SVG_NS = "http://www.w3.org/2000/svg";
function makeEl(tag, attrs) {
  const node = document.createElementNS(SVG_NS, tag);
  Object.entries(attrs).forEach(([k, v]) => node.setAttribute(k, v));
  return node;
}

const BOUNDS = { left: 20, right: 300, top: 20, bottom: 240 };
const SPEED_PX_PER_FRAME = 2.2;
const FRAMES_MIN = 6;   // very frequent collisions (high pressure)
const FRAMES_MAX = 90;  // rare collisions (low pressure)
const TAU_LOG_MIN = Math.log(7e-12);
const TAU_LOG_MAX = Math.log(5e-9);

let particle = { x: 160, y: 130, vx: 1, vy: 0.4 };
let framesSinceCollision = 0;
let collisionIntervalFrames = 40;
let lastCollisionPoint = { x: particle.x, y: particle.y };
const trailSegments = [];
const MAX_TRAIL = 9;

function pickRandomDirection() {
  const angle = Math.random() * Math.PI * 2;
  return { vx: Math.cos(angle), vy: Math.sin(angle) };
}

function updateCollisionInterval() {
  const clampedTau = Math.max(7e-12, Math.min(5e-9, currentTau));
  const norm = (Math.log(clampedTau) - TAU_LOG_MIN) / (TAU_LOG_MAX - TAU_LOG_MIN);
  collisionIntervalFrames = Math.round(FRAMES_MIN + norm * (FRAMES_MAX - FRAMES_MIN));
}

function stepZigzag() {
  updateCollisionInterval();

  particle.x += particle.vx * SPEED_PX_PER_FRAME;
  particle.y += particle.vy * SPEED_PX_PER_FRAME;

  // bounce off the box walls (keeps the visual contained; doesn't count as a "collision")
  if (particle.x < BOUNDS.left || particle.x > BOUNDS.right) particle.vx *= -1;
  if (particle.y < BOUNDS.top || particle.y > BOUNDS.bottom) particle.vy *= -1;
  particle.x = Math.max(BOUNDS.left, Math.min(BOUNDS.right, particle.x));
  particle.y = Math.max(BOUNDS.top, Math.min(BOUNDS.bottom, particle.y));

  framesSinceCollision++;
  if (framesSinceCollision >= collisionIntervalFrames) {
    trailSegments.push({ x1: lastCollisionPoint.x, y1: lastCollisionPoint.y, x2: particle.x, y2: particle.y });
    if (trailSegments.length > MAX_TRAIL) trailSegments.shift();

    const dir = pickRandomDirection();
    particle.vx = dir.vx;
    particle.vy = dir.vy;
    lastCollisionPoint = { x: particle.x, y: particle.y };
    framesSinceCollision = 0;
  }

  renderZigzag();
  requestAnimationFrame(stepZigzag);
}

function renderZigzag() {
  svg.innerHTML = "";

  // border box
  svg.appendChild(makeEl("rect", {
    x: BOUNDS.left, y: BOUNDS.top, width: BOUNDS.right - BOUNDS.left, height: BOUNDS.bottom - BOUNDS.top,
    fill: "none", stroke: "#262B33", "stroke-width": 1.5, rx: 6,
  }));

  // trail segments, fading older ones
  trailSegments.forEach((seg, i) => {
    const opacity = 0.25 + (0.75 * (i + 1)) / trailSegments.length;
    svg.appendChild(makeEl("line", {
      x1: seg.x1, y1: seg.y1, x2: seg.x2, y2: seg.y2,
      stroke: "#4FA8B8", "stroke-width": 2, opacity: opacity.toFixed(2), "stroke-linecap": "round",
    }));
    svg.appendChild(makeEl("circle", { cx: seg.x2, cy: seg.y2, r: 3, fill: "#E8734A", opacity: opacity.toFixed(2) }));
  });

  // current segment being traced (from last collision to current live position)
  svg.appendChild(makeEl("line", {
    x1: lastCollisionPoint.x, y1: lastCollisionPoint.y, x2: particle.x, y2: particle.y,
    stroke: "#4FA8B8", "stroke-width": 2, "stroke-linecap": "round",
  }));

  // the molecule itself
  svg.appendChild(makeEl("circle", { cx: particle.x, cy: particle.y, r: 5, fill: "#EDEAE2" }));
}

// ---------------------------- Init ----------------------------

updateCalculator();
stepZigzag();