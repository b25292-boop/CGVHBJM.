# Thermodynamics Simulator Section

## Structure
```
thermodynamics/
    index.html          <- landing page (lists all thermo experiments)
    style.css           <- shared styling for the whole thermo section
    basic-laws/
        index.html      <- Basic Gas Laws experiment page (frontend)
        script.js        <- wires sliders to backend, draws live P-V/P-T/V-T graph
        physics.py       <- gas law physics engine (Boyle's, Charles's, Gay-Lussac's, general PV=nRT solver)
        main.py          <- FastAPI backend serving the physics engine
        requirements.txt <- backend dependencies
```

## Running it

1. **Start the backend** (from the `basic-laws` folder):
   ```bash
   pip install -r requirements.txt
   uvicorn main:app --reload
   ```
   This runs on `http://127.0.0.1:8000`. Visit `/docs` for interactive API testing.

2. **Open the frontend**: just open `thermodynamics/index.html` in a browser (or serve the whole folder with any static file server). Click into "Basic Gas Laws" to reach the simulator.

3. `script.js` is already pointed at `http://127.0.0.1:8000` (see the `API_BASE` constant at the top) — change this when you deploy the backend somewhere else.

## What the Basic Gas Laws page does

- Toggle between **Boyle's**, **Charles's**, and **Gay-Lussac's** law.
- Drag the "driving" slider for the current law (e.g. Pressure for Boyle's) and the paired variable updates live via the backend.
- The graph panel shows P-V, P-T, or V-T — tracing the actual path of states you've created, not just a static curve.
- Moles is fixed for these three named laws — that constraint is visually indicated by highlighting the locked variable.

## Next experiments
The landing page already has placeholder cards for Carnot Engine Cycle, Kinetic Theory of Gases, and Heat Transfer — build each the same way: a `physics.py`-style engine, a FastAPI `main.py`, and a matching frontend folder under `thermodynamics/`.
