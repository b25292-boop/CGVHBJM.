# Mechanical Properties Virtual Lab — Shareable Source Bundle

This folder contains three **separate, standalone HTML experiments**. They are not merged into one website, so your group members can open, inspect, and later combine the code into a single project.

## Included experiments

- `bulk-modulus.html` — Bulk Modulus Fun Lab
- `bending-of-beams.html` — Bending of Beams Fun Lab
- `shear-modulus.html` — Shear Modulus Fun Lab

## Open and test

1. Extract this ZIP file into a folder.
2. Open any `.html` file in Chrome, Edge, or Firefox.
3. Internet access may be needed because the experiments load Three.js and/or Google Fonts from online CDNs.
4. Test the controls, 3D interaction, graphs, reset controls, and tables before merging.

## How group members can merge experiments later

1. Make a backup copy of all three files first.
2. Create one new `index.html` for the combined project; keep these standalone files unchanged.
3. Add navigation tabs or buttons to switch between experiment sections.
4. Do **not** paste multiple complete HTML documents inside one another. Each merged experiment should contribute its body content, styles, and JavaScript to the single page.
5. Rename duplicate IDs (for example `stage`, `material`, `bg`, graph IDs, and reset buttons) so each experiment has unique IDs.
6. Scope CSS selectors to each experiment to prevent styles from one simulator changing another.
7. Load shared libraries such as Three.js only once when practical, and keep each experiment's renderer and animation loop separate.
8. Test the merged page after each experiment is added, including drag/rotation, zoom, graphs, reset buttons, observation tables, and mobile layout.

## Important

This is a **source bundle for sharing and future merging**, not an already integrated website. Keep the original files as backups while your group works on the combined version.
