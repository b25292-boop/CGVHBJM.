"""
Energy Skate Park — Backend (single file)

A minimal Flask + SQLite backend to save and load custom skate-park tracks
(control points, mass, friction, gravity) created in the frontend simulator.

Setup:
    pip install flask
    python app.py

Server runs on http://localhost:5000
Database file `tracks.db` is created automatically on first run.
"""

import sqlite3
import json
from datetime import datetime, timezone
from flask import Flask, request, jsonify, g

app = Flask(__name__)
DB_PATH = "tracks.db"


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL DEFAULT 'Untitled track',
            control_points TEXT NOT NULL,   -- JSON array of [x, y] pairs
            mass REAL DEFAULT 60,
            friction REAL DEFAULT 0.0,
            gravity REAL DEFAULT 9.8,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def row_to_dict(row):
    return {
        "id": row["id"],
        "title": row["title"],
        "controlPoints": json.loads(row["control_points"]),
        "mass": row["mass"],
        "friction": row["friction"],
        "gravity": row["gravity"],
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
    }


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/tracks")
def list_tracks():
    db = get_db()
    rows = db.execute("SELECT * FROM tracks ORDER BY updated_at DESC").fetchall()
    return jsonify([row_to_dict(r) for r in rows])


@app.get("/api/tracks/<int:track_id>")
def get_track(track_id):
    db = get_db()
    row = db.execute("SELECT * FROM tracks WHERE id = ?", (track_id,)).fetchone()
    if row is None:
        return jsonify({"message": "Track not found"}), 404
    return jsonify(row_to_dict(row))


@app.post("/api/tracks")
def create_track():
    data = request.get_json() or {}
    control_points = data.get("controlPoints")
    if not control_points:
        return jsonify({"message": "controlPoints is required"}), 400

    now = datetime.now(timezone.utc).isoformat()
    db = get_db()
    cur = db.execute(
        """
        INSERT INTO tracks (title, control_points, mass, friction, gravity, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            data.get("title", "Untitled track"),
            json.dumps(control_points),
            data.get("mass", 60),
            data.get("friction", 0.0),
            data.get("gravity", 9.8),
            now,
            now,
        ),
    )
    db.commit()
    row = db.execute("SELECT * FROM tracks WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(row_to_dict(row)), 201


@app.put("/api/tracks/<int:track_id>")
def update_track(track_id):
    db = get_db()
    row = db.execute("SELECT * FROM tracks WHERE id = ?", (track_id,)).fetchone()
    if row is None:
        return jsonify({"message": "Track not found"}), 404

    data = request.get_json() or {}
    title = data.get("title", row["title"])
    control_points = json.dumps(data.get("controlPoints")) if "controlPoints" in data else row["control_points"]
    mass = data.get("mass", row["mass"])
    friction = data.get("friction", row["friction"])
    gravity = data.get("gravity", row["gravity"])
    now = datetime.now(timezone.utc).isoformat()

    db.execute(
        """
        UPDATE tracks
        SET title = ?, control_points = ?, mass = ?, friction = ?, gravity = ?, updated_at = ?
        WHERE id = ?
        """,
        (title, control_points, mass, friction, gravity, now, track_id),
    )
    db.commit()
    row = db.execute("SELECT * FROM tracks WHERE id = ?", (track_id,)).fetchone()
    return jsonify(row_to_dict(row))


@app.delete("/api/tracks/<int:track_id>")
def delete_track(track_id):
    db = get_db()
    row = db.execute("SELECT * FROM tracks WHERE id = ?", (track_id,)).fetchone()
    if row is None:
        return jsonify({"message": "Track not found"}), 404
    db.execute("DELETE FROM tracks WHERE id = ?", (track_id,))
    db.commit()
    return jsonify({"message": "Deleted"})


if __name__ == "__main__":
    init_db()
    app.run(debug=True, port=5000)