"""
Projectile Motion Simulator - Physics Engine
------------------------------------------------
Pure calculation logic, no Flask/API code here.
Keeping this separate means:
  - it's easy to unit test
  - other simulators (pendulum, circuits, etc.) can follow the same pattern
  - the frontend team only ever talks to app.py, never to this file directly
"""

import numpy as np

GRAVITY = 9.8  # m/s^2, standard gravity on Earth


def simulate_projectile(initial_velocity: float, angle_degrees: float,
                         initial_height: float = 0.0, gravity: float = GRAVITY,
                         num_points: int = 100) -> dict:
    """
    Calculates the full trajectory of a projectile.

    Args:
        initial_velocity: launch speed in m/s
        angle_degrees: launch angle in degrees (0-90)
        initial_height: starting height in meters (default 0 = ground level)
        gravity: acceleration due to gravity in m/s^2 (default 9.8, Earth)
        num_points: how many points to sample along the trajectory (for plotting)

    Returns:
        dict with trajectory points, and key results (range, max height, time of flight)
    """
    if initial_velocity <= 0:
        raise ValueError("initial_velocity must be greater than 0")
    if not (0 <= angle_degrees <= 90):
        raise ValueError("angle_degrees must be between 0 and 90")
    if gravity <= 0:
        raise ValueError("gravity must be greater than 0")

    angle_rad = np.radians(angle_degrees)
    vx = initial_velocity * np.cos(angle_rad)  # horizontal velocity component
    vy = initial_velocity * np.sin(angle_rad)  # vertical velocity component

    # Time of flight: solve  0 = h0 + vy*t - 0.5*g*t^2  for t (quadratic formula)
    # Using the positive root since time can't be negative
    discriminant = vy**2 + 2 * gravity * initial_height
    time_of_flight = (vy + np.sqrt(discriminant)) / gravity

    # Max height occurs when vertical velocity = 0, i.e. t = vy / g
    time_to_peak = vy / gravity
    max_height = initial_height + (vy * time_to_peak) - (0.5 * gravity * time_to_peak**2)

    # Horizontal range = horizontal velocity * total time of flight
    horizontal_range = vx * time_of_flight

    # Generate trajectory points for plotting on the frontend.
    # Each point also carries velocity + speed, so the frontend can show
    # live velocity/time/distance when the user clicks a specific point
    # on the curve (your "point P" from the sketch).
    t_values = np.linspace(0, time_of_flight, num_points)
    x_values = vx * t_values
    vy_at_t = vy - gravity * t_values  # vertical velocity changes over time; vx stays constant
    y_values = initial_height + (vy * t_values) - (0.5 * gravity * t_values**2)
    y_values = np.clip(y_values, 0, None)  # don't let it dip below ground due to rounding
    speed_values = np.sqrt(vx**2 + vy_at_t**2)  # resultant speed at each instant

    trajectory = [
        {
            "t": round(float(t), 4),
            "x": round(float(x), 4),
            "y": round(float(y), 4),
            "vx": round(float(vx), 4),
            "vy": round(float(vy_t), 4),
            "speed": round(float(speed), 4),
        }
        for t, x, y, vy_t, speed in zip(t_values, x_values, y_values, vy_at_t, speed_values)
    ]

    return {
        "inputs": {
            "initial_velocity": initial_velocity,
            "angle_degrees": angle_degrees,
            "initial_height": initial_height,
            "gravity": gravity,
        },
        "results": {
            "time_of_flight": round(float(time_of_flight), 4),
            "max_height": round(float(max_height), 4),
            "horizontal_range": round(float(horizontal_range), 4),
            "vx": round(float(vx), 4),
            "vy": round(float(vy), 4),
        },
        "trajectory": trajectory,
    }


def get_point_at_x(x_clicked: float, initial_velocity: float, angle_degrees: float,
                    initial_height: float = 0.0, gravity: float = GRAVITY) -> dict:
    """
    Given an x-position the user clicked on the trajectory curve, calculates the
    EXACT y, time, velocity and speed at that point — not just the nearest of the
    100 pre-sampled points. This is what backs "click anywhere on the line" on P.

    Args:
        x_clicked: the horizontal distance (in meters) where the user clicked
        initial_velocity, angle_degrees, initial_height, gravity: same launch
            conditions used to originally generate the trajectory

    Returns:
        dict with t, x, y, vx, vy, speed at that exact clicked point
    """
    if initial_velocity <= 0:
        raise ValueError("initial_velocity must be greater than 0")
    if not (0 <= angle_degrees <= 90):
        raise ValueError("angle_degrees must be between 0 and 90")
    if gravity <= 0:
        raise ValueError("gravity must be greater than 0")

    angle_rad = np.radians(angle_degrees)
    vx = initial_velocity * np.cos(angle_rad)
    vy = initial_velocity * np.sin(angle_rad)

    # Total range, to make sure the clicked x is actually on the trajectory
    discriminant = vy**2 + 2 * gravity * initial_height
    time_of_flight = (vy + np.sqrt(discriminant)) / gravity
    horizontal_range = vx * time_of_flight

    if x_clicked < 0 or x_clicked > horizontal_range:
        raise ValueError(
            f"x_clicked must be between 0 and {round(float(horizontal_range), 4)} "
            f"(the projectile's total range)"
        )

    # Since horizontal velocity is constant: x = vx * t  =>  t = x / vx
    t = x_clicked / vx

    y = initial_height + (vy * t) - (0.5 * gravity * t**2)
    y = max(y, 0.0)  # guard against tiny floating-point dips below ground

    vy_at_t = vy - gravity * t
    speed = np.sqrt(vx**2 + vy_at_t**2)
    # Direction of travel at this exact point: positive angle = still rising,
    # negative angle = falling. atan2 handles both correctly.
    angle_at_t = np.degrees(np.arctan2(vy_at_t, vx))

    return {
        "t": round(float(t), 4),
        "x": round(float(x_clicked), 4),
        "y": round(float(y), 4),
        "vx": round(float(vx), 4),
        "vy": round(float(vy_at_t), 4),
        "speed": round(float(speed), 4),
        "angle_degrees": round(float(angle_at_t), 4),
    }


# ============================================================
# FIND-POINT-BY-ANY-PARAMETER
# ------------------------------------------------------------
# get_point_at_x() above only lets you locate a point by its x-position
# (which is what a canvas click naturally gives you). But a student
# might instead know the TIME, the HEIGHT (y), or the vertical velocity
# (vy) at the point they want to examine. These functions handle those
# cases - each returns the same full point dict (t, x, y, vx, vy, speed,
# angle_degrees) so the frontend can reuse the same quiz/reveal flow no
# matter which parameter was used to locate the point.
#
# Height (y) is the only one that can match TWO points on the curve (once
# on the way up, once on the way down) - so that one returns a LIST.
# ============================================================

def _full_point_from_time(t: float, initial_velocity: float, angle_degrees: float,
                           initial_height: float, gravity: float) -> dict:
    """Shared helper: build the full point dict once t is known."""
    angle_rad = np.radians(angle_degrees)
    vx = initial_velocity * np.cos(angle_rad)
    vy0 = initial_velocity * np.sin(angle_rad)

    x = vx * t
    y = initial_height + (vy0 * t) - (0.5 * gravity * t**2)
    y = max(y, 0.0)
    vy_at_t = vy0 - gravity * t
    speed = np.sqrt(vx**2 + vy_at_t**2)
    angle_at_t = np.degrees(np.arctan2(vy_at_t, vx))

    return {
        "t": round(float(t), 4),
        "x": round(float(x), 4),
        "y": round(float(y), 4),
        "vx": round(float(vx), 4),
        "vy": round(float(vy_at_t), 4),
        "speed": round(float(speed), 4),
        "angle_degrees": round(float(angle_at_t), 4),
    }


def get_point_at_time(t: float, initial_velocity: float, angle_degrees: float,
                       initial_height: float = 0.0, gravity: float = GRAVITY) -> dict:
    """Locate the point on the trajectory at a given time t."""
    if initial_velocity <= 0:
        raise ValueError("initial_velocity must be greater than 0")
    if not (0 <= angle_degrees <= 90):
        raise ValueError("angle_degrees must be between 0 and 90")
    if t < 0:
        raise ValueError("t can't be negative")

    full = simulate_projectile(initial_velocity, angle_degrees, initial_height, gravity)
    time_of_flight = full["results"]["time_of_flight"]
    if t > time_of_flight:
        raise ValueError(
            f"t={t}s is after the projectile has already landed "
            f"(total flight time is {time_of_flight}s)"
        )

    return _full_point_from_time(t, initial_velocity, angle_degrees, initial_height, gravity)


def get_points_at_y(y_target: float, initial_velocity: float, angle_degrees: float,
                     initial_height: float = 0.0, gravity: float = GRAVITY) -> list:
    """
    Locate the point(s) on the trajectory at a given height y.
    Returns a LIST because a height below the peak is usually crossed
    TWICE - once going up, once coming down.
    """
    if initial_velocity <= 0:
        raise ValueError("initial_velocity must be greater than 0")
    if not (0 <= angle_degrees <= 90):
        raise ValueError("angle_degrees must be between 0 and 90")
    if y_target < 0:
        raise ValueError("y can't be negative — the ground is y=0")

    angle_rad = np.radians(angle_degrees)
    vy0 = initial_velocity * np.sin(angle_rad)

    full = simulate_projectile(initial_velocity, angle_degrees, initial_height, gravity)
    max_height = full["results"]["max_height"]
    time_of_flight = full["results"]["time_of_flight"]

    if y_target > max_height:
        raise ValueError(
            f"This projectile never reaches y={y_target}m — its max height "
            f"is only {max_height}m"
        )

    # Solve 0.5*g*t^2 - vy0*t + (y_target - initial_height) = 0 for t
    a = 0.5 * gravity
    b = -vy0
    c = y_target - initial_height
    discriminant = b**2 - 4 * a * c
    discriminant = max(discriminant, 0.0)  # guard tiny negative from rounding at the exact peak

    t1 = (-b - np.sqrt(discriminant)) / (2 * a)
    t2 = (-b + np.sqrt(discriminant)) / (2 * a)

    candidate_times = sorted(set(round(float(t), 6) for t in (t1, t2)))
    valid_times = [t for t in candidate_times if -1e-6 <= t <= time_of_flight + 1e-6]
    valid_times = [max(t, 0.0) for t in valid_times]

    if not valid_times:
        raise ValueError(f"y={y_target}m isn't reached during this flight")

    return [
        _full_point_from_time(t, initial_velocity, angle_degrees, initial_height, gravity)
        for t in valid_times
    ]


def get_point_at_vy(vy_target: float, initial_velocity: float, angle_degrees: float,
                     initial_height: float = 0.0, gravity: float = GRAVITY) -> dict:
    """
    Locate the point on the trajectory where the vertical velocity equals
    vy_target. Since vy decreases steadily (never speeds back up) over the
    flight, there's always exactly ONE matching point - unlike height.
    """
    if initial_velocity <= 0:
        raise ValueError("initial_velocity must be greater than 0")
    if not (0 <= angle_degrees <= 90):
        raise ValueError("angle_degrees must be between 0 and 90")

    angle_rad = np.radians(angle_degrees)
    vy0 = initial_velocity * np.sin(angle_rad)

    full = simulate_projectile(initial_velocity, angle_degrees, initial_height, gravity)
    time_of_flight = full["results"]["time_of_flight"]
    vy_at_landing = vy0 - gravity * time_of_flight

    if not (vy_at_landing - 1e-6 <= vy_target <= vy0 + 1e-6):
        raise ValueError(
            f"vy={vy_target} m/s never occurs during this flight "
            f"(it ranges from {round(float(vy0), 3)} down to {round(float(vy_at_landing), 3)} m/s)"
        )

    t = (vy0 - vy_target) / gravity
    t = min(max(t, 0.0), time_of_flight)  # clamp tiny rounding overshoot at the edges

    return _full_point_from_time(t, initial_velocity, angle_degrees, initial_height, gravity)


# ============================================================
# REVERSE SOLVERS
# ------------------------------------------------------------
# The functions above need initial_velocity + angle_degrees to work.
# But sometimes a student knows OTHER combinations instead (e.g. the
# range and the max height, but not the launch angle). These functions
# work backwards: given a different pair of known values, they solve
# for the missing velocity and/or angle, so the trajectory can still
# be generated with simulate_projectile() afterwards.
#
# All of these correctly account for a non-zero launch height (h0) -
# nothing here assumes the ball starts at ground level.
# ============================================================

def _time_of_flight_from_vy(vy: float, initial_height: float, gravity: float) -> float:
    """Shared helper: total flight time given vertical velocity and launch height."""
    discriminant = vy**2 + 2 * gravity * initial_height
    if discriminant < 0:
        # Physically shouldn't happen for vy>=0 and initial_height>=0, but guards
        # against bad input combinations (e.g. negative height).
        raise ValueError("These values don't correspond to a real projectile path")
    return (vy + np.sqrt(discriminant)) / gravity


def solve_from_maxheight_angle(max_height: float, angle_degrees: float,
                                initial_height: float = 0.0, gravity: float = GRAVITY) -> dict:
    """
    Case: you know the peak (max) height reached and the launch angle,
    but not the initial velocity.

    max_height is measured from the ground (absolute), same reference as
    initial_height - NOT the extra height gained above the launch point.

    Physics: at the peak, vertical velocity = 0. The extra height gained
    above the launch point is (max_height - initial_height), and
    vy^2 = 2 * g * (max_height - initial_height).  Then v = vy / sin(angle).
    """
    if not (0 <= angle_degrees <= 90):
        raise ValueError("angle_degrees must be between 0 and 90")
    if angle_degrees == 0:
        raise ValueError(
            "With a 0-degree angle the projectile never gains height, "
            "so a max height target can't be reached — try a nonzero angle"
        )
    if max_height < initial_height:
        raise ValueError(
            "max_height can't be less than initial_height — the projectile "
            "starts at initial_height and can only go up from there"
        )

    gain = max_height - initial_height
    vy = np.sqrt(2 * gravity * gain)
    angle_rad = np.radians(angle_degrees)
    v = vy / np.sin(angle_rad)

    return {
        "initial_velocity": round(float(v), 4),
        "angle_degrees": angle_degrees,
    }


def solve_from_range_time(horizontal_range: float, time_of_flight: float,
                           initial_height: float = 0.0, gravity: float = GRAVITY) -> dict:
    """
    Case: you know the total range and the total time of flight, but not
    velocity or angle.

    Physics: horizontal velocity is constant, so vx = range / time.
    Vertical motion: at landing, 0 = h0 + vy*T - 0.5*g*T^2  =>  vy = (0.5*g*T^2 - h0) / T
    Then v = sqrt(vx^2 + vy^2) and angle = atan(vy / vx).
    """
    if horizontal_range <= 0:
        raise ValueError("horizontal_range must be greater than 0")
    if time_of_flight <= 0:
        raise ValueError("time_of_flight must be greater than 0")

    vx = horizontal_range / time_of_flight
    vy = (0.5 * gravity * time_of_flight**2 - initial_height) / time_of_flight

    if vy < 0:
        raise ValueError(
            "This range/time combination isn't physically possible for a "
            "projectile launched upward or level from this initial_height — "
            "double check the numbers (the time given is too long for that range)"
        )

    v = np.sqrt(vx**2 + vy**2)
    angle_degrees = np.degrees(np.arctan2(vy, vx))

    return {
        "initial_velocity": round(float(v), 4),
        "angle_degrees": round(float(angle_degrees), 4),
    }


def solve_from_range_maxheight(horizontal_range: float, max_height: float,
                                initial_height: float = 0.0, gravity: float = GRAVITY) -> dict:
    """
    Case: you know the range and the max height, but not velocity or angle.

    Physics:
      1. From max_height alone: vy = sqrt(2*g*(max_height - initial_height))
      2. That vy gives the total time of flight (using the same quadratic
         formula as everywhere else in this file).
      3. Horizontal velocity is then just vx = range / time_of_flight.
      4. Combine vx, vy into total velocity and angle.
    """
    if horizontal_range <= 0:
        raise ValueError("horizontal_range must be greater than 0")
    if max_height < initial_height:
        raise ValueError(
            "max_height can't be less than initial_height — the projectile "
            "starts at initial_height and can only go up from there"
        )

    gain = max_height - initial_height
    vy = np.sqrt(2 * gravity * gain)
    time_of_flight = _time_of_flight_from_vy(vy, initial_height, gravity)

    if time_of_flight <= 0:
        raise ValueError("These values don't correspond to a real projectile path")

    vx = horizontal_range / time_of_flight
    v = np.sqrt(vx**2 + vy**2)
    angle_degrees = np.degrees(np.arctan2(vy, vx))

    return {
        "initial_velocity": round(float(v), 4),
        "angle_degrees": round(float(angle_degrees), 4),
    }


def solve_from_range_velocity(horizontal_range: float, initial_velocity: float,
                               initial_height: float = 0.0, gravity: float = GRAVITY) -> dict:
    """
    Case: you know the range and the velocity, but not the angle.

    Unlike the other solvers above, there's no simple closed-form formula
    for this when initial_height != 0 (the angle appears in both the
    horizontal AND vertical motion in a way that can't be cleanly separated).
    So this scans across possible angles numerically and finds the one(s)
    that produce the target range.

    There can be TWO valid angles for the same range (a "low, flat" throw
    and a "high, arcing" throw) - this returns the lower angle by default,
    since that's the more common answer expected in physics problems, and
    also reports the higher one for reference.

    If the target range is farther than this velocity can ever reach
    (even at the best possible angle), raises a clear error instead of
    returning a wrong answer.
    """
    if horizontal_range <= 0:
        raise ValueError("horizontal_range must be greater than 0")
    if initial_velocity <= 0:
        raise ValueError("initial_velocity must be greater than 0")

    # Scan a fine grid of angles and compute the range each one produces.
    angles = np.linspace(0.01, 89.99, 9000)
    angle_rads = np.radians(angles)
    vx_all = initial_velocity * np.cos(angle_rads)
    vy_all = initial_velocity * np.sin(angle_rads)
    discriminants = vy_all**2 + 2 * gravity * initial_height
    times = (vy_all + np.sqrt(discriminants)) / gravity
    ranges = vx_all * times

    max_range = float(np.max(ranges))
    best_angle_for_max = float(angles[np.argmax(ranges)])

    if horizontal_range > max_range:
        raise ValueError(
            f"A velocity of {initial_velocity} m/s can reach at most "
            f"{round(max_range, 2)} m (at {round(best_angle_for_max, 1)} degrees) "
            f"from this initial_height — the target range of {horizontal_range} m "
            f"isn't reachable, try a higher velocity or a shorter range"
        )

    # Range increases from angle=0 up to best_angle_for_max, then decreases.
    # Find the closest match on each side of that peak.
    idx_peak = int(np.argmax(ranges))

    low_side_ranges = ranges[:idx_peak + 1]
    low_side_angles = angles[:idx_peak + 1]
    low_idx = int(np.argmin(np.abs(low_side_ranges - horizontal_range)))
    low_angle = float(low_side_angles[low_idx])

    high_side_ranges = ranges[idx_peak:]
    high_side_angles = angles[idx_peak:]
    high_idx = int(np.argmin(np.abs(high_side_ranges - horizontal_range)))
    high_angle = float(high_side_angles[high_idx])

    return {
        "initial_velocity": initial_velocity,
        "angle_degrees": round(low_angle, 2),
        "alternate_angle_degrees": round(high_angle, 2),
    }


# ============================================================
# UNIVERSAL SOLVER
# ------------------------------------------------------------
# Instead of the student picking "which combination do I know" from a
# fixed menu, this function accepts ANY subset of the 5 core values
# (velocity, angle, range, max height, time of flight) - whichever the
# student happens to know - and figures out on its own whether that's
# enough information to solve for velocity + angle, which formula to
# use, and whether the numbers given are even physically possible.
# ============================================================

def _range_for(v: float, angle_degrees: float, initial_height: float, gravity: float) -> float:
    """Helper: what range does this v + angle produce? Used by the bisection solvers below."""
    angle_rad = np.radians(angle_degrees)
    vx = v * np.cos(angle_rad)
    vy = v * np.sin(angle_rad)
    discriminant = vy**2 + 2 * gravity * initial_height
    if discriminant < 0:
        raise ValueError("These values don't correspond to a real projectile path")
    t_flight = (vy + np.sqrt(discriminant)) / gravity
    return vx * t_flight


def _solve_velocity_from_angle_range(angle_degrees: float, horizontal_range: float,
                                      initial_height: float, gravity: float) -> float:
    """
    Given a fixed angle and a target range, finds the velocity that produces
    it. Range increases steadily as velocity increases (for a fixed angle),
    so this narrows in on the answer step by step (bisection) rather than
    using one direct formula.
    """
    if angle_degrees >= 90:
        raise ValueError("At a 90-degree angle the projectile goes straight up and can never have a horizontal range")
    if angle_degrees <= 0 and initial_height <= 0:
        raise ValueError("At a 0-degree angle with no initial height, the projectile can't travel any horizontal range")

    lo, hi = 1e-6, 1.0
    # Expand hi until it overshoots the target range
    for _ in range(200):
        if _range_for(hi, angle_degrees, initial_height, gravity) >= horizontal_range:
            break
        hi *= 2
    else:
        raise ValueError("Couldn't find a velocity that reaches this range at this angle — double check your numbers")

    for _ in range(100):
        mid = (lo + hi) / 2
        if _range_for(mid, angle_degrees, initial_height, gravity) < horizontal_range:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def solve_trajectory(initial_velocity: float = None, angle_degrees: float = None,
                      horizontal_range: float = None, max_height: float = None,
                      time_of_flight: float = None, initial_height: float = 0.0,
                      gravity: float = GRAVITY) -> dict:
    """
    The main entry point for flexible input: pass in whichever of
    initial_velocity / angle_degrees / horizontal_range / max_height /
    time_of_flight you actually know (leave the rest as None), and this
    figures out the rest - or raises a ValueError explaining why it can't
    (not enough info, or the numbers given aren't physically possible).

    Returns: dict with "initial_velocity", "angle_degrees", and "method"
    (which pair of known values was used to solve it).
    """
    known = {}
    if initial_velocity is not None:
        known["v"] = initial_velocity
    if angle_degrees is not None:
        known["theta"] = angle_degrees
    if horizontal_range is not None:
        known["R"] = horizontal_range
    if max_height is not None:
        known["H"] = max_height
    if time_of_flight is not None:
        known["T"] = time_of_flight

    if len(known) < 2:
        raise ValueError(
            "Please provide at least two of: velocity, angle, range, "
            "max height, time of flight — one value alone isn't enough "
            "to determine a unique trajectory"
        )

    h0, g = initial_height, gravity
    solved_v = solved_theta = method = None

    # Try combinations in order of directness/reliability.
    if "v" in known and "theta" in known:
        solved_v, solved_theta = known["v"], known["theta"]
        method = "velocity_angle"

    elif "theta" in known and "R" in known:
        solved_theta = known["theta"]
        solved_v = _solve_velocity_from_angle_range(known["theta"], known["R"], h0, g)
        method = "angle_range"

    elif "theta" in known and "H" in known:
        result = solve_from_maxheight_angle(known["H"], known["theta"], h0, g)
        solved_v, solved_theta = result["initial_velocity"], result["angle_degrees"]
        method = "angle_maxheight"

    elif "theta" in known and "T" in known:
        if known["theta"] <= 0:
            raise ValueError("Can't solve velocity from a 0-degree angle and time alone")
        vy_req = (0.5 * g * known["T"]**2 - h0) / known["T"]
        if vy_req < 0:
            raise ValueError(
                "This time of flight isn't physically possible from this "
                "initial_height — double check the numbers"
            )
        angle_rad = np.radians(known["theta"])
        solved_v = vy_req / np.sin(angle_rad)
        solved_theta = known["theta"]
        method = "angle_time"

    elif "v" in known and "R" in known:
        result = solve_from_range_velocity(known["R"], known["v"], h0, g)
        solved_v, solved_theta = result["initial_velocity"], result["angle_degrees"]
        method = "velocity_range"

    elif "v" in known and "H" in known:
        gain = known["H"] - h0
        if gain < 0:
            raise ValueError(
                "max_height can't be less than initial_height — the projectile "
                "starts at initial_height and can only go up from there"
            )
        vy_req = np.sqrt(2 * g * gain)
        if vy_req > known["v"]:
            raise ValueError(
                f"A velocity of {known['v']} m/s can't reach a max height of "
                f"{known['H']} m from this initial_height — try a higher velocity "
                f"or a lower max height"
            )
        solved_theta = np.degrees(np.arcsin(vy_req / known["v"]))
        solved_v = known["v"]
        method = "velocity_maxheight"

    elif "v" in known and "T" in known:
        vy_req = (0.5 * g * known["T"]**2 - h0) / known["T"]
        if vy_req < 0 or vy_req > known["v"]:
            raise ValueError(
                "This velocity and time of flight don't correspond to a "
                "physically possible trajectory from this initial_height — "
                "double check the numbers"
            )
        solved_theta = np.degrees(np.arcsin(vy_req / known["v"]))
        solved_v = known["v"]
        method = "velocity_time"

    elif "R" in known and "H" in known:
        result = solve_from_range_maxheight(known["R"], known["H"], h0, g)
        solved_v, solved_theta = result["initial_velocity"], result["angle_degrees"]
        method = "range_maxheight"

    elif "R" in known and "T" in known:
        result = solve_from_range_time(known["R"], known["T"], h0, g)
        solved_v, solved_theta = result["initial_velocity"], result["angle_degrees"]
        method = "range_time"

    elif "H" in known and "T" in known:
        raise ValueError(
            "Max height and time of flight alone aren't enough to pin down "
            "a unique velocity and angle — please also provide range or "
            "velocity"
        )

    else:
        raise ValueError("Couldn't determine a solvable combination from the given values")

    # If MORE than 2 values were given, check the extras are consistent
    # with what we solved for. If they don't match, the input is
    # contradictory (e.g. numbers that don't come from the same real throw).
    full = simulate_projectile(solved_v, solved_theta, h0, g)
    computed = {
        "v": full["inputs"]["initial_velocity"],
        "theta": full["inputs"]["angle_degrees"],
        "R": full["results"]["horizontal_range"],
        "H": full["results"]["max_height"],
        "T": full["results"]["time_of_flight"],
    }
    labels = {"v": "velocity", "theta": "angle", "R": "range", "H": "max height", "T": "time of flight"}
    tolerance = 0.03  # 3% relative tolerance, to allow for rounding in what the student typed

    for key, given_value in known.items():
        comp_value = computed[key]
        denom = abs(given_value) if abs(given_value) > 1e-9 else 1.0
        if abs(comp_value - given_value) / denom > tolerance:
            raise ValueError(
                f"The values you entered don't all match the same trajectory "
                f"(mismatch in {labels[key]}: you gave {given_value}, but the rest "
                f"of your inputs imply {round(comp_value, 3)}) — double check your numbers"
            )

    return {
        "initial_velocity": round(float(solved_v), 4),
        "angle_degrees": round(float(solved_theta), 4),
        "method": method,
    }