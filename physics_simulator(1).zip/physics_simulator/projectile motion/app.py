"""
Backend API for the Physics Simulator Website
------------------------------------------------
Run this with:  python app.py
Then it's live at http://localhost:5000

Endpoints:
  GET  /                                -> health check
  POST /api/projectile-motion           -> run a full simulation (velocity + angle known)
  POST /api/projectile-motion/point 
          -> get exact velocity/time/y at a clicked x-position
  POST /api/projectile-motion/solve     -> figure out velocity/angle from OTHER known values
                                            (e.g. range+max_height, range+time, etc.)

As you add more simulators (pendulum, circuits, etc.), follow this same
pattern: put the physics in simulators/<name>.py, then add one route here.
"""

from flask import Flask, request, jsonify
from simulators.projectile_motion import (
    simulate_projectile,
    get_point_at_x,
    get_point_at_time,
    get_points_at_y,
    get_point_at_vy,
    solve_trajectory,
)

app = Flask(__name__)


# --- Manual CORS handling (no internet access to install flask-cors here,
# but this does the same job: lets your frontend, on a different port/domain,
# call this API from the browser) ---
@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response


@app.route("/")
def health_check():
    return jsonify({"status": "ok", "message": "Physics Simulator API is running"})


@app.route("/api/projectile-motion", methods=["POST", "OPTIONS"])
def projectile_motion():
    if request.method == "OPTIONS":
        # Browser preflight request - just needs a 200 with CORS headers
        return "", 200

    data = request.get_json(silent=True) or {}

    try:
        initial_velocity = float(data.get("initial_velocity", 20))
        angle_degrees = float(data.get("angle_degrees", 45))
        initial_height = float(data.get("initial_height", 0))
        gravity = float(data.get("gravity", 9.8))
    except (TypeError, ValueError):
        return jsonify({"error": "All inputs must be numbers"}), 400

    try:
        result = simulate_projectile(
            initial_velocity=initial_velocity,
            angle_degrees=angle_degrees,
            initial_height=initial_height,
            gravity=gravity,
        )
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    return jsonify(result)


@app.route("/api/projectile-motion/point", methods=["POST", "OPTIONS"])
def projectile_motion_point():
    """
    Used when the user clicks anywhere on the trajectory line in the frontend.
    Frontend sends the x-position clicked (converted from pixels to meters)
    plus the same launch conditions used to draw the curve, and gets back the
    EXACT velocity/time/y at that spot - not just the nearest sampled point.
    """
    if request.method == "OPTIONS":
        return "", 200

    data = request.get_json(silent=True) or {}

    try:
        x_clicked = float(data["x_clicked"])
        initial_velocity = float(data.get("initial_velocity", 20))
        angle_degrees = float(data.get("angle_degrees", 45))
        initial_height = float(data.get("initial_height", 0))
        gravity = float(data.get("gravity", 9.8))
    except KeyError:
        return jsonify({"error": "x_clicked is required"}), 400
    except (TypeError, ValueError):
        return jsonify({"error": "All inputs must be numbers"}), 400

    try:
        result = get_point_at_x(
            x_clicked=x_clicked,
            initial_velocity=initial_velocity,
            angle_degrees=angle_degrees,
            initial_height=initial_height,
            gravity=gravity,
        )
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    return jsonify(result)


@app.route("/api/projectile-motion/solve", methods=["POST", "OPTIONS"])
def projectile_motion_solve():
    """
    Used when the student doesn't know velocity+angle directly, but knows
    SOME OTHER combination of values instead. Unlike a fixed multiple-choice
    "mode", this accepts ANY subset of the 5 fields below - just send
    whichever ones you actually have, leave the rest out (or null):

      initial_velocity, angle_degrees, horizontal_range, max_height, time_of_flight

    initial_height and gravity are optional in all cases (default 0 and 9.8).

    The backend figures out on its own whether the given values are enough
    to solve for velocity + angle, and returns a clear error/disclaimer if:
      - fewer than 2 values were given (not enough info)
      - the combination given isn't solvable (e.g. max_height + time alone)
      - the numbers given aren't physically possible (e.g. an unreachable range)
      - extra values were given that don't match a single real trajectory

    On success, generates the full trajectory (same response shape as
    /api/projectile-motion) so the frontend can reuse the same drawing code.
    """
    if request.method == "OPTIONS":
        return "", 200

    data = request.get_json(silent=True) or {}

    def optional_float(key):
        val = data.get(key)
        if val is None or val == "":
            return None
        try:
            return float(val)
        except (TypeError, ValueError):
            raise ValueError(f"{key} must be a number")

    try:
        initial_velocity = optional_float("initial_velocity")
        angle_degrees = optional_float("angle_degrees")
        horizontal_range = optional_float("horizontal_range")
        max_height = optional_float("max_height")
        time_of_flight = optional_float("time_of_flight")
        initial_height = optional_float("initial_height") or 0.0
        gravity = optional_float("gravity") or 9.8
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    try:
        solved = solve_trajectory(
            initial_velocity=initial_velocity,
            angle_degrees=angle_degrees,
            horizontal_range=horizontal_range,
            max_height=max_height,
            time_of_flight=time_of_flight,
            initial_height=initial_height,
            gravity=gravity,
        )
    except ValueError as e:
        # This covers BOTH "not enough info" and physics disclaimers
        # (unreachable range, inconsistent values, etc.)
        return jsonify({"error": str(e)}), 400

    try:
        result = simulate_projectile(
            initial_velocity=solved["initial_velocity"],
            angle_degrees=solved["angle_degrees"],
            initial_height=initial_height,
            gravity=gravity,
        )
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    result["solved_from"] = solved["method"]
    return jsonify(result)


@app.route("/api/projectile-motion/find-point", methods=["POST", "OPTIONS"])
def projectile_motion_find_point():
    """
    Locates point(s) on the trajectory using WHATEVER parameter the student
    knows - not just an x-position from a click. Send a "find_by" field
    telling us which parameter you're providing:

      find_by: "t"   + value = time in seconds
      find_by: "x"   + value = horizontal distance in meters
      find_by: "y"   + value = height in meters (may return TWO points -
                                once going up, once coming down)
      find_by: "vy"  + value = vertical velocity in m/s

    Always returns {"points": [...]} - a list, even when there's only one
    match - so the frontend can handle both cases the same way. Each point
    has the same shape as /point: t, x, y, vx, vy, speed, angle_degrees.
    """
    if request.method == "OPTIONS":
        return "", 200

    data = request.get_json(silent=True) or {}
    find_by = data.get("find_by")

    try:
        value = float(data["value"])
        initial_velocity = float(data.get("initial_velocity", 20))
        angle_degrees = float(data.get("angle_degrees", 45))
        initial_height = float(data.get("initial_height", 0))
        gravity = float(data.get("gravity", 9.8))
    except KeyError:
        return jsonify({"error": "value is required"}), 400
    except (TypeError, ValueError):
        return jsonify({"error": "All inputs must be numbers"}), 400

    try:
        if find_by == "t":
            point = get_point_at_time(value, initial_velocity, angle_degrees, initial_height, gravity)
            points = [point]
        elif find_by == "x":
            point = get_point_at_x(value, initial_velocity, angle_degrees, initial_height, gravity)
            points = [point]
        elif find_by == "y":
            points = get_points_at_y(value, initial_velocity, angle_degrees, initial_height, gravity)
        elif find_by == "vy":
            point = get_point_at_vy(value, initial_velocity, angle_degrees, initial_height, gravity)
            points = [point]
        else:
            return jsonify({"error": "find_by must be one of: t, x, y, vy"}), 400
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    return jsonify({"points": points})


if __name__ == "__main__":
    app.run(debug=True, port=5000)